package pl.anaris.stayquest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public final class MainActivity extends Activity {
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String ASSET_PREFIX = "/assets/www/";
    private static final String START_URL = "https://" + LOCAL_HOST + ASSET_PREFIX + "index.html#/home";
    private static final int REQUEST_IMPORT = 4101;
    private static final int REQUEST_EXPORT = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 10, 15));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        setContentView(webView);

        applySystemInsets();
        configureWebView();

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            webView.loadUrl(START_URL);
        }
    }

    private void applySystemInsets() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout()
                );
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            webView.setFitsSystemWindows(true);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSafeBrowsingEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString() + " STAYQUEST-ANDROID/0.6.0");

        boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(debuggable);

        webView.addJavascriptInterface(new StayQuestBridge(), "StayQuestAndroid");
        webView.setWebViewClient(new LocalContentClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                WebView view,
                ValueCallback<Uri[]> callback,
                FileChooserParams params
            ) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;

                Intent intent = params.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(intent, REQUEST_IMPORT);
                    return true;
                } catch (ActivityNotFoundException error) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, R.string.file_picker_missing, Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
    }

    private final class LocalContentClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return localAssetResponse(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            if (isLocalUrl(url)) return false;
            openExternal(url);
            return true;
        }
    }

    private boolean isLocalUrl(Uri url) {
        return "https".equals(url.getScheme()) && LOCAL_HOST.equals(url.getHost());
    }

    private WebResourceResponse localAssetResponse(Uri url) {
        if (!isLocalUrl(url) || url.getPath() == null || !url.getPath().startsWith(ASSET_PREFIX)) return null;

        String relativePath = Uri.decode(url.getPath().substring(ASSET_PREFIX.length()));
        if (relativePath.isEmpty()) relativePath = "index.html";
        if (relativePath.contains("..")) return errorResponse(403, "Forbidden");

        try {
            InputStream stream = getAssets().open("www/" + relativePath);
            String mimeType = mimeType(relativePath);
            String encoding = isTextMime(mimeType) ? "UTF-8" : null;
            return new WebResourceResponse(
                mimeType,
                encoding,
                200,
                "OK",
                Collections.singletonMap("Cache-Control", "no-store"),
                stream
            );
        } catch (FileNotFoundException error) {
            return errorResponse(404, "Not Found");
        } catch (IOException error) {
            return errorResponse(500, "Read Error");
        }
    }

    private WebResourceResponse errorResponse(int status, String reason) {
        byte[] body = reason.getBytes(StandardCharsets.UTF_8);
        return new WebResourceResponse(
            "text/plain",
            "UTF-8",
            status,
            reason,
            Collections.emptyMap(),
            new ByteArrayInputStream(body)
        );
    }

    private String mimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "text/javascript";
        if (lower.endsWith(".json") || lower.endsWith(".webmanifest")) return "application/json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    private boolean isTextMime(String mimeType) {
        return mimeType.startsWith("text/") || mimeType.contains("json") || mimeType.contains("svg");
    }

    private void openExternal(Uri url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, url));
        } catch (ActivityNotFoundException error) {
            Toast.makeText(this, R.string.browser_missing, Toast.LENGTH_LONG).show();
        }
    }

    private void requestBackupSave(String content, String filename) {
        pendingBackup = content;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, safeFilename(filename));
        try {
            startActivityForResult(intent, REQUEST_EXPORT);
        } catch (ActivityNotFoundException error) {
            pendingBackup = null;
            Toast.makeText(this, R.string.file_picker_missing, Toast.LENGTH_LONG).show();
        }
    }

    private String safeFilename(String filename) {
        if (filename != null && filename.matches("[A-Za-z0-9._-]{1,96}\\.json")) return filename;
        return "stay-quest-backup.json";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMPORT) {
            if (fileChooserCallback == null) return;
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileChooserCallback.onReceiveValue(result);
            fileChooserCallback = null;
            return;
        }

        if (requestCode == REQUEST_EXPORT) {
            String backup = pendingBackup;
            pendingBackup = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || backup == null) return;

            try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                if (output == null) throw new IOException("Brak strumienia zapisu.");
                output.write(backup.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, R.string.backup_saved, Toast.LENGTH_SHORT).show();
            } catch (IOException error) {
                Toast.makeText(this, R.string.backup_failed, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
        if (webView != null) {
            webView.removeJavascriptInterface("StayQuestAndroid");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    public final class StayQuestBridge {
        @JavascriptInterface
        public void saveBackup(String content, String filename) {
            runOnUiThread(() -> requestBackupSave(content, filename));
        }
    }
}
