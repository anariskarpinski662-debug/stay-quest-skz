export function createSeededRandom(seed = Date.now()) {
  let state = Number(seed) >>> 0;

  return function seededRandom() {
    state += 0x6d2b79f5;
    let value = state;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function shuffle(items, random = Math.random) {
  const result = [...items];

  for (let index = result.length - 1; index > 0; index -= 1) {
    const randomValue = random();
    if (!Number.isFinite(randomValue) || randomValue < 0 || randomValue >= 1) {
      throw new RangeError("Generator losowy musi zwracać wartość od 0 (włącznie) do 1 (wyłącznie).");
    }
    const target = Math.floor(randomValue * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }

  return result;
}

export function sampleWithoutReplacement(items, count, random = Math.random) {
  if (!Number.isInteger(count) || count < 1) throw new RangeError("Liczba elementów musi być dodatnia.");
  return shuffle(items, random).slice(0, Math.min(count, items.length));
}
