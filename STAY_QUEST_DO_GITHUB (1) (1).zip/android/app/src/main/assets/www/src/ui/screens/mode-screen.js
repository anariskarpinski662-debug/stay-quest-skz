import { findGameMode } from "../../data/game-modes.js";
import { getQuizQuestionCount } from "../../data/question-bank.js";
import { TIMELINE_EVENT_COUNT } from "../../data/timeline-events.js";
import { MEMBER_SYMBOLS } from "../../data/member-symbols.js";

function getContentSummary(modeId) {
  const questionCount = getQuizQuestionCount(modeId);
  if (questionCount) return `${questionCount} pytań w banku • runda losuje 10`;
  if (modeId === "timeline") return `${TIMELINE_EVENT_COUNT} wydarzeń • rundy po 4, 6 lub 8`;
  if (modeId === "skzoo-memory") return `${MEMBER_SYMBOLS.length} postaci • plansze po 4, 6 lub 8 par`;
  return "Tryb gotowy";
}

export function createModeScreen(modeId) {
  const mode = findGameMode(modeId);
  const screen = document.createElement("div");
  screen.className = "screen mode-screen";

  if (!mode) {
    screen.innerHTML = `
      <section class="empty-state">
        <span aria-hidden="true">?</span>
        <h1>Nie ma takiego trybu</h1>
        <p>Wróć do ekranu głównego i wybierz jedną z dostępnych kart.</p>
        <a class="button button--primary" href="#/home">Wróć do trybów</a>
      </section>
    `;
    return screen;
  }

  const items = mode.implementation.map((item) => `<li>${item}</li>`).join("");
  const action = `
    <a class="button button--primary button--wide" href="#/play/${mode.id}">
      Rozpocznij grę <span aria-hidden="true">→</span>
    </a>
    <p class="build-card__note">${getContentSummary(mode.id)}. Wynik rundy zapisze się automatycznie po ukończeniu.</p>
  `;
  screen.innerHTML = `
    <a class="back-link" href="#/home">← Wszystkie tryby</a>
    <section class="mode-hero mode-hero--${mode.accent}">
      <span class="mode-hero__icon" aria-hidden="true">${mode.icon}</span>
      <p class="eyebrow">${mode.eyebrow}</p>
      <h1>${mode.name}</h1>
      <p>${mode.description}</p>
      <div class="mode-hero__meta"><strong>+${mode.reward} pkt</strong><span>${mode.plannedContent}</span></div>
    </section>
    <section class="build-card">
      <div class="build-card__step"><span>03</span><p>Pełna rozgrywka gotowa</p></div>
      <h2>Co działa w tym module</h2>
      <ul>${items}</ul>
      <div class="build-card__action">${action}</div>
    </section>
  `;
  return screen;
}
