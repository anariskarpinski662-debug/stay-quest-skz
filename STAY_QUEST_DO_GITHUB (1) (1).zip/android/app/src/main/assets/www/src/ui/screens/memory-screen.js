import { createMemorySession } from "../../game/memory-session.js";
import { escapeHtml } from "../html.js";

const BOARD_OPTIONS = [
  { size: 4, name: "Rozgrzewka", detail: "4 pary • 8 kart", icon: "04" },
  { size: 6, name: "Standard", detail: "6 par • 12 kart", icon: "06" },
  { size: 8, name: "Master", detail: "8 par • cała ósemka", icon: "08" }
];

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

function renderSetup(mode, itemCount) {
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="special-setup special-setup--pink">
      <span class="special-setup__icon" aria-hidden="true">◆</span>
      <p class="eyebrow">SKZOO Memory Game</p>
      <h1 tabindex="-1">Ile par odkrywamy?</h1>
      <p>Połącz symbol członka z nazwą jego postaci SKZOO. Liczy się pamięć i jak najmniej ruchów.</p>
      <div class="round-picker">
        ${BOARD_OPTIONS.map(
          (option) => `
            <button type="button" data-action="memory-start" data-size="${option.size}">
              <span>${option.icon}</span>
              <strong>${option.name}</strong>
              <small>${option.detail}</small>
            </button>
          `
        ).join("")}
      </div>
      <p class="content-count">Dostępnych postaci: ${itemCount}. Bez limitu czasu i bez presji.</p>
    </section>
  `;
}

function cardLabel(card, index) {
  if (!card.faceUp && !card.matched) return `Zakryta karta ${index + 1}`;
  const type = card.faceType === "symbol" ? "symbol członka" : "nazwa SKZOO";
  return `${card.matched ? "Dopasowana" : "Odkryta"} karta: ${type}, ${card.value}`;
}

function renderCard(card, index) {
  const visible = card.faceUp || card.matched;
  const stateClass = card.matched ? " is-matched" : visible ? " is-revealed" : "";
  const faceClass = visible ? ` memory-card--${card.faceType}` : "";

  return `
    <button
      class="memory-card${stateClass}${faceClass}"
      type="button"
      data-action="memory-flip"
      data-card-id="${escapeHtml(card.id)}"
      aria-label="${escapeHtml(cardLabel(card, index))}"
      ${card.matched ? "disabled" : ""}
    >
      <span class="memory-card__back" aria-hidden="true">SQ</span>
      <span class="memory-card__face" aria-hidden="true">${visible ? escapeHtml(card.value) : ""}</span>
    </button>
  `;
}

function renderGame(mode, snapshot, message = "Wybierz pierwszą kartę.") {
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Zakończ rundę</a>
    <section class="memory-status" aria-label="Stan planszy">
      <div><p class="eyebrow">Plansza ${snapshot.pairCount}-parowa</p><h1 tabindex="-1">Znajdź pary SKZOO</h1></div>
      <div class="memory-status__stats">
        <span>Ruchy <strong>${snapshot.moves}</strong></span>
        <span>Pary <strong>${snapshot.pairsFound}/${snapshot.pairCount}</strong></span>
      </div>
    </section>
    <p class="memory-instruction">Symbol członka i nazwa postaci tworzą jedną parę.</p>
    <p class="sr-only" role="status" aria-live="polite">${escapeHtml(message)}</p>
    <section class="memory-grid memory-grid--${snapshot.pairCount}" aria-label="Plansza Memory">
      ${snapshot.cards.map(renderCard).join("")}
    </section>
  `;
}

function renderSummary(mode, summary) {
  const efficiency = summary.moves === summary.pairCount ? "Perfekcyjna pamięć!" : "Wszystkie pary odnalezione!";
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="memory-summary">
      <span class="memory-summary__badge" aria-hidden="true">◆</span>
      <p class="eyebrow">Plansza ukończona</p>
      <h1 tabindex="-1">${efficiency}</h1>
      <p>Wszystkie symbole połączyły się z właściwymi nazwami SKZOO.</p>
      <div class="memory-summary__score"><span>Wynik</span><strong>${summary.score} pkt</strong></div>
      <div class="memory-summary__stats">
        <span>Ruchy <strong>${summary.moves}</strong></span>
        <span>Pary <strong>${summary.pairsFound}/${summary.pairCount}</strong></span>
        <span>Czas <strong>${formatTime(summary.elapsedSeconds)}</strong></span>
      </div>
    </section>
    <div class="summary-actions">
      <button class="button button--primary button--wide" type="button" data-action="memory-restart">Nowa plansza</button>
      <button class="button button--secondary button--wide" type="button" data-action="memory-change-size">Zmień rozmiar</button>
    </div>
  `;
}

export function createMemoryScreen({ mode, items, onComplete = () => {}, onFeedback = () => {} }) {
  const screen = document.createElement("div");
  screen.className = "screen memory-screen";
  let session = null;
  let selectedSize = 6;
  let mismatchTimer = null;

  function clearMismatchTimer() {
    if (mismatchTimer) window.clearTimeout(mismatchTimer);
    mismatchTimer = null;
  }

  function renderSetupScreen() {
    clearMismatchTimer();
    session = null;
    screen.innerHTML = renderSetup(mode, items.length);
    requestAnimationFrame(() => screen.querySelector("h1")?.focus({ preventScroll: true }));
  }

  function renderActive(snapshot = session.getSnapshot(), message, focusId = null) {
    screen.innerHTML = renderGame(mode, snapshot, message);
    const requestedCard = focusId
      ? screen.querySelector(`[data-card-id="${focusId}"]:not([disabled])`)
      : null;
    const focusTarget = requestedCard ?? screen.querySelector(".memory-card:not([disabled])") ?? screen.querySelector(".memory-status h1");
    requestAnimationFrame(() => focusTarget?.focus({ preventScroll: true }));
  }

  function start(size) {
    clearMismatchTimer();
    selectedSize = size;
    session = createMemorySession({ items, pairCount: size });
    renderActive();
  }

  screen.addEventListener("click", (event) => {
    const actionTarget = event.target.closest("[data-action]");
    const action = actionTarget?.dataset.action;
    if (!action) return;

    if (action === "memory-start") {
      onFeedback("tap");
      start(Number(actionTarget.dataset.size));
    }
    if (action === "memory-flip" && session) {
      const cardId = actionTarget.dataset.cardId;
      const response = session.flip(cardId);
      const messages = {
        first: "Pierwsza karta odkryta. Wybierz drugą.",
        match: "Para znaleziona!",
        mismatch: "To nie jest para. Zapamiętaj obie karty."
      };

      if (response.snapshot.status === "complete") {
        const summary = session.getSummary();
        onComplete({
          modeId: mode.id,
          kind: "memory",
          score: summary.score,
          accuracy: Math.round((summary.pairCount / summary.moves) * 100),
          details: {
            pairCount: summary.pairCount,
            moves: summary.moves,
            elapsedSeconds: summary.elapsedSeconds
          }
        });
        screen.innerHTML = renderSummary(mode, summary);
        requestAnimationFrame(() => screen.querySelector(".memory-summary h1")?.focus({ preventScroll: true }));
        return;
      }

      onFeedback(response.type === "match" ? "match" : response.type === "mismatch" ? "wrong" : "tap");
      renderActive(response.snapshot, messages[response.type], cardId);
      if (response.type === "mismatch") {
        const activeSession = session;
        mismatchTimer = window.setTimeout(() => {
          mismatchTimer = null;
          if (!screen.isConnected || session !== activeSession) return;
          const snapshot = session.concealMismatch();
          renderActive(snapshot, "Karty ponownie zakryte.");
        }, 850);
      }
    }
    if (action === "memory-restart") {
      onFeedback("tap");
      start(selectedSize);
    }
    if (action === "memory-change-size") {
      onFeedback("tap");
      renderSetupScreen();
    }
  });

  renderSetupScreen();
  return screen;
}
