import { GAME_MODES } from "../data/game-modes.js";
import { ACHIEVEMENTS } from "../data/achievements.js";
import { applyGameResult, getLevelInfo } from "../game/progress.js";

export const STORAGE_KEY = "stay-quest-state-v1";
export const STATE_VERSION = 3;

const MODE_IDS = new Set(GAME_MODES.map(({ id }) => id));
const ACHIEVEMENT_IDS = new Set(ACHIEVEMENTS.map(({ id }) => id));
const TEXT_SCALES = new Set(["small", "standard", "large"]);

function emptyRecord() {
  return {
    plays: 0,
    bestScore: 0,
    bestAccuracy: 0,
    bestStreak: 0,
    lastScore: 0,
    lastAccuracy: 0,
    lastPlayedAt: null,
    bestMovesBySize: {},
    bestTimeBySize: {},
    largestPerfectRound: 0
  };
}

function emptyRecords() {
  return Object.fromEntries(GAME_MODES.map(({ id }) => [id, emptyRecord()]));
}

export function createInitialState() {
  return {
    schemaVersion: STATE_VERSION,
    player: {
      displayName: "STAY",
      totalPoints: 0,
      level: 1,
      rank: "Baby STAY",
      currentStreak: 0,
      bestStreak: 0
    },
    stats: {
      gamesPlayed: 0,
      correctAnswers: 0,
      totalAnswers: 0,
      perfectQuizRounds: 0,
      perfectTimelineRounds: 0,
      perfectMemoryRounds: 0,
      completedModes: []
    },
    records: emptyRecords(),
    achievements: { unlocked: [] },
    history: [],
    settings: {
      soundEnabled: true,
      hapticsEnabled: true,
      reducedMotion: false,
      highContrast: false,
      textScale: "standard"
    }
  };
}

function safeInteger(value, fallback = 0) {
  return Number.isInteger(value) && value >= 0 ? value : fallback;
}

function safePercentage(value, fallback = 0) {
  return Number.isFinite(value) && value >= 0 && value <= 100 ? Math.round(value) : fallback;
}

function safeDate(value) {
  if (typeof value !== "string" || Number.isNaN(Date.parse(value))) return null;
  return new Date(value).toISOString();
}

function safeName(value) {
  const normalized = String(value ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 24);
  return normalized || "STAY";
}

function safeSizeMap(value) {
  if (!value || typeof value !== "object") return {};
  return Object.fromEntries(
    ["4", "6", "8"]
      .filter((key) => Number.isInteger(value[key]) && value[key] >= 0)
      .map((key) => [key, value[key]])
  );
}

function sanitizeRecord(value) {
  const initial = emptyRecord();
  if (!value || typeof value !== "object") return initial;
  return {
    plays: safeInteger(value.plays),
    bestScore: safeInteger(value.bestScore),
    bestAccuracy: safePercentage(value.bestAccuracy),
    bestStreak: safeInteger(value.bestStreak),
    lastScore: safeInteger(value.lastScore),
    lastAccuracy: safePercentage(value.lastAccuracy),
    lastPlayedAt: safeDate(value.lastPlayedAt),
    bestMovesBySize: safeSizeMap(value.bestMovesBySize),
    bestTimeBySize: safeSizeMap(value.bestTimeBySize),
    largestPerfectRound: [0, 4, 6, 8].includes(value.largestPerfectRound) ? value.largestPerfectRound : 0
  };
}

function sanitizeHistory(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((entry) => entry && MODE_IDS.has(entry.modeId) && ["quiz", "timeline", "memory"].includes(entry.kind))
    .map((entry, index) => ({
      id: String(entry.id ?? `history-${index}`).slice(0, 120),
      modeId: entry.modeId,
      kind: entry.kind,
      score: safeInteger(entry.score),
      accuracy: safePercentage(entry.accuracy),
      completedAt: safeDate(entry.completedAt) ?? new Date(0).toISOString(),
      details: entry.details && typeof entry.details === "object" ? structuredClone(entry.details) : {}
    }))
    .slice(0, 30);
}

export function sanitizeState(value) {
  const initial = createInitialState();
  if (!value || typeof value !== "object") return initial;

  const totalPoints = safeInteger(value.player?.totalPoints);
  const levelInfo = getLevelInfo(totalPoints);
  const completedModes = Array.isArray(value.stats?.completedModes)
    ? [...new Set(value.stats.completedModes.filter((id) => MODE_IDS.has(id)))]
    : [];
  const unlocked = Array.isArray(value.achievements?.unlocked)
    ? value.achievements.unlocked
        .filter((entry) => entry && ACHIEVEMENT_IDS.has(entry.id))
        .filter((entry, index, entries) => entries.findIndex(({ id }) => id === entry.id) === index)
        .map((entry) => ({ id: entry.id, unlockedAt: safeDate(entry.unlockedAt) ?? new Date(0).toISOString() }))
    : [];

  return {
    schemaVersion: STATE_VERSION,
    player: {
      displayName: safeName(value.player?.displayName),
      totalPoints,
      level: levelInfo.level,
      rank: levelInfo.rank,
      currentStreak: safeInteger(value.player?.currentStreak),
      bestStreak: safeInteger(value.player?.bestStreak ?? value.player?.currentStreak)
    },
    stats: {
      gamesPlayed: safeInteger(value.stats?.gamesPlayed),
      correctAnswers: safeInteger(value.stats?.correctAnswers),
      totalAnswers: safeInteger(value.stats?.totalAnswers),
      perfectQuizRounds: safeInteger(value.stats?.perfectQuizRounds),
      perfectTimelineRounds: safeInteger(value.stats?.perfectTimelineRounds),
      perfectMemoryRounds: safeInteger(value.stats?.perfectMemoryRounds),
      completedModes
    },
    records: Object.fromEntries(
      GAME_MODES.map(({ id }) => [id, sanitizeRecord(value.records?.[id])])
    ),
    achievements: { unlocked },
    history: sanitizeHistory(value.history),
    settings: {
      soundEnabled: typeof value.settings?.soundEnabled === "boolean" ? value.settings.soundEnabled : initial.settings.soundEnabled,
      hapticsEnabled: typeof value.settings?.hapticsEnabled === "boolean" ? value.settings.hapticsEnabled : initial.settings.hapticsEnabled,
      reducedMotion: typeof value.settings?.reducedMotion === "boolean" ? value.settings.reducedMotion : initial.settings.reducedMotion,
      highContrast: typeof value.settings?.highContrast === "boolean" ? value.settings.highContrast : initial.settings.highContrast,
      textScale: TEXT_SCALES.has(value.settings?.textScale) ? value.settings.textScale : initial.settings.textScale
    }
  };
}

function readSavedState(storage) {
  try {
    const raw = storage?.getItem(STORAGE_KEY);
    return raw ? sanitizeState(JSON.parse(raw)) : createInitialState();
  } catch {
    return createInitialState();
  }
}

function getDefaultStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}

export function createStore(options = {}) {
  const storage = options.storage === undefined ? getDefaultStorage() : options.storage;
  const now = options.now ?? (() => new Date());
  let state = readSavedState(storage);
  const listeners = new Set();

  function getState() {
    return structuredClone(state);
  }

  function persist() {
    try {
      storage?.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch {
      return false;
    }
  }

  function notify() {
    const snapshot = getState();
    listeners.forEach((listener) => listener(snapshot));
  }

  function replaceState(nextState) {
    state = sanitizeState(nextState);
    const saved = persist();
    notify();
    return { state: getState(), saved };
  }

  function setState(updater) {
    const nextState = typeof updater === "function" ? updater(getState()) : updater;
    return replaceState(nextState);
  }

  function updateProfile(displayName) {
    return replaceState({
      ...state,
      player: { ...state.player, displayName: safeName(displayName) }
    });
  }

  function updateSettings(changes) {
    return replaceState({
      ...state,
      settings: { ...state.settings, ...(changes ?? {}) }
    });
  }

  function recordResult(result) {
    const applied = applyGameResult(state, result, { now });
    state = sanitizeState(applied.state);
    const saved = persist();
    notify();
    return { state: getState(), newlyUnlocked: applied.newlyUnlocked, saved };
  }

  function exportBackup() {
    return JSON.stringify(
      {
        appId: "stay-quest",
        schemaVersion: STATE_VERSION,
        exportedAt: new Date(now()).toISOString(),
        state: getState()
      },
      null,
      2
    );
  }

  function importBackup(text) {
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new TypeError("Plik nie zawiera poprawnej kopii JSON.");
    }
    if (parsed?.appId && parsed.appId !== "stay-quest") throw new TypeError("To nie jest kopia STAY QUEST.");
    const importedState = parsed?.state ?? parsed;
    if (!importedState?.player || !importedState?.settings) throw new TypeError("Kopia nie zawiera wymaganego stanu gry.");
    return replaceState(importedState);
  }

  function reset() {
    return replaceState(createInitialState());
  }

  function subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  return {
    getState,
    setState,
    updateProfile,
    updateSettings,
    recordResult,
    exportBackup,
    importBackup,
    reset,
    subscribe
  };
}
