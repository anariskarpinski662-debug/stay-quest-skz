const DIFFICULTY_STEP = 0.15;
const MAX_STREAK_BONUS = 40;
const STREAK_BONUS_STEP = 10;
const HINT_PENALTY_RATE = 0.25;

export function calculateQuestionScore({
  correct,
  basePoints,
  difficulty,
  currentStreak = 0,
  hintUsed = false,
  extraPenalty = 0
}) {
  if (!Number.isInteger(basePoints) || basePoints <= 0) throw new RangeError("Nieprawidłowa liczba punktów bazowych.");
  if (!Number.isInteger(difficulty) || difficulty < 1 || difficulty > 5) throw new RangeError("Nieprawidłowa trudność.");
  if (!Number.isInteger(currentStreak) || currentStreak < 0) throw new RangeError("Nieprawidłowa seria odpowiedzi.");
  if (!Number.isInteger(extraPenalty) || extraPenalty < 0) throw new RangeError("Nieprawidłowa dodatkowa kara.");

  if (!correct) {
    return {
      total: 0,
      basePoints: 0,
      difficultyBonus: 0,
      streakBonus: 0,
      hintPenalty: 0,
      revealPenalty: 0,
      nextStreak: 0
    };
  }

  const nextStreak = currentStreak + 1;
  const adjustedBase = Math.round(basePoints * (1 + (difficulty - 1) * DIFFICULTY_STEP));
  const difficultyBonus = adjustedBase - basePoints;
  const streakBonus = Math.min(Math.max(nextStreak - 1, 0) * STREAK_BONUS_STEP, MAX_STREAK_BONUS);
  const subtotal = adjustedBase + streakBonus;
  const hintPenalty = hintUsed ? Math.round(subtotal * HINT_PENALTY_RATE) : 0;
  const revealPenalty = Math.min(extraPenalty, subtotal - hintPenalty);

  return {
    total: subtotal - hintPenalty - revealPenalty,
    basePoints,
    difficultyBonus,
    streakBonus,
    hintPenalty,
    revealPenalty,
    nextStreak
  };
}
