import { ACHIEVEMENTS } from "../data/achievements.js";

export const POINTS_PER_LEVEL = 2500;

const RANKS = Object.freeze([
  { minLevel: 1, name: "Baby STAY" },
  { minLevel: 2, name: "Rookie STAY" },
  { minLevel: 3, name: "Core STAY" },
  { minLevel: 5, name: "Master STAY" },
  { minLevel: 8, name: "Legend STAY" }
]);

const VALID_MODE_IDS = new Set([
  "assoc-master",
  "emoji-guesser",
  "timeline",
  "hardcore-lore",
  "skzoo-memory"
]);

function clone(value) {
  return structuredClone(value);
}

function asNonNegativeInteger(value, label) {
  if (!Number.isInteger(value) || value < 0) throw new RangeError(`${label} musi być nieujemną liczbą całkowitą.`);
  return value;
}

function asAccuracy(value) {
  if (!Number.isFinite(value) || value < 0 || value > 100) throw new RangeError("Skuteczność musi mieścić się w zakresie 0–100.");
  return Math.round(value);
}

function toIsoDate(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) throw new TypeError("Nieprawidłowa data ukończenia rundy.");
  return date.toISOString();
}

function validateResultDetails(result) {
  const details = result.details ?? {};
  if (!details || typeof details !== "object") throw new TypeError("Szczegóły wyniku mają nieprawidłowy format.");

  if (result.kind === "quiz") {
    const correctAnswers = asNonNegativeInteger(result.correctAnswers ?? 0, "Liczba poprawnych odpowiedzi");
    const totalQuestions = asNonNegativeInteger(result.totalQuestions ?? 0, "Liczba pytań");
    asNonNegativeInteger(result.longestStreak ?? 0, "Najlepsza seria");
    asNonNegativeInteger(result.currentStreak ?? 0, "Bieżąca seria");
    if (correctAnswers > totalQuestions) throw new RangeError("Liczba poprawnych odpowiedzi nie może przekraczać liczby pytań.");
  }

  if (result.kind === "timeline") {
    if (![4, 6, 8].includes(details.roundSize)) throw new RangeError("Nieprawidłowy rozmiar rundy Timeline.");
    if (typeof details.perfect !== "boolean") throw new TypeError("Wynik Timeline nie określa perfekcyjnej rundy.");
  }

  if (result.kind === "memory") {
    if (![4, 6, 8].includes(details.pairCount)) throw new RangeError("Nieprawidłowy rozmiar planszy Memory.");
    asNonNegativeInteger(details.moves, "Liczba ruchów");
    asNonNegativeInteger(details.elapsedSeconds, "Czas rundy");
    if (details.moves < details.pairCount) throw new RangeError("Liczba ruchów nie może być mniejsza od liczby par.");
  }
}

export function getLevelInfo(totalPoints) {
  const safePoints = Math.max(0, Math.floor(Number(totalPoints) || 0));
  const level = Math.floor(safePoints / POINTS_PER_LEVEL) + 1;
  const rank = [...RANKS].reverse().find(({ minLevel }) => level >= minLevel)?.name ?? RANKS[0].name;
  const pointsInLevel = safePoints % POINTS_PER_LEVEL;

  return {
    level,
    rank,
    pointsInLevel,
    pointsToNextLevel: POINTS_PER_LEVEL - pointsInLevel,
    progress: Math.round((pointsInLevel / POINTS_PER_LEVEL) * 100)
  };
}

export function getAchievementMetric(state, metric) {
  if (metric === "gamesPlayed") return state.stats.gamesPlayed;
  if (metric === "totalPoints") return state.player.totalPoints;
  if (metric === "bestStreak") return state.player.bestStreak;
  if (metric === "perfectQuizRounds") return state.stats.perfectQuizRounds;
  if (metric === "perfectTimelineRounds") return state.stats.perfectTimelineRounds;
  if (metric === "perfectMemoryRounds") return state.stats.perfectMemoryRounds;
  if (metric === "completedModes") return state.stats.completedModes.length;
  if (metric === "correctAnswers") return state.stats.correctAnswers;
  return 0;
}

export function getAchievementProgress(state, achievement) {
  const current = Math.min(getAchievementMetric(state, achievement.metric), achievement.target);
  return {
    current,
    target: achievement.target,
    percentage: Math.round((current / achievement.target) * 100)
  };
}

function unlockEligibleAchievements(state, completedAt) {
  const unlockedIds = new Set(state.achievements.unlocked.map(({ id }) => id));
  const newlyUnlocked = ACHIEVEMENTS.filter(
    (achievement) => !unlockedIds.has(achievement.id) && getAchievementMetric(state, achievement.metric) >= achievement.target
  );

  state.achievements.unlocked.push(
    ...newlyUnlocked.map(({ id }) => ({ id, unlockedAt: completedAt }))
  );
  return newlyUnlocked.map(({ id }) => id);
}

function updateSpecialRecords(record, result) {
  const next = clone(record);
  if (result.kind === "memory") {
    const size = String(result.details.pairCount);
    const previousMoves = next.bestMovesBySize?.[size];
    const previousTime = next.bestTimeBySize?.[size];
    next.bestMovesBySize = {
      ...(next.bestMovesBySize ?? {}),
      [size]: previousMoves == null ? result.details.moves : Math.min(previousMoves, result.details.moves)
    };
    next.bestTimeBySize = {
      ...(next.bestTimeBySize ?? {}),
      [size]: previousTime == null ? result.details.elapsedSeconds : Math.min(previousTime, result.details.elapsedSeconds)
    };
  }
  if (result.kind === "timeline" && result.details.perfect) {
    next.largestPerfectRound = Math.max(next.largestPerfectRound ?? 0, result.details.roundSize);
  }
  return next;
}

export function applyGameResult(currentState, result, { now = () => new Date() } = {}) {
  if (!result || typeof result !== "object") throw new TypeError("Brakuje wyniku rundy.");
  if (!VALID_MODE_IDS.has(result.modeId)) throw new TypeError("Wynik pochodzi z nieznanego trybu.");
  if (!["quiz", "timeline", "memory"].includes(result.kind)) throw new TypeError("Nieznany rodzaj wyniku.");

  const score = asNonNegativeInteger(result.score, "Wynik");
  const accuracy = asAccuracy(result.accuracy);
  validateResultDetails(result);
  const completedAt = toIsoDate(now());
  const state = clone(currentState);
  const existingRecord = state.records[result.modeId];
  if (!existingRecord) throw new TypeError("Brakuje rekordu wybranego trybu.");
  const record = updateSpecialRecords(existingRecord, result);

  record.plays += 1;
  record.bestScore = Math.max(record.bestScore, score);
  record.bestAccuracy = Math.max(record.bestAccuracy, accuracy);
  record.lastScore = score;
  record.lastAccuracy = accuracy;
  record.lastPlayedAt = completedAt;
  record.bestStreak = Math.max(record.bestStreak, result.longestStreak ?? 0);
  state.records[result.modeId] = record;

  state.player.totalPoints += score;
  state.player.bestStreak = Math.max(state.player.bestStreak, result.longestStreak ?? 0);
  if (result.kind === "quiz") state.player.currentStreak = result.currentStreak ?? 0;
  const levelInfo = getLevelInfo(state.player.totalPoints);
  state.player.level = levelInfo.level;
  state.player.rank = levelInfo.rank;

  state.stats.gamesPlayed += 1;
  state.stats.correctAnswers += result.correctAnswers ?? 0;
  state.stats.totalAnswers += result.totalQuestions ?? 0;
  if (!state.stats.completedModes.includes(result.modeId)) state.stats.completedModes.push(result.modeId);
  if (result.kind === "quiz" && accuracy === 100) state.stats.perfectQuizRounds += 1;
  if (result.kind === "timeline" && result.details.perfect) state.stats.perfectTimelineRounds += 1;
  if (result.kind === "memory" && result.details.moves === result.details.pairCount) state.stats.perfectMemoryRounds += 1;

  state.history.unshift({
    id: `${completedAt}-${result.modeId}-${state.stats.gamesPlayed}`,
    modeId: result.modeId,
    kind: result.kind,
    score,
    accuracy,
    completedAt,
    details: clone(result.details ?? {})
  });
  state.history = state.history.slice(0, 30);

  const newlyUnlocked = unlockEligibleAchievements(state, completedAt);
  return { state, newlyUnlocked };
}
