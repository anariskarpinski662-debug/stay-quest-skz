import {
  QUESTION_TYPES,
  getCorrectAnswerLabel,
  isAnswerCorrect,
  validateQuestionBank
} from "./question-schema.js";
import { sampleWithoutReplacement, shuffle } from "./random.js";
import { calculateQuestionScore } from "./scoring.js";

function clone(value) {
  return structuredClone(value);
}

function prepareQuestion(question, random) {
  const prepared = clone(question);
  if (prepared.type === QUESTION_TYPES.SINGLE_CHOICE) prepared.options = shuffle(prepared.options, random);
  return prepared;
}

function createPublicQuestion(question, revealedClueCount) {
  const allClues = question.clues ?? [];
  const visibleCount = Math.min(revealedClueCount, allClues.length);
  return {
    id: question.id,
    modeId: question.modeId,
    type: question.type,
    prompt: question.prompt,
    category: question.category,
    kind: question.kind,
    difficulty: question.difficulty,
    basePoints: question.basePoints,
    clues: clone(allClues.slice(0, visibleCount)),
    totalClues: allClues.length,
    canRevealClue: visibleCount < allClues.length,
    revealPenaltyPerClue: question.cluePolicy?.penaltyPerReveal ?? 0,
    options: clone(question.options ?? []),
    hasHint: Boolean(question.hint)
  };
}

function validateSubmittedAnswer(question, answer) {
  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    if (!question.options.some(({ id }) => id === answer)) throw new TypeError("Wybierz jedną z dostępnych odpowiedzi.");
    return;
  }

  if (question.type === QUESTION_TYPES.TEXT && !String(answer ?? "").trim()) {
    throw new TypeError("Wpisz odpowiedź przed sprawdzeniem.");
  }
}

export function createQuizSession({ modeId, questions, questionCount = questions?.length, random = Math.random }) {
  const validation = validateQuestionBank(questions);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (!modeId || typeof modeId !== "string") throw new TypeError("Sesja wymaga identyfikatora trybu.");
  if (questions.some((question) => question.modeId !== modeId)) {
    throw new TypeError("Bank sesji zawiera pytanie z innego trybu.");
  }
  if (!Number.isInteger(questionCount) || questionCount < 1) throw new RangeError("Sesja wymaga co najmniej jednego pytania.");

  const selectedQuestions = sampleWithoutReplacement(questions, questionCount, random).map((question) =>
    prepareQuestion(question, random)
  );

  let index = 0;
  let status = "active";
  let score = 0;
  let currentStreak = 0;
  let longestStreak = 0;
  let hintUsed = false;
  let revealedHint = null;
  let revealedClueCount = selectedQuestions[0].cluePolicy?.initialVisible ?? selectedQuestions[0].clues?.length ?? 0;
  let cluePenalty = 0;
  let lastResult = null;
  const history = [];

  function currentQuestion() {
    return selectedQuestions[index] ?? null;
  }

  function getSnapshot() {
    const question = status === "complete" ? null : currentQuestion();
    return {
      modeId,
      status,
      score,
      currentStreak,
      longestStreak,
      correctAnswers: history.filter(({ correct }) => correct).length,
      answeredQuestions: history.length,
      questionNumber: status === "complete" ? selectedQuestions.length : index + 1,
      totalQuestions: selectedQuestions.length,
      currentQuestion: question ? createPublicQuestion(question, revealedClueCount) : null,
      revealedHint,
      cluePenalty,
      lastResult: lastResult ? clone(lastResult) : null
    };
  }

  function useHint() {
    if (status !== "active") throw new Error("Podpowiedź można odsłonić tylko przed odpowiedzią.");
    const question = currentQuestion();
    if (!question.hint) return null;

    hintUsed = true;
    revealedHint = question.hint;
    return revealedHint;
  }

  function revealClue() {
    if (status !== "active") throw new Error("Trop można odsłonić tylko przed odpowiedzią.");
    const question = currentQuestion();
    const clues = question.clues ?? [];
    if (revealedClueCount >= clues.length) return null;

    const clueIndex = revealedClueCount;
    revealedClueCount += 1;
    const penalty = question.cluePolicy?.penaltyPerReveal ?? 0;
    cluePenalty += penalty;

    return {
      clue: clues[clueIndex],
      clueIndex,
      penalty,
      remaining: clues.length - revealedClueCount
    };
  }

  function finalizeAnswer(answer, skipped = false) {
    if (status !== "active") throw new Error("Na to pytanie została już udzielona odpowiedź.");
    const question = currentQuestion();
    if (!skipped) validateSubmittedAnswer(question, answer);

    const correct = skipped ? false : isAnswerCorrect(question, answer);
    const scoring = calculateQuestionScore({
      correct,
      basePoints: question.basePoints,
      difficulty: question.difficulty,
      currentStreak,
      hintUsed,
      extraPenalty: cluePenalty
    });

    currentStreak = scoring.nextStreak;
    longestStreak = Math.max(longestStreak, currentStreak);
    score += scoring.total;

    lastResult = {
      questionId: question.id,
      questionNumber: index + 1,
      submittedAnswer: skipped ? null : answer,
      correctAnswerId: question.type === QUESTION_TYPES.SINGLE_CHOICE ? question.correctOptionId : null,
      correctAnswer: getCorrectAnswerLabel(question),
      correct,
      skipped,
      earnedPoints: scoring.total,
      scoring,
      explanation: question.explanation,
      kind: question.kind,
      source: clone(question.source ?? null),
      hintUsed
    };

    history.push(clone(lastResult));
    status = "answered";
    return clone(lastResult);
  }

  function submitAnswer(answer) {
    return finalizeAnswer(answer, false);
  }

  function skip() {
    return finalizeAnswer(null, true);
  }

  function next() {
    if (status !== "answered") throw new Error("Najpierw odpowiedz na bieżące pytanie.");

    if (index >= selectedQuestions.length - 1) {
      status = "complete";
    } else {
      index += 1;
      status = "active";
      hintUsed = false;
      revealedHint = null;
      revealedClueCount = selectedQuestions[index].cluePolicy?.initialVisible ?? selectedQuestions[index].clues?.length ?? 0;
      cluePenalty = 0;
      lastResult = null;
    }

    return getSnapshot();
  }

  function getSummary() {
    const answeredQuestions = history.length;
    const correctAnswers = history.filter(({ correct }) => correct).length;

    return {
      modeId,
      status,
      score,
      totalQuestions: selectedQuestions.length,
      answeredQuestions,
      correctAnswers,
      incorrectAnswers: answeredQuestions - correctAnswers,
      accuracy: answeredQuestions === 0 ? 0 : Math.round((correctAnswers / answeredQuestions) * 100),
      currentStreak,
      longestStreak,
      history: clone(history)
    };
  }

  return { getSnapshot, getSummary, useHint, revealClue, submitAnswer, skip, next };
}
