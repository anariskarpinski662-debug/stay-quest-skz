export const MEMBER_SYMBOLS = Object.freeze([
  { id: "bang-chan", name: "Bang Chan", skzoo: "Wolf Chan", emoji: "🐺" },
  { id: "lee-know", name: "Lee Know", skzoo: "Leebit", emoji: "🐰" },
  { id: "changbin", name: "Changbin", skzoo: "Dwaekki", emoji: "🐷🐰" },
  { id: "hyunjin", name: "Hyunjin", skzoo: "Jiniret", emoji: "🦙" },
  { id: "han", name: "Han", skzoo: "HAN QUOKKA", emoji: "🐿️" },
  { id: "felix", name: "Felix", skzoo: "BbokAri", emoji: "🐥" },
  { id: "seungmin", name: "Seungmin", skzoo: "PuppyM", emoji: "🐶" },
  { id: "i-n", name: "I.N", skzoo: "FoxI.Ny", emoji: "🦊" }
]);

export const MEMBER_EMOJI_LINE = MEMBER_SYMBOLS.map(({ emoji }) => emoji).join(" ");
