const staticContent = {
  "not-found": {
    icon: "?",
    eyebrow: "Zagubiona karta",
    title: "Nie znaleziono ekranu",
    copy: "Ten adres nie prowadzi do żadnej części STAY QUEST.",
    step: "Wróć na ekran główny."
  }
};

export function createStaticScreen(name) {
  const content = staticContent[name] || staticContent["not-found"];
  const screen = document.createElement("div");
  screen.className = "screen";
  screen.innerHTML = `
    <section class="empty-state">
      <span aria-hidden="true">${content.icon}</span>
      <p class="eyebrow">${content.eyebrow}</p>
      <h1>${content.title}</h1>
      <p>${content.copy}</p>
      <small>${content.step}</small>
      <a class="button button--secondary" href="#/home">Wróć do gry</a>
    </section>
  `;
  return screen;
}
