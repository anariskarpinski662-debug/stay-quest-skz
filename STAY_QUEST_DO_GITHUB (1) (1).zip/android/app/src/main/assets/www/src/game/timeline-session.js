import { sampleWithoutReplacement, shuffle } from "./random.js";

function clone(value) {
  return structuredClone(value);
}

function isValidDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

export function validateTimelineEvents(events) {
  const errors = [];
  if (!Array.isArray(events) || events.length < 2) return { valid: false, errors: ["Oś czasu wymaga co najmniej dwóch wydarzeń."] };

  const ids = new Set();
  for (const [index, event] of events.entries()) {
    if (!event?.id || !event?.title || !event?.description || !event?.era) errors.push(`Wydarzenie ${index + 1} ma niepełne dane.`);
    if (!isValidDate(event?.date)) errors.push(`Wydarzenie ${index + 1} ma nieprawidłową datę.`);
    if (ids.has(event?.id)) errors.push(`Powtórzony identyfikator wydarzenia: ${event.id}.`);
    ids.add(event?.id);
    if (!event?.source?.title || !/^https?:\/\//.test(event?.source?.url) || !isValidDate(event?.source?.checkedAt)) {
      errors.push(`Wydarzenie ${index + 1} nie ma poprawnego źródła.`);
    }
  }

  return { valid: errors.length === 0, errors };
}

function publicEvent(event) {
  return { id: event.id, title: event.title, description: event.description, era: event.era };
}

export function createTimelineSession({ events, roundSize = 6, random = Math.random }) {
  const validation = validateTimelineEvents(events);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (![4, 6, 8].includes(roundSize)) throw new RangeError("Dozwolone rundy mają 4, 6 albo 8 wydarzeń.");
  if (roundSize > events.length) throw new RangeError("Bank nie zawiera wystarczającej liczby wydarzeń.");

  const selected = sampleWithoutReplacement(events, roundSize, random);
  const correctOrder = [...selected].sort((a, b) => a.date.localeCompare(b.date));
  let userOrder = shuffle(selected, random);
  if (userOrder.every((event, index) => event.id === correctOrder[index].id)) {
    userOrder = [...userOrder.slice(1), userOrder[0]];
  }
  let status = "active";
  let result = null;

  function getSnapshot() {
    return {
      status,
      roundSize,
      events: userOrder.map(publicEvent),
      result: result ? clone(result) : null
    };
  }

  function setOrder(ids) {
    if (status !== "active") throw new Error("Ta runda została już sprawdzona.");
    if (!Array.isArray(ids) || ids.length !== userOrder.length || new Set(ids).size !== ids.length) {
      throw new TypeError("Nowa kolejność musi zawierać wszystkie wydarzenia dokładnie raz.");
    }
    const byId = new Map(userOrder.map((event) => [event.id, event]));
    if (ids.some((id) => !byId.has(id))) throw new TypeError("Nowa kolejność zawiera nieznane wydarzenie.");
    userOrder = ids.map((id) => byId.get(id));
    return getSnapshot();
  }

  function move(eventId, direction) {
    if (![-1, 1].includes(direction)) throw new RangeError("Kierunek przesunięcia musi wynosić -1 albo 1.");
    const currentIndex = userOrder.findIndex(({ id }) => id === eventId);
    if (currentIndex === -1) throw new TypeError("Nie znaleziono wydarzenia.");
    const targetIndex = currentIndex + direction;
    if (targetIndex < 0 || targetIndex >= userOrder.length) return getSnapshot();
    const ids = userOrder.map(({ id }) => id);
    [ids[currentIndex], ids[targetIndex]] = [ids[targetIndex], ids[currentIndex]];
    return setOrder(ids);
  }

  function check() {
    if (status !== "active") throw new Error("Ta runda została już sprawdzona.");
    const correctPositions = userOrder.filter((event, index) => event.id === correctOrder[index].id).length;
    const perfect = correctPositions === roundSize;
    const score = correctPositions * 100 + (perfect ? roundSize * 50 : 0);

    result = {
      perfect,
      score,
      correctPositions,
      total: roundSize,
      accuracy: Math.round((correctPositions / roundSize) * 100),
      correctOrder: correctOrder.map((event, index) => ({
        ...clone(event),
        correctPosition: index + 1,
        userPosition: userOrder.findIndex(({ id }) => id === event.id) + 1
      }))
    };
    status = "complete";
    return clone(result);
  }

  return { getSnapshot, setOrder, move, check };
}
