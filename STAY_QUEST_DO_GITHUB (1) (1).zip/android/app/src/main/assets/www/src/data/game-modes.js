export const GAME_MODES = Object.freeze([
  {
    id: "assoc-master",
    name: "Mistrz Skojarzeń",
    shortName: "Skojarzenia",
    eyebrow: "Symbole • rekwizyty • cytaty",
    description: "Rozpoznaj utwór albo członka po zestawie celnych tropów.",
    icon: "✦",
    accent: "lime",
    reward: 150,
    plannedContent: "32 zagadki • runda 10",
    implementation: [
      "dwie kategorie: utwory oraz członkowie i SKZOO",
      "tropy odsłaniane pojedynczo",
      "premia za odpowiedź przy mniejszej liczbie tropów"
    ]
  },
  {
    id: "emoji-guesser",
    name: "Zgadnij Utwór po Emoji",
    shortName: "Emoji",
    eyebrow: "Tytuł • tekst • klimat",
    description: "Odczytaj zakodowany w emoji tytuł, motyw albo charakter utworu.",
    icon: "🧩",
    accent: "cyan",
    reward: 100,
    plannedContent: "26 zagadek • runda 10",
    implementation: [
      "rosnące poziomy trudności",
      "odpowiedzi wpisywane z tolerancją zapisu",
      "wyjaśnienie znaczenia każdego symbolu"
    ]
  },
  {
    id: "timeline",
    name: "SKZ Timeline Architect",
    shortName: "Oś czasu",
    eyebrow: "Historia • ery • osiągnięcia",
    description: "Ułóż wydarzenia w poprawnej kolejności i zbuduj historię zespołu.",
    icon: "⌛",
    accent: "violet",
    reward: 150,
    plannedContent: "30 wydarzeń • 3 rundy",
    implementation: [
      "rundy po 4, 6 i 8 wydarzeń",
      "przeciąganie kart palcem",
      "daty i kontekst ujawniane po sprawdzeniu"
    ]
  },
  {
    id: "hardcore-lore",
    name: "Hardcore Lore Quiz",
    shortName: "Lore",
    eyebrow: "Poziom Master STAY",
    description: "Najtrudniejsze pytania o dyskografię, historię, unity i oficjalne materiały.",
    icon: "⚡",
    accent: "coral",
    reward: 200,
    plannedContent: "29 pytań • runda 10",
    implementation: [
      "zweryfikowana pula i losowanie pytań",
      "serie bezbłędnych odpowiedzi",
      "źródło i ciekawostka przy każdym rozwiązaniu"
    ]
  },
  {
    id: "skzoo-memory",
    name: "SKZOO Memory Game",
    shortName: "Memory",
    eyebrow: "Refleks • pamięć • SKZOO",
    description: "Odkrywaj karty i łącz osiem par postaci SKZOO w jak najmniejszej liczbie ruchów.",
    icon: "◆",
    accent: "pink",
    reward: 100,
    plannedContent: "8 postaci • 3 plansze",
    implementation: [
      "plansze łatwa, normalna i mistrzowska",
      "licznik ruchów bez presji czasu",
      "wynik zależny od liczby wykonanych ruchów"
    ]
  }
]);

export function findGameMode(modeId) {
  return GAME_MODES.find(({ id }) => id === modeId);
}
