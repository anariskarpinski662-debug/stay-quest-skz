import { escapeHtml } from "../html.js";

function checked(value) {
  return value ? " checked" : "";
}

function renderToggle({ name, title, copy, enabled }) {
  return `
    <label class="setting-toggle">
      <span><strong>${escapeHtml(title)}</strong><small>${escapeHtml(copy)}</small></span>
      <input type="checkbox" name="${escapeHtml(name)}" data-setting${checked(enabled)} />
      <i aria-hidden="true"></i>
    </label>
  `;
}

export function createSettingsScreen({ state, onProfileSave, onSettingsChange, onPreview = () => {}, onExport, onImport, onReset }) {
  const screen = document.createElement("div");
  screen.className = "screen settings-screen";

  screen.innerHTML = `
    <section class="settings-hero">
      <span aria-hidden="true">◉</span>
      <p class="eyebrow">Profil zapisany na tym urządzeniu</p>
      <h1>Ustawienia STAY QUEST</h1>
      <p>Twój profil, wyniki i opcje zostają w aplikacji także po jej zamknięciu.</p>
    </section>

    <section class="settings-card">
      <div class="settings-card__heading"><span aria-hidden="true">01</span><div><p class="eyebrow">Profil gracza</p><h2>Jak mamy Cię wyświetlać?</h2></div></div>
      <form class="profile-form" data-form="profile">
        <label for="display-name">Nazwa gracza</label>
        <div><input id="display-name" name="displayName" type="text" maxlength="24" value="${escapeHtml(state.player.displayName)}" autocomplete="nickname" /><button class="button button--primary" type="submit">Zapisz</button></div>
        <small>Maksymalnie 24 znaki. Nazwa pojawi się na ekranie głównym i w profilu.</small>
      </form>
    </section>

    <section class="settings-card">
      <div class="settings-card__heading"><span aria-hidden="true">02</span><div><p class="eyebrow">Komfort i dostępność</p><h2>Dopasuj interfejs</h2></div></div>
      <div class="settings-list">
        ${renderToggle({ name: "soundEnabled", title: "Dźwięki interfejsu", copy: "Krótkie sygnały odpowiedzi, par i osiągnięć.", enabled: state.settings.soundEnabled })}
        ${renderToggle({ name: "hapticsEnabled", title: "Wibracje dotykowe", copy: "Delikatna reakcja telefonu, jeśli urządzenie ją obsługuje.", enabled: state.settings.hapticsEnabled })}
        ${renderToggle({ name: "reducedMotion", title: "Ogranicz animacje", copy: "Wyłącza przejścia i płynne przewijanie.", enabled: state.settings.reducedMotion })}
        ${renderToggle({ name: "highContrast", title: "Wysoki kontrast", copy: "Wzmacnia obramowania i drugoplanowy tekst.", enabled: state.settings.highContrast })}
      </div>
      <fieldset class="text-scale-picker">
        <legend>Wielkość tekstu</legend>
        ${[
          ["small", "Mniejszy", "A"],
          ["standard", "Standard", "A"],
          ["large", "Większy", "A+"]
        ].map(([value, label, sample]) => `
          <label>
            <input type="radio" name="textScale" value="${value}" data-setting${checked(state.settings.textScale === value)} />
            <span><b>${sample}</b><small>${label}</small></span>
          </label>
        `).join("")}
      </fieldset>
      <button class="button button--quiet settings-preview" type="button" data-action="settings-preview">Sprawdź dźwięk i wibrację</button>
    </section>

    <section class="settings-card">
      <div class="settings-card__heading"><span aria-hidden="true">03</span><div><p class="eyebrow">Kopia bezpieczeństwa</p><h2>Zabierz postęp ze sobą</h2></div></div>
      <p class="settings-card__copy">Eksport zapisuje profil, rekordy, historię, odznaki i ustawienia w jednym pliku JSON.</p>
      <div class="backup-actions">
        <button class="button button--secondary button--wide" type="button" data-action="settings-export">Pobierz kopię postępu</button>
        <label class="button button--secondary button--wide" for="backup-file">Wczytaj kopię z pliku</label>
        <input class="sr-only" id="backup-file" type="file" accept="application/json,.json" data-action="settings-import" />
      </div>
    </section>

    <section class="settings-card settings-card--danger">
      <div class="settings-card__heading"><span aria-hidden="true">!</span><div><p class="eyebrow">Strefa resetu</p><h2>Nowy początek</h2></div></div>
      <p class="settings-card__copy">Reset usuwa punkty, rekordy, historię i osiągnięcia z tego urządzenia. Najpierw możesz pobrać kopię.</p>
      <button class="button button--danger button--wide" type="button" data-action="settings-reset">Wyzeruj cały postęp</button>
    </section>
    <p class="settings-message" role="status" aria-live="polite" hidden></p>
  `;

  function showMessage(message, error = false) {
    const output = screen.querySelector(".settings-message");
    output.textContent = message;
    output.classList.toggle("is-error", error);
    output.hidden = false;
  }

  screen.addEventListener("submit", (event) => {
    if (event.target.dataset.form !== "profile") return;
    event.preventDefault();
    const displayName = new FormData(event.target).get("displayName");
    onProfileSave(displayName);
    showMessage("Nazwa gracza została zapisana.");
  });

  screen.addEventListener("change", async (event) => {
    const input = event.target;
    if (input.matches("[data-setting]")) {
      const value = input.type === "checkbox" ? input.checked : input.value;
      onSettingsChange({ [input.name]: value });
      showMessage("Ustawienie zapisane.");
    }
    if (input.matches('[data-action="settings-import"]') && input.files?.[0]) {
      const file = input.files[0];
      if (file.size > 2 * 1024 * 1024) {
        showMessage("Plik kopii jest zbyt duży.", true);
        input.value = "";
        return;
      }
      try {
        await onImport(await file.text());
        showMessage("Kopia postępu została wczytana.");
      } catch (error) {
        showMessage(error.message, true);
      } finally {
        input.value = "";
      }
    }
  });

  screen.addEventListener("click", (event) => {
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (action === "settings-export") {
      onExport();
      showMessage("Kopia postępu została pobrana.");
    }
    if (action === "settings-preview") onPreview();
    if (action === "settings-reset") onReset();
  });

  return screen;
}
