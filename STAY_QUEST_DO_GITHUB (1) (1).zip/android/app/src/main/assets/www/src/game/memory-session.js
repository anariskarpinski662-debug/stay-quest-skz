import { sampleWithoutReplacement, shuffle } from "./random.js";

function clone(value) {
  return structuredClone(value);
}

export function validateMemoryItems(items) {
  const errors = [];
  if (!Array.isArray(items) || items.length < 4) return { valid: false, errors: ["Memory wymaga co najmniej czterech par."] };

  const ids = new Set();
  items.forEach((item, index) => {
    if (!item?.id || !item?.skzoo || !item?.emoji) errors.push(`Para ${index + 1} ma niepełne dane.`);
    if (ids.has(item?.id)) errors.push(`Powtórzony identyfikator pary: ${item.id}.`);
    ids.add(item?.id);
  });
  return { valid: errors.length === 0, errors };
}

export function createMemorySession({ items, pairCount = 8, random = Math.random, now = Date.now }) {
  const validation = validateMemoryItems(items);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (![4, 6, 8].includes(pairCount)) throw new RangeError("Plansza może zawierać 4, 6 albo 8 par.");
  if (pairCount > items.length) throw new RangeError("Brakuje postaci do utworzenia planszy.");

  const selected = sampleWithoutReplacement(items, pairCount, random);
  const cards = shuffle(
    selected.flatMap((item) => [
      {
        id: `${item.id}-symbol`,
        pairId: item.id,
        faceType: "symbol",
        value: item.emoji,
        matched: false,
        faceUp: false
      },
      {
        id: `${item.id}-name`,
        pairId: item.id,
        faceType: "name",
        value: item.skzoo,
        matched: false,
        faceUp: false
      }
    ]),
    random
  );

  const startedAt = now();
  let completedAt = null;
  let status = "active";
  let locked = false;
  let pendingMismatch = [];
  let moves = 0;
  let pairsFound = 0;

  function visibleCard(card) {
    const visible = card.faceUp || card.matched;
    return {
      id: card.id,
      matched: card.matched,
      faceUp: card.faceUp,
      faceType: visible ? card.faceType : null,
      value: visible ? card.value : null
    };
  }

  function calculateScore() {
    const extraMoves = Math.max(0, moves - pairCount);
    return Math.max(pairCount * 100, pairCount * 300 - extraMoves * 25);
  }

  function elapsedSeconds() {
    return Math.max(0, Math.round(((completedAt ?? now()) - startedAt) / 1000));
  }

  function getSnapshot() {
    return {
      status,
      locked,
      pairCount,
      moves,
      pairsFound,
      elapsedSeconds: elapsedSeconds(),
      score: status === "complete" ? calculateScore() : 0,
      cards: cards.map(visibleCard)
    };
  }

  function flip(cardId) {
    if (status === "complete") return { type: "complete", snapshot: getSnapshot() };
    if (locked) return { type: "locked", snapshot: getSnapshot() };
    const card = cards.find(({ id }) => id === cardId);
    if (!card) throw new TypeError("Nie znaleziono karty.");
    if (card.matched || card.faceUp) return { type: "ignored", snapshot: getSnapshot() };

    card.faceUp = true;
    const openCards = cards.filter((candidate) => candidate.faceUp && !candidate.matched);
    if (openCards.length === 1) return { type: "first", cardId, snapshot: getSnapshot() };

    moves += 1;
    const [first, second] = openCards;
    if (first.pairId === second.pairId) {
      first.matched = true;
      second.matched = true;
      pairsFound += 1;

      if (pairsFound === pairCount) {
        status = "complete";
        completedAt = now();
      }
      return { type: "match", cardIds: [first.id, second.id], snapshot: getSnapshot() };
    }

    locked = true;
    pendingMismatch = [first.id, second.id];
    return { type: "mismatch", cardIds: clone(pendingMismatch), snapshot: getSnapshot() };
  }

  function concealMismatch() {
    if (!locked) return getSnapshot();
    cards.forEach((card) => {
      if (pendingMismatch.includes(card.id)) card.faceUp = false;
    });
    pendingMismatch = [];
    locked = false;
    return getSnapshot();
  }

  function getSummary() {
    return {
      status,
      pairCount,
      moves,
      pairsFound,
      elapsedSeconds: elapsedSeconds(),
      score: status === "complete" ? calculateScore() : 0
    };
  }

  return { getSnapshot, getSummary, flip, concealMismatch };
}
