import { ACHIEVEMENTS } from "../../data/achievements.js";
import { GAME_MODES, findGameMode } from "../../data/game-modes.js";
import { getAchievementProgress, getLevelInfo } from "../../game/progress.js";
import { escapeHtml } from "../html.js";

const dateFormatter = new Intl.DateTimeFormat("pl-PL", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit"
});

function formatDate(value) {
  return dateFormatter.format(new Date(value));
}

function renderAchievement(state, achievement, unlockedById) {
  const unlocked = unlockedById.get(achievement.id);
  const progress = getAchievementProgress(state, achievement);
  return `
    <article class="achievement-card${unlocked ? " is-unlocked" : ""}">
      <span class="achievement-card__icon" aria-hidden="true">${escapeHtml(achievement.icon)}</span>
      <div class="achievement-card__copy">
        <p class="eyebrow">${unlocked ? "Odblokowano" : "W toku"}</p>
        <h3>${escapeHtml(achievement.title)}</h3>
        <p>${escapeHtml(achievement.description)}</p>
      </div>
      <div class="achievement-card__progress">
        <div class="progress-track" role="progressbar" aria-label="Postęp osiągnięcia ${escapeHtml(achievement.title)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress.percentage}">
          <span style="width: ${progress.percentage}%"></span>
        </div>
        <small>${unlocked ? formatDate(unlocked.unlockedAt) : `${progress.current}/${progress.target}`}</small>
      </div>
    </article>
  `;
}

function renderSpecialRecord(modeId, record) {
  if (modeId === "skzoo-memory") {
    const sizes = Object.entries(record.bestMovesBySize)
      .map(([size, moves]) => `${size} par: ${moves} ruchów`)
      .join(" • ");
    return sizes || "Brak ukończonej planszy";
  }
  if (modeId === "timeline") {
    return record.largestPerfectRound
      ? `Największa perfekcyjna oś: ${record.largestPerfectRound} kart`
      : "Perfekcyjna oś jeszcze czeka";
  }
  return record.bestStreak ? `Najlepsza seria: ${record.bestStreak}` : "Seria jeszcze czeka";
}

function roundLabel(count) {
  if (count === 1) return "runda";
  if (count % 10 >= 2 && count % 10 <= 4 && (count % 100 < 12 || count % 100 > 14)) return "rundy";
  return "rund";
}

function renderRecord(mode, record) {
  return `
    <article class="record-card record-card--${escapeHtml(mode.accent)}">
      <header>
        <span aria-hidden="true">${escapeHtml(mode.icon)}</span>
        <div><p class="eyebrow">${record.plays} ${roundLabel(record.plays)}</p><h3>${escapeHtml(mode.shortName)}</h3></div>
      </header>
      <div class="record-card__numbers">
        <span>Rekord <strong>${record.plays ? `${record.bestScore} pkt` : "—"}</strong></span>
        <span>Skuteczność <strong>${record.plays ? `${record.bestAccuracy}%` : "—"}</strong></span>
      </div>
      <p>${escapeHtml(renderSpecialRecord(mode.id, record))}</p>
    </article>
  `;
}

function historyDetail(entry) {
  if (entry.kind === "timeline") return `${entry.details.roundSize ?? "?"} kart`;
  if (entry.kind === "memory") return `${entry.details.pairCount ?? "?"} par • ${entry.details.moves ?? "?"} ruchów`;
  return `${entry.accuracy}% poprawnych`;
}

function renderHistoryEntry(entry) {
  const mode = findGameMode(entry.modeId);
  return `
    <li class="history-entry">
      <span class="history-entry__icon" aria-hidden="true">${escapeHtml(mode?.icon ?? "•")}</span>
      <div>
        <strong>${escapeHtml(mode?.shortName ?? entry.modeId)}</strong>
        <small>${escapeHtml(historyDetail(entry))} • ${escapeHtml(formatDate(entry.completedAt))}</small>
      </div>
      <b>+${entry.score}</b>
    </li>
  `;
}

export function createAchievementsScreen(state) {
  const screen = document.createElement("div");
  screen.className = "screen achievements-screen";
  const level = getLevelInfo(state.player.totalPoints);
  const unlockedById = new Map(state.achievements.unlocked.map((entry) => [entry.id, entry]));

  screen.innerHTML = `
    <section class="profile-progress-card">
      <div class="profile-progress-card__top">
        <span class="profile-progress-card__level">${state.player.level}</span>
        <div><p class="eyebrow">${escapeHtml(state.player.rank)}</p><h1>${escapeHtml(state.player.displayName)}</h1></div>
      </div>
      <p class="profile-progress-card__points"><strong>${state.player.totalPoints}</strong> punktów łącznie</p>
      <div class="progress-track" role="progressbar" aria-label="Postęp poziomu" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${level.progress}">
        <span style="width: ${level.progress}%"></span>
      </div>
      <small>Do poziomu ${state.player.level + 1}: ${level.pointsToNextLevel} pkt</small>
    </section>

    <section class="progress-stat-grid" aria-label="Statystyki postępu">
      <article><span>Rundy</span><strong>${state.stats.gamesPlayed}</strong></article>
      <article><span>Poprawne</span><strong>${state.stats.correctAnswers}</strong></article>
      <article><span>Najlepsza seria</span><strong>${state.player.bestStreak}</strong></article>
      <article><span>Odznaki</span><strong>${unlockedById.size}/${ACHIEVEMENTS.length}</strong></article>
    </section>

    <div class="section-heading achievements-heading">
      <div><p class="eyebrow">Kolekcja wyzwań</p><h2>Osiągnięcia</h2></div>
      <span>${unlockedById.size} zdobytych</span>
    </div>
    <section class="achievement-grid" aria-label="Lista osiągnięć">
      ${ACHIEVEMENTS.map((achievement) => renderAchievement(state, achievement, unlockedById)).join("")}
    </section>

    <div class="section-heading records-heading">
      <div><p class="eyebrow">Najlepsze wyniki</p><h2>Rekordy trybów</h2></div>
    </div>
    <section class="record-grid" aria-label="Rekordy trybów">
      ${GAME_MODES.map((mode) => renderRecord(mode, state.records[mode.id])).join("")}
    </section>

    <div class="section-heading history-heading">
      <div><p class="eyebrow">Ostatnie zapisane gry</p><h2>Historia</h2></div>
      <span>${state.history.length}/30</span>
    </div>
    ${state.history.length
      ? `<ol class="history-list">${state.history.slice(0, 10).map(renderHistoryEntry).join("")}</ol>`
      : `<section class="history-empty"><span aria-hidden="true">☆</span><p>Ukończ pierwszą rundę, a jej wynik pojawi się tutaj.</p></section>`}
  `;

  return screen;
}
