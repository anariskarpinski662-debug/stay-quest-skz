import { createApp } from "./app/app.js";

const target = document.querySelector("#app");
const isAndroidWrapper = location.hostname === "appassets.androidplatform.net";

document.documentElement.dataset.platform = isAndroidWrapper ? "android" : "web";

if (!target) throw new Error("Nie znaleziono kontenera aplikacji.");

const app = createApp(target);

if (!isAndroidWrapper && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./service-worker.js", { scope: "./" })
      .then((registration) => {
        registration.addEventListener("updatefound", () => {
          const worker = registration.installing;
          worker?.addEventListener("statechange", () => {
            if (worker.state === "installed" && navigator.serviceWorker.controller) {
              app.notify("Nowa wersja jest gotowa. Otwórz aplikację ponownie, aby ją wczytać.");
            }
          });
        });
      })
      .catch((error) => {
        console.error("Nie udało się włączyć trybu offline:", error);
      });
  });
}
