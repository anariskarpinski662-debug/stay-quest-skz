export function renderAppShell(target) {
  target.innerHTML = `
    <a class="skip-link" href="#screen">Przejdź do głównej treści</a>
    <div class="app-shell">
      <header class="topbar">
        <a class="brand" href="#/home" aria-label="STAY QUEST — ekran główny">
          <span class="brand__mark" aria-hidden="true">SQ</span>
          <span><strong>STAY QUEST</strong><small>mobile game</small></span>
        </a>
        <span class="connection-pill" id="connection-status" role="status">sprawdzanie…</span>
      </header>

      <main id="screen" tabindex="-1"></main>

      <nav class="bottom-nav" aria-label="Główna nawigacja">
        <a href="#/home" data-nav="home"><span aria-hidden="true">⌂</span><small>Gra</small></a>
        <a href="#/achievements" data-nav="achievements"><span aria-hidden="true">★</span><small>Odznaki</small></a>
        <a href="#/settings" data-nav="settings"><span aria-hidden="true">◉</span><small>Opcje</small></a>
      </nav>
    </div>
    <div id="modal-layer" class="modal-layer" hidden></div>
    <div id="toast" class="toast" role="status" aria-live="polite" hidden></div>
  `;

  return {
    appShell: target.querySelector(".app-shell"),
    screen: target.querySelector("#screen"),
    connectionStatus: target.querySelector("#connection-status"),
    modalLayer: target.querySelector("#modal-layer"),
    toast: target.querySelector("#toast")
  };
}
