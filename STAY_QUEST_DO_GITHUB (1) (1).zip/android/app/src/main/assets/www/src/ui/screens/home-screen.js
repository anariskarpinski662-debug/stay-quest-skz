import { GAME_MODES } from "../../data/game-modes.js";
import { MEMBER_EMOJI_LINE } from "../../data/member-symbols.js";
import { getLevelInfo } from "../../game/progress.js";
import { createModeCard } from "../components/mode-card.js";
import { escapeHtml } from "../html.js";

export function createHomeScreen(state) {
  const screen = document.createElement("div");
  screen.className = "screen home-screen";
  const level = getLevelInfo(state.player.totalPoints);
  const installControl = document.documentElement.dataset.platform === "android"
    ? `<span class="native-install-status"><span aria-hidden="true">✓</span> Aplikacja Android</span>`
    : `
      <button class="button button--primary" type="button" data-action="install">
        <span aria-hidden="true">↓</span> Zainstaluj aplikację
      </button>
    `;

  const hero = document.createElement("section");
  hero.className = "hero-card";
  hero.innerHTML = `
    <div class="hero-card__glow" aria-hidden="true"></div>
    <p class="eyebrow">Twoja strefa gry</p>
    <h1>Gotowy, <span>${escapeHtml(state.player.displayName)}</span>?</h1>
    <p class="hero-card__copy">${escapeHtml(state.player.rank)} • pięć trybów, trwałe rekordy i coraz wyższy poziom wiedzy.</p>
    <p class="member-line" aria-label="Ośmiu członków">${MEMBER_EMOJI_LINE}</p>
    ${installControl}
  `;

  const stats = document.createElement("section");
  stats.className = "stat-grid";
  stats.setAttribute("aria-label", "Statystyki gracza");
  stats.innerHTML = `
    <article class="stat-card"><span>Poziom</span><strong>${state.player.level}</strong></article>
    <article class="stat-card"><span>Punkty</span><strong>${state.player.totalPoints}</strong></article>
    <article class="stat-card"><span>Najlepsza seria</span><strong>${state.player.bestStreak}</strong></article>
  `;

  const levelStrip = document.createElement("section");
  levelStrip.className = "home-level-strip";
  levelStrip.innerHTML = `
    <div><span>Poziom ${state.player.level}</span><strong>${level.pointsToNextLevel} pkt do kolejnego</strong></div>
    <div class="progress-track" role="progressbar" aria-label="Postęp poziomu" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${level.progress}"><span style="width: ${level.progress}%"></span></div>
  `;

  const sectionHeader = document.createElement("div");
  sectionHeader.className = "section-heading";
  sectionHeader.innerHTML = `
    <div><p class="eyebrow">Wybierz wyzwanie</p><h2>Tryby gry</h2></div>
    <span>${GAME_MODES.length} modułów</span>
  `;

  const modeGrid = document.createElement("section");
  modeGrid.className = "mode-grid";
  modeGrid.setAttribute("aria-label", "Tryby gry");
  GAME_MODES.forEach((mode) => modeGrid.append(createModeCard(mode)));

  screen.append(hero, stats, levelStrip, sectionHeader, modeGrid);
  return screen;
}
