const CUES = Object.freeze({
  tap: {
    tones: [[420, 0.035, 0]],
    vibration: 8
  },
  correct: {
    tones: [[660, 0.07, 0], [880, 0.1, 0.065]],
    vibration: [14, 22, 18]
  },
  wrong: {
    tones: [[230, 0.09, 0], [170, 0.12, 0.075]],
    vibration: 36
  },
  match: {
    tones: [[520, 0.055, 0], [720, 0.08, 0.05]],
    vibration: [10, 18, 14]
  },
  complete: {
    tones: [[520, 0.07, 0], [660, 0.07, 0.07], [880, 0.14, 0.14]],
    vibration: [18, 28, 18, 28, 28]
  },
  achievement: {
    tones: [[660, 0.08, 0], [990, 0.1, 0.08], [1320, 0.15, 0.17]],
    vibration: [20, 25, 20, 25, 35]
  },
  preview: {
    tones: [[540, 0.065, 0], [810, 0.11, 0.065]],
    vibration: [15, 25, 22]
  }
});

function defaultAudioContextFactory() {
  const AudioContextClass = globalThis.AudioContext ?? globalThis.webkitAudioContext;
  return AudioContextClass ? new AudioContextClass() : null;
}

function defaultVibrate(pattern) {
  if (typeof globalThis.navigator?.vibrate !== "function") return false;
  return globalThis.navigator.vibrate(pattern);
}

export function createFeedbackController({
  getSettings = () => ({ soundEnabled: true, hapticsEnabled: true }),
  audioContextFactory = defaultAudioContextFactory,
  vibrate = defaultVibrate
} = {}) {
  let audioContext = null;

  function getAudioContext() {
    if (audioContext) return audioContext;
    try {
      audioContext = audioContextFactory();
    } catch {
      audioContext = null;
    }
    return audioContext;
  }

  function playTone(context, [frequency, duration, delay]) {
    const start = context.currentTime + delay;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(0.025, start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.015);
  }

  function trigger(name = "tap") {
    const cue = CUES[name] ?? CUES.tap;
    const settings = getSettings() ?? {};
    let soundPlayed = false;
    let hapticPlayed = false;

    if (settings.hapticsEnabled !== false) {
      try {
        hapticPlayed = vibrate(cue.vibration) !== false;
      } catch {
        hapticPlayed = false;
      }
    }

    if (settings.soundEnabled !== false) {
      const context = getAudioContext();
      if (context) {
        try {
          if (context.state === "suspended") void context.resume();
          cue.tones.forEach((tone) => playTone(context, tone));
          soundPlayed = true;
        } catch {
          soundPlayed = false;
        }
      }
    }

    return { soundPlayed, hapticPlayed };
  }

  async function destroy() {
    if (audioContext?.close) await audioContext.close();
    audioContext = null;
  }

  return { trigger, destroy };
}
