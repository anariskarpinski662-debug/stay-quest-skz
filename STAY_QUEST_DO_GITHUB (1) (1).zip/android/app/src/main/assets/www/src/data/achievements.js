export const ACHIEVEMENTS = Object.freeze([
  {
    id: "first-round",
    icon: "✦",
    title: "Pierwszy krok",
    description: "Ukończ pierwszą rundę w dowolnym trybie.",
    metric: "gamesPlayed",
    target: 1
  },
  {
    id: "five-rounds",
    icon: "05",
    title: "Piątka na start",
    description: "Ukończ 5 rund.",
    metric: "gamesPlayed",
    target: 5
  },
  {
    id: "twenty-rounds",
    icon: "20",
    title: "Tryb koncertowy",
    description: "Ukończ 20 rund.",
    metric: "gamesPlayed",
    target: 20
  },
  {
    id: "points-1000",
    icon: "+",
    title: "Łowca punktów",
    description: "Zdobądź łącznie 1000 punktów.",
    metric: "totalPoints",
    target: 1000
  },
  {
    id: "points-5000",
    icon: "★",
    title: "Punktowy dominATE",
    description: "Zdobądź łącznie 5000 punktów.",
    metric: "totalPoints",
    target: 5000
  },
  {
    id: "streak-five",
    icon: "↗",
    title: "Seria x5",
    description: "Odpowiedz poprawnie 5 razy z rzędu.",
    metric: "bestStreak",
    target: 5
  },
  {
    id: "streak-ten",
    icon: "⚡",
    title: "Bez chwili zawahania",
    description: "Odpowiedz poprawnie 10 razy z rzędu.",
    metric: "bestStreak",
    target: 10
  },
  {
    id: "perfect-quiz",
    icon: "100",
    title: "Bez jednej skuchy",
    description: "Ukończ rundę quizową ze skutecznością 100%.",
    metric: "perfectQuizRounds",
    target: 1
  },
  {
    id: "timeline-perfect",
    icon: "⌛",
    title: "Architekt czasu",
    description: "Ułóż perfekcyjną oś czasu.",
    metric: "perfectTimelineRounds",
    target: 1
  },
  {
    id: "memory-perfect",
    icon: "◆",
    title: "Pamięć SKZOO",
    description: "Ukończ Memory bez żadnego błędnego ruchu.",
    metric: "perfectMemoryRounds",
    target: 1
  },
  {
    id: "all-modes",
    icon: "05",
    title: "Cała piątka",
    description: "Ukończ przynajmniej jedną rundę w każdym trybie.",
    metric: "completedModes",
    target: 5
  },
  {
    id: "answers-100",
    icon: "✓",
    title: "Setka odpowiedzi",
    description: "Udziel 100 poprawnych odpowiedzi quizowych.",
    metric: "correctAnswers",
    target: 100
  }
].map((achievement) => Object.freeze(achievement)));

export function findAchievement(achievementId) {
  return ACHIEVEMENTS.find(({ id }) => id === achievementId) ?? null;
}
