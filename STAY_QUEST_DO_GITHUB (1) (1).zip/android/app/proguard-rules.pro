-keepclassmembers class pl.anaris.stayquest.MainActivity$StayQuestBridge {
    @android.webkit.JavascriptInterface <methods>;
}
