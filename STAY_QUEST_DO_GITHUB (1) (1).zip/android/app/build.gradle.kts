plugins {
    id("com.android.application")
}

android {
    namespace = "pl.anaris.stayquest"
    compileSdk = 36

    defaultConfig {
        applicationId = "pl.anaris.stayquest"
        minSdk = 28
        targetSdk = 36
        versionCode = 600
        versionName = "0.6.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = false
    }
}
