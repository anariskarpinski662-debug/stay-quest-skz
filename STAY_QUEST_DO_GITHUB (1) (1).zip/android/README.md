# STAY QUEST Android

Natywna osłona pełnej gry znajduje się w module `app`. Instrukcja synchronizacji, budowania, podpisywania i testowania: `../docs/ANDROID_BUILD.md`.

Przed każdym buildem wykonaj w katalogu głównym projektu `npm run sync:android`.
