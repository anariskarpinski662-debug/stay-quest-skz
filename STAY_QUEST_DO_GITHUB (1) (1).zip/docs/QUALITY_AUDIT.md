# Audyt jakości — krok 5 / wersja 0.5.0

## Dotyk i telefon

- minimalna obsługiwana szerokość układu wynosi 320 px,
- podstawowy cel dotykowy ma 48 × 48 px,
- górna belka i dolna nawigacja uwzględniają `safe-area-inset`,
- plansza Memory zachowuje cztery kolumny także na wąskim ekranie,
- Timeline pozwala przeciągnąć numer karty dotykiem o jeden lub kilka kroków,
- każda operacja przeciągania ma równoważne przyciski „wyżej” i „niżej”.

## Dostępność

- powłoka ma link pomijający nawigację i fokusowalny region główny,
- aktywny ekran otrzymuje poprawny tytuł dokumentu,
- modale mają rolę dialogu, blokadę fokusu, obsługę Escape i zwrot fokusu,
- tło modala korzysta z `inert` oraz `aria-hidden`,
- statusy odpowiedzi, połączenia i ustawień są regionami live,
- ustawienie ograniczenia ruchu działa niezależnie od preferencji systemowej,
- ustawienia korzystają z natywnych pól wyboru i przycisków.

## Offline i aktualizacje

- 38 plików potrzebnych do gry trafia do wersjonowanej powłoki offline,
- wejście do aplikacji używa strategii network-first z fallbackiem do `index.html`,
- statyczne zasoby są dostępne natychmiast z cache i odświeżane w tle,
- czyszczone są wyłącznie starsze cache należące do STAY QUEST,
- użytkownik otrzymuje komunikat o zainstalowanej aktualizacji.

## Budżety

Automatyczne testy blokują regresję, gdy:

- powłoka offline przekroczy 360 KiB,
- pojedynczy plik JavaScript lub CSS przekroczy 64 KiB,
- do projektu trafi katalog `node_modules`,
- zabraknie pliku zadeklarowanego w powłoce offline.

## Granica tego kroku

Audyty kodu, danych, HTTP i układu są automatyczne. Instalacja rzeczywistego APK, zachowanie klawiatury ekranowej i test na fizycznym Androidzie należą do kroku 6.
