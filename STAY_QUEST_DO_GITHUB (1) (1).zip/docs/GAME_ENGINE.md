# Wspólny silnik rozgrywki

## Po co istnieje osobny rdzeń

Ekrany nie obliczają samodzielnie punktów ani poprawności. Odpowiada za to warstwa `src/game`, dzięki czemu zasady pozostają identyczne w każdym trybie quizowym i mogą być testowane bez uruchamiania interfejsu.

## Obsługiwane pytania

### Jednokrotny wybór

Pytanie zawiera co najmniej dwie opcje z unikalnymi identyfikatorami. Silnik miesza ich kolejność w każdej nowej rundzie i porównuje identyfikator wybranej opcji z rozwiązaniem.

### Odpowiedź wpisywana

Pytanie może zawierać kilka akceptowanych zapisów. Porównanie ignoruje:

- wielkość liter,
- nadmiarowe odstępy,
- apostrofy i zwykłe znaki interpunkcyjne,
- polskie znaki diakrytyczne.

Poprawna odpowiedź nie jest udostępniana ekranowi przed zatwierdzeniem wyboru.

## Przebieg sesji

Sesja przechodzi przez trzy stany:

1. `active` — gracz odpowiada albo korzysta z podpowiedzi,
2. `answered` — rozwiązanie, punkty i wyjaśnienie są widoczne,
3. `complete` — wszystkie pytania zostały rozliczone i dostępne jest podsumowanie.

Pytania są losowane bez zwracania, więc w jednej rundzie żaden identyfikator się nie powtarza.

## Punktacja

1. Punkty bazowe pochodzą z rekordu pytania.
2. Każdy poziom trudności powyżej pierwszego dodaje 15% wartości bazowej.
3. Od drugiej poprawnej odpowiedzi z rzędu naliczana jest premia 10 punktów za poziom serii, maksymalnie 40 punktów.
4. Odsłonięcie podpowiedzi odejmuje 25% całej puli danego pytania.
5. W Mistrzu Skojarzeń dodatkowy odsłonięty trop odejmuje stałą karę zapisaną przy pytaniu.
6. Błędna lub pominięta odpowiedź daje 0 punktów i zeruje bieżącą serię.

Ekran wyniku pokazuje osobno bazę, premię trudności, premię serii, karę za podpowiedź i koszt dodatkowych tropów.

## Ochrona jakości treści

Walidator blokuje uruchomienie wadliwego banku, między innymi gdy:

- dwa pytania mają ten sam identyfikator,
- poprawna opcja nie istnieje,
- pytanie nie ma wyjaśnienia,
- oficjalny fakt nie ma tytułu źródła, bezpiecznego adresu HTTP/HTTPS i daty sprawdzenia,
- poziom trudności wykracza poza skalę 1–5.

## Silnik Timeline

Kontroler losuje 4, 6 lub 8 wydarzeń bez powtórek i przed sprawdzeniem przekazuje ekranowi wyłącznie tytuł, opis oraz erę. Daty, poprawna kolejność i źródła pozostają ukryte. Wynik uwzględnia liczbę kart ustawionych dokładnie na właściwej pozycji oraz premię za perfekcyjną oś.

## Silnik Memory

Kontroler buduje 4, 6 lub 8 par. Jedna karta pokazuje symbol członka, a druga nazwę odpowiadającej postaci SKZOO. Błędna para chwilowo blokuje kolejne ruchy, dopasowane karty pozostają odkryte, a wynik maleje wraz z dodatkowymi ruchami. Czas jest informacyjny i nie ogranicza rundy.

## Przekazanie wyniku do profilu

Każdy ekran przekazuje ujednolicony wynik dopiero przy przejściu sesji do stanu ukończonego. Rekord zawiera identyfikator trybu, rodzaj mechaniki, punkty, skuteczność oraz szczegóły właściwe dla quizu, Timeline albo Memory. Warstwa postępu następnie:

1. aktualizuje rekord danego trybu,
2. dodaje punkty do profilu i przelicza poziom,
3. aktualizuje serie oraz statystyki,
4. zapisuje wpis w historii,
5. sprawdza nowe osiągnięcia,
6. utrwala cały stan na urządzeniu.

Przycisk ponownej gry tworzy nową sesję. Samo ponowne wyrenderowanie podsumowania nie zapisuje wyniku drugi raz.
