# Plan rozbudowy STAY QUEST

## Krok 1 — fundament mobilny

Status: gotowy.

- aplikacja wieloplikowa,
- ekran startowy i karty trybów,
- routing bez przeładowywania strony,
- instalowalna PWA,
- obsługa offline,
- podstawy dostępności i bezpiecznych obszarów ekranu.

## Krok 2 — wspólny silnik gry

Status: gotowy.

- model pytania i walidacja danych — gotowe,
- sesja gry i losowanie bez powtórek — gotowe,
- odpowiedzi jednokrotnego wyboru — gotowe,
- odpowiedzi wpisywane z normalizacją zapisu — gotowe,
- natychmiastowa informacja zwrotna — gotowe,
- naliczanie punktów, trudności, serii i kary za podpowiedź — gotowe,
- ekran wyniku rundy — gotowy,
- testy silnika niezależne od interfejsu — gotowe,
- demonstracyjne rundy Skojarzeń i Emoji — zastąpione pełnymi bankami w kroku 3.

## Krok 3 — pięć trybów

Status: gotowy.

- Mistrz Skojarzeń — 32 zagadki, w tym utwory oraz członkowie i SKZOO,
- Zgadnij Utwór po Emoji — 26 zagadek z odpowiedzią wpisywaną,
- SKZ Timeline Architect — 30 wydarzeń, trzy długości rundy i źródła po sprawdzeniu,
- Hardcore Lore Quiz — 29 pytań faktograficznych ze źródłami,
- SKZOO Memory Game — trzy rozmiary planszy i osiem postaci.

Każdy moduł ma własne dane i ekran. Quizy korzystają ze wspólnej punktacji, Timeline z kontrolera chronologii, a Memory z osobnego kontrolera par.

## Krok 4 — profil i postęp

Status: gotowy.

- trwały zapis wyników — gotowy,
- poziomy i rangi — gotowe,
- rekordy trybów — gotowe,
- serie odpowiedzi — gotowe,
- 12 osiągnięć z postępem — gotowe,
- ustawienia dźwięku, ruchu, tekstu i kontrastu — gotowe,
- eksport, import i reset postępu — gotowe,
- migracja wcześniejszego zapisu — gotowa.

## Krok 5 — dopracowanie

Status: gotowy.

- krótkie animacje i generowane sygnały Web Audio z opcją wyłączenia — gotowe,
- opcjonalne wibracje dotykowe z bezpiecznym fallbackiem — gotowe,
- przeciąganie kart Timeline dotykiem oraz alternatywne przyciski — gotowe,
- automatyczny audyt szerokości od 320 px i bezpiecznych obszarów ekranu — gotowy,
- wersjonowana powłoka offline, nawigacyjny fallback i odświeżanie cache — gotowe,
- budżet rozmiaru powłoki i pojedynczych plików — gotowy,
- szybki skok do treści, zarządzanie fokusem i przegląd semantyki — gotowe.

## Krok 6 — Android

Status: w toku — projekt źródłowy gotowy, build APK oczekuje na toolchain.

- opakowanie istniejącej aplikacji w projekt Android — gotowe,
- lokalne ładowanie pełnej gry bez internetu — gotowe,
- natywne cofanie, import, eksport i obsługa linków — gotowe,
- automatyczna synchronizacja zasobów oraz testy projektu — gotowe,
- workflow budujący podpisany kluczem debug APK — gotowy, jeszcze nieuruchomiony,
- kompilacja APK w środowisku z Android SDK — oczekuje,
- test instalacji i aktualizacji na telefonie — oczekuje,
- finalny pakiet do zainstalowania — oczekuje.
