# Android — projekt wersji 0.6.0

## Stan

Katalog `android/` zawiera natywny projekt aplikacji o identyfikatorze `pl.anaris.stayquest`. Projekt używa:

- Android Gradle Plugin 9.2.1,
- Gradle 9.4.1,
- JDK 17,
- Android SDK 36 i Build Tools 36.0.0,
- minimalnego systemu Android 9 (API 28),
- docelowego systemu Android 16 (API 36).

Projekt nie ma zależności AndroidX ani zewnętrznych bibliotek uruchomieniowych.

## Architektura

Pełna gra jest kopiowana do `android/app/src/main/assets/www/`. Aktywność Android tworzy systemowy `WebView` i udostępnia pliki pod lokalnym adresem HTTPS `appassets.androidplatform.net`. Dzięki temu moduły JavaScript działają zgodnie z zasadami same-origin bez włączania ryzykownego dostępu `file://`.

Aplikacja:

- działa z treścią gry bez internetu,
- zachowuje profil w lokalnej pamięci WebView,
- obsługuje systemowe cofanie,
- otwiera zewnętrzne źródła w domyślnej przeglądarce,
- pozwala wybrać plik kopii postępu,
- zapisuje eksport przez systemowy ekran wyboru dokumentu,
- korzysta z systemowych obszarów statusu, wycięcia i nawigacji,
- nie prosi o uprawnienie do internetu ani pamięci plików,
- prosi wyłącznie o obsługę wibracji.

## Synchronizacja gry

Po zmianie plików webowych uruchom w katalogu głównym projektu:

```bash
npm run sync:android
```

Test porównuje wszystkie 38 osadzonych plików bajt po bajcie z bieżącym źródłem.

## Budowa w Android Studio

1. Zainstaluj Android Studio z JDK 17 oraz platformą Android SDK 36.
2. Otwórz katalog `android/` jako projekt.
3. Ustaw Gradle 9.4.1, jeżeli IDE nie dobierze go automatycznie.
4. Zaczekaj na synchronizację AGP 9.2.1.
5. Wybierz `Build > Generate App Bundles or APKs > Generate APKs` dla wariantu debug.

Wynik powinien znaleźć się w `android/app/build/outputs/apk/debug/app-debug.apk`. Wariant debug jest automatycznie podpisany kluczem testowym i nadaje się do instalacji ręcznej, ale nie do publikacji w Google Play.

## Wersja podpisana

Do stałych aktualizacji na tym samym telefonie trzeba używać zawsze tego samego prywatnego klucza. Klucza nie należy dodawać do ZIP-a ani repozytorium. W Android Studio służy do tego `Build > Generate Signed App Bundle or APK`.

## Lista testu na telefonie

- instalacja i pierwsze uruchomienie,
- każdy z pięciu trybów,
- zamknięcie i ponowne otwarcie z zachowanym postępem,
- dźwięk i wibracje,
- import oraz eksport JSON,
- systemowy gest cofania,
- otwarcie źródła w przeglądarce,
- uruchomienie w trybie samolotowym,
- instalacja nowszej wersji bez utraty danych.

Test na fizycznym urządzeniu jest ostatnim etapem przed uznaniem APK za gotowe.

## Źródła techniczne

- [Ładowanie lokalnej treści w WebView](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content)
- [Budowanie APK do udostępnienia](https://developer.android.com/build/build-for-release)
- [Android Gradle Plugin 9.2](https://developer.android.com/build/releases/agp-9-2-0-release-notes)
- [Android 16 / API 36](https://developer.android.com/tools/releases/platforms#16)
