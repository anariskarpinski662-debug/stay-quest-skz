# Profil i trwały postęp — wersja 0.6.0

## Co jest zapisywane

Stan aplikacji obejmuje:

- nazwę gracza, punkty, poziom, rangę oraz serie,
- łączne statystyki odpowiedzi i ukończonych rund,
- rekordy każdego z pięciu trybów,
- najlepsze ruchy i czasy osobno dla plansz Memory,
- największą perfekcyjnie ułożoną oś czasu,
- zdobyte osiągnięcia wraz z datami,
- maksymalnie 30 ostatnich rund,
- ustawienia interfejsu, dźwięku i wibracji.

Zapis korzysta ze schematu w wersji 3. Dane z wersji 1 i 2 są uzupełniane o nowe pola bez kasowania nazwy, punktów, historii ani wcześniejszych ustawień. W wersji 3 dodano osobne ustawienie wibracji dotykowych.

## Poziomy i rangi

Poziom rośnie co 2500 punktów. Rangi są elementem systemu gry:

| Minimalny poziom | Ranga |
| ---: | --- |
| 1 | Baby STAY |
| 2 | Rookie STAY |
| 3 | Core STAY |
| 5 | Master STAY |
| 8 | Legend STAY |

## Osiągnięcia

Wersja 0.6.0 zawiera 12 osiągnięć. Obejmują liczbę rund, punkty, serie poprawnych odpowiedzi, perfekcyjne quizy, perfekcyjny Timeline, bezbłędne Memory, ukończenie wszystkich trybów i 100 poprawnych odpowiedzi.

## Kopia bezpieczeństwa

Eksport tworzy plik JSON zawierający cały stan profilu. Import sprawdza format, identyfikator aplikacji i wymagane sekcje, a następnie normalizuje dane do bieżącego schematu. Reset wymaga osobnego potwierdzenia. Kopię warto pobrać przed resetem albo zmianą urządzenia.
