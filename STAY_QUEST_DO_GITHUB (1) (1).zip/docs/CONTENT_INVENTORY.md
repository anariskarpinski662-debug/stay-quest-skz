# Inwentarz treści — wersja 0.6.0

Stan banków po kroku 3:

| Tryb | Zawartość | Długość rundy |
| --- | ---: | --- |
| Mistrz Skojarzeń | 24 zagadki utworów + 8 zagadek członków | 10 losowych pytań |
| Zgadnij Utwór po Emoji | 26 zagadek | 10 losowych pytań |
| Hardcore Lore Quiz | 29 pytań | 10 losowych pytań |
| SKZ Timeline Architect | 30 wydarzeń | 4, 6 lub 8 kart |
| SKZOO Memory Game | 8 postaci / 16 stron kart | 4, 6 lub 8 par |

Łącznie tryby quizowe zawierają 87 pytań. Zagadki skojarzeniowe i emoji są oznaczone jako autorskie interpretacje. Fakty oficjalne mają źródło oraz datę ostatniego sprawdzenia.

Bank obejmuje dyskografię od `Mixtape` i `I am NOT` do `RUN IT` oraz `THIS & THAT`, a oś czasu uwzględnia również zwycięstwo w `Kingdom: Legendary War` i serię wejść na pierwsze miejsce Billboard 200.
