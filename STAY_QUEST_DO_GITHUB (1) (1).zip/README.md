# STAY QUEST

Mobilna, instalowalna gra dla STAY. Projekt jest celowo podzielony na moduły — interfejs, dane, silnik rozgrywki i zapis postępu nie trafiają do jednego wielkiego pliku HTML.

## Stan projektu

Kroki 1–5 są gotowe, a natywny projekt kroku 6 jest przygotowany do kompilacji:

- mobilny ekran główny z pięcioma trybami,
- działająca nawigacja między ekranami,
- manifest PWA i ikony instalacyjne,
- obsługa instalacji na ekranie głównym,
- service worker, pełna powłoka offline i bezpieczne odświeżanie cache w tle,
- bezpieczne miejsce na stan gracza,
- responsywny dark mode oraz duże pola dotykowe,
- testy struktury danych i manifestu,
- wspólny silnik rund dla trybów quizowych,
- pytania jednokrotnego wyboru i z odpowiedzią wpisywaną,
- losowanie bez powtórek oraz mieszanie kolejności odpowiedzi,
- poziomy trudności, serie poprawnych odpowiedzi i premie punktowe,
- podpowiedzi obniżające wynik o 25%,
- pomijanie pytań, natychmiastowe wyjaśnienia i źródła,
- ekran podsumowania ze skutecznością oraz najdłuższą serią,
- 87 pytań quizowych: 32 Skojarzenia, 26 Emoji i 29 Hardcore Lore,
- osobna kategoria skojarzeń o członkach i SKZOO,
- progresywne odsłanianie tropów z karą punktową,
- Timeline z bankiem 30 wydarzeń i rundami po 4, 6 lub 8 kart,
- Memory z planszami po 4, 6 lub 8 par,
- automatyczny zapis ukończonych rund na urządzeniu,
- poziomy, pięć rang i 12 osiągnięć z licznikami postępu,
- rekordy osobno dla pięciu trybów oraz historia 30 ostatnich rund,
- edytowalna nazwa gracza,
- ustawienia wielkości tekstu, kontrastu, animacji, dźwięku i wibracji,
- lekkie sygnały Web Audio bez pobierania plików dźwiękowych,
- osobne reakcje na poprawną odpowiedź, błąd, parę, wynik i osiągnięcie,
- dotykowe przeciąganie kart Timeline wraz z przyciskami jako alternatywą,
- link szybkiego przejścia do treści i zamknięty obieg fokusu w modalach,
- komunikat o gotowej aktualizacji plików aplikacji,
- audyty układu od 320 px, safe area, ruchu, dotyku i semantyki,
- automatyczny limit 360 KiB dla powłoki offline oraz 64 KiB dla pojedynczego pliku kodu,
- projekt Android API 36 z pełną grą w lokalnym `WebView`,
- natywne cofanie, import, eksport i otwieranie źródeł,
- synchronizacja 38 plików gry z zasobami Androida,
- ręcznie uruchamiany workflow budujący testowe APK,
- eksport, import oraz potwierdzany reset postępu,
- bezpieczna migracja wcześniejszego zapisu do schematu wersji 3,
- automatyczne testy logiki i test HTTP aplikacji.

Każdy z pięciu trybów można uruchomić z jego ekranu. Tryby quizowe losują po 10 pytań, Timeline nie ujawnia dat przed sprawdzeniem, a Memory łączy symbol członka z nazwą postaci SKZOO. Po ukończeniu wynik trafia do profilu tylko raz, a nowe odznaki są sygnalizowane komunikatem.

## Uruchomienie

W katalogu projektu uruchom:

```bash
npm run dev
```

Następnie otwórz `http://localhost:4173`. Wersję PWA można instalować z bezpiecznego adresu HTTPS. Projekt Android znajduje się w katalogu `android/`; szczegóły kompilacji i testu APK opisuje `docs/ANDROID_BUILD.md`.

## Testy

```bash
npm test
npm run check
npm run smoke
npm run sync:android
```

## Architektura

```text
android/                  natywna osłona Android i osadzona gra offline
assets/icons/             ikony PWA i Android
docs/                     zasady treści i plan rozbudowy
src/app/                  uruchomienie, router, migracja i trwały stan
src/data/                 tryby, osiągnięcia, członkowie, pytania i wydarzenia
src/game/                 sesje, punktacja oraz naliczanie postępu
src/styles/               tokeny, baza, układ i komponenty
src/ui/components/        elementy wielokrotnego użytku
src/ui/screens/           kompletne ekrany aplikacji
tests/                    automatyczne testy
tools/                    lokalny serwer deweloperski
```

## Zasada projektu

Treści oficjalne, interpretacje zagadek i fandomowe lore będą oznaczane osobno. Każde pytanie faktograficzne powinno mieć krótkie wyjaśnienie oraz źródło możliwe do ponownej weryfikacji.

Szczegóły działania rdzenia znajdują się w pliku `docs/GAME_ENGINE.md`, system profilu w `docs/PROGRESS_SYSTEM.md`, liczby treści w `docs/CONTENT_INVENTORY.md`, kontrola kroku 5 w `docs/QUALITY_AUDIT.md`, a projekt mobilny w `docs/ANDROID_BUILD.md`.
