import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (path) => readFile(resolve(root, path), "utf8");

test("powłoka udostępnia szybki skok, region główny i komunikaty live", async () => {
  const shell = await read("src/ui/app-shell.js");
  assert.match(shell, /class="skip-link" href="#screen"/);
  assert.match(shell, /<main id="screen" tabindex="-1"><\/main>/);
  assert.match(shell, /<nav class="bottom-nav" aria-label=/);
  assert.match(shell, /role="status" aria-live="polite"/);
});

test("modale zatrzymują fokus i ukrywają tło przed technologiami asystującymi", async () => {
  const app = await read("src/app/app.js");
  assert.match(app, /role="dialog" aria-modal="true"/);
  assert.match(app, /shell\.appShell\.inert = true/);
  assert.match(app, /setAttribute\("aria-hidden", "true"\)/);
  assert.match(app, /event\.key === "Escape"/);
  assert.match(app, /event\.key !== "Tab"/);
  assert.match(app, /modalReturnFocus/);
});

test("ustawienia korzystają z natywnych kontrolek i respektują ograniczenie ruchu", async () => {
  const [settings, base, tokens] = await Promise.all([
    read("src/ui/screens/settings-screen.js"),
    read("src/styles/base.css"),
    read("src/styles/tokens.css")
  ]);
  assert.match(settings, /type="checkbox"/);
  assert.match(settings, /type="radio"/);
  assert.match(settings, /role="status" aria-live="polite"/);
  assert.match(base, /prefers-reduced-motion: reduce/);
  assert.match(base, /data-reduced-motion="true"/);
  assert.match(tokens, /--tap-size: 48px/);
});
