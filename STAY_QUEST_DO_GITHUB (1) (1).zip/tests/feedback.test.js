import test from "node:test";
import assert from "node:assert/strict";
import { createFeedbackController } from "../src/app/feedback.js";

function createAudioMock() {
  const events = [];
  const parameter = {
    setValueAtTime(value, time) { events.push(["set", value, time]); },
    exponentialRampToValueAtTime(value, time) { events.push(["ramp", value, time]); }
  };
  return {
    events,
    state: "running",
    currentTime: 1,
    destination: {},
    createOscillator() {
      return {
        type: "",
        frequency: parameter,
        connect() { events.push(["osc-connect"]); },
        start(time) { events.push(["start", time]); },
        stop(time) { events.push(["stop", time]); }
      };
    },
    createGain() {
      return {
        gain: parameter,
        connect() { events.push(["gain-connect"]); }
      };
    },
    async close() { events.push(["close"]); }
  };
}

test("sygnał poprawnej odpowiedzi uruchamia dźwięk i wibrację", () => {
  const audio = createAudioMock();
  const vibrations = [];
  const controller = createFeedbackController({
    getSettings: () => ({ soundEnabled: true, hapticsEnabled: true }),
    audioContextFactory: () => audio,
    vibrate: (pattern) => { vibrations.push(pattern); return true; }
  });

  assert.deepEqual(controller.trigger("correct"), { soundPlayed: true, hapticPlayed: true });
  assert.equal(audio.events.filter(([name]) => name === "start").length, 2);
  assert.equal(vibrations.length, 1);
});

test("wyłączone efekty nie tworzą kontekstu audio ani wibracji", () => {
  let audioCalls = 0;
  let vibrationCalls = 0;
  const controller = createFeedbackController({
    getSettings: () => ({ soundEnabled: false, hapticsEnabled: false }),
    audioContextFactory: () => { audioCalls += 1; return createAudioMock(); },
    vibrate: () => { vibrationCalls += 1; return true; }
  });

  assert.deepEqual(controller.trigger("achievement"), { soundPlayed: false, hapticPlayed: false });
  assert.equal(audioCalls, 0);
  assert.equal(vibrationCalls, 0);
});

test("brak obsługi audio i wibracji nie przerywa gry", () => {
  const controller = createFeedbackController({
    getSettings: () => ({ soundEnabled: true, hapticsEnabled: true }),
    audioContextFactory: () => null,
    vibrate: () => { throw new Error("unsupported"); }
  });

  assert.deepEqual(controller.trigger("tap"), { soundPlayed: false, hapticPlayed: false });
});
