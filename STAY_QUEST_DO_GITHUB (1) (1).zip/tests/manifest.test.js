import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

test("manifest opisuje instalowalną aplikację w trybie standalone", async () => {
  const manifest = JSON.parse(
    await readFile(new URL("../manifest.webmanifest", import.meta.url), "utf8")
  );

  assert.equal(manifest.display, "standalone");
  assert.equal(manifest.orientation, "portrait-primary");
  assert.ok(manifest.start_url);
  assert.ok(manifest.icons.some(({ sizes }) => sizes === "192x192"));
  assert.ok(manifest.icons.some(({ sizes, purpose }) => sizes === "512x512" && purpose === "maskable"));
  assert.ok(manifest.shortcuts.some(({ url }) => url === "./#/settings"));
});
