import test from "node:test";
import assert from "node:assert/strict";
import { createStore, STATE_VERSION, STORAGE_KEY } from "../src/app/store.js";

class MemoryStorage {
  constructor(entries = {}) {
    this.values = new Map(Object.entries(entries));
  }

  getItem(key) {
    return this.values.get(key) ?? null;
  }

  setItem(key, value) {
    this.values.set(key, String(value));
  }
}

const fixedDate = () => new Date("2026-08-19T12:00:00.000Z");

function result() {
  return {
    modeId: "emoji-guesser",
    kind: "quiz",
    score: 750,
    accuracy: 80,
    longestStreak: 4,
    currentStreak: 2,
    correctAnswers: 8,
    totalQuestions: 10,
    details: {}
  };
}

test("stary zapis v1 jest bezpiecznie migrowany do pełnego stanu", () => {
  const storage = new MemoryStorage({
    [STORAGE_KEY]: JSON.stringify({
      player: { displayName: "Anaris", totalPoints: 600, level: 99, currentStreak: 3 },
      settings: { soundEnabled: false, reducedMotion: true }
    })
  });
  const state = createStore({ storage, now: fixedDate }).getState();

  assert.equal(state.schemaVersion, STATE_VERSION);
  assert.equal(state.player.displayName, "Anaris");
  assert.equal(state.player.level, 1);
  assert.equal(state.player.bestStreak, 3);
  assert.equal(state.settings.soundEnabled, false);
  assert.equal(state.settings.hapticsEnabled, true);
  assert.equal(state.settings.highContrast, false);
  assert.equal(Object.keys(state.records).length, 5);
});

test("ukończona runda jest zapisana i wraca po ponownym utworzeniu sklepu", () => {
  const storage = new MemoryStorage();
  const store = createStore({ storage, now: fixedDate });
  const saved = store.recordResult(result());
  const restored = createStore({ storage, now: fixedDate }).getState();

  assert.equal(saved.saved, true);
  assert.equal(restored.player.totalPoints, 750);
  assert.equal(restored.records["emoji-guesser"].plays, 1);
  assert.equal(restored.history.length, 1);
});

test("profil i ustawienia są normalizowane przed zapisem", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.updateProfile("  Anaris\nSTAY  ");
  store.updateSettings({ textScale: "gigantic", highContrast: true });
  const state = store.getState();

  assert.equal(state.player.displayName, "Anaris STAY");
  assert.equal(state.settings.textScale, "standard");
  assert.equal(state.settings.highContrast, true);
});

test("eksport i import odtwarzają kopię postępu", () => {
  const original = createStore({ storage: new MemoryStorage(), now: fixedDate });
  original.updateProfile("Anaris");
  original.recordResult(result());
  const backup = original.exportBackup();

  const restored = createStore({ storage: new MemoryStorage(), now: fixedDate });
  restored.importBackup(backup);
  assert.equal(restored.getState().player.displayName, "Anaris");
  assert.equal(restored.getState().player.totalPoints, 750);
  assert.throws(() => restored.importBackup("nie-json"), /poprawnej kopii/);
});

test("reset usuwa postęp, ale pozostawia poprawny schemat", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.recordResult(result());
  store.reset();

  assert.equal(store.getState().player.totalPoints, 0);
  assert.equal(store.getState().stats.gamesPlayed, 0);
  assert.equal(store.getState().schemaVersion, STATE_VERSION);
});
