import test from "node:test";
import assert from "node:assert/strict";
import { createInitialState } from "../src/app/store.js";
import { createAchievementsScreen } from "../src/ui/screens/achievements-screen.js";
import { createSettingsScreen } from "../src/ui/screens/settings-screen.js";

function withDocument(run) {
  const previous = globalThis.document;
  globalThis.document = {
    createElement() {
      return {
        className: "",
        innerHTML: "",
        addEventListener() {}
      };
    }
  };
  try {
    return run();
  } finally {
    globalThis.document = previous;
  }
}

test("ekran postępu renderuje 12 osiągnięć i rekordy pięciu trybów", () => {
  const screen = withDocument(() => createAchievementsScreen(createInitialState()));
  assert.equal((screen.innerHTML.match(/<article class="achievement-card/g) ?? []).length, 12);
  assert.equal((screen.innerHTML.match(/<article class="record-card /g) ?? []).length, 5);
  assert.match(screen.innerHTML, /Baby STAY/);
});

test("ekran ustawień udostępnia profil, dostępność, kopię i reset", () => {
  const screen = withDocument(() => createSettingsScreen({
    state: createInitialState(),
    onProfileSave() {},
    onSettingsChange() {},
    onExport() {},
    onImport() {},
    onReset() {}
  }));

  assert.match(screen.innerHTML, /name="displayName"/);
  assert.match(screen.innerHTML, /name="highContrast"/);
  assert.match(screen.innerHTML, /name="hapticsEnabled"/);
  assert.match(screen.innerHTML, /settings-preview/);
  assert.match(screen.innerHTML, /settings-export/);
  assert.match(screen.innerHTML, /settings-reset/);
});
