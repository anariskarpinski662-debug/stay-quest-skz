import test from "node:test";
import assert from "node:assert/strict";
import { readdir, readFile, stat } from "node:fs/promises";
import { extname, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");

async function collectFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const path = resolve(directory, entry.name);
    return entry.isDirectory() ? collectFiles(path) : [path];
  }));
  return nested.flat();
}

test("powłoka offline mieści się w budżecie 360 KiB", async () => {
  const serviceWorker = await readFile(resolve(root, "service-worker.js"), "utf8");
  const shell = serviceWorker.match(/const APP_SHELL = \[([\s\S]*?)\];/)?.[1] ?? "";
  const paths = [...shell.matchAll(/"(\.\/[^\"]+)"/g)].map((match) => match[1]);
  const sizes = await Promise.all(paths.map((path) => stat(resolve(root, path))));
  const total = sizes.reduce((sum, file) => sum + file.size, 0);
  assert.ok(paths.length >= 35, "powłoka powinna zawierać komplet modułów aplikacji");
  assert.ok(total <= 360 * 1024, `powłoka ma ${(total / 1024).toFixed(1)} KiB`);
});

test("pojedyncze pliki kodu pozostają małe i projekt nie zawiera node_modules", async () => {
  const files = await collectFiles(root);
  assert.equal(files.some((path) => path.includes("/node_modules/")), false);
  const codeFiles = files.filter((path) => [".js", ".css"].includes(extname(path)) && !path.includes("/tests/"));
  const sizes = await Promise.all(codeFiles.map(async (path) => ({ path, size: (await stat(path)).size })));
  const largest = sizes.sort((a, b) => b.size - a.size)[0];
  assert.ok(largest.size <= 64 * 1024, `${largest.path} przekracza budżet 64 KiB`);
});
