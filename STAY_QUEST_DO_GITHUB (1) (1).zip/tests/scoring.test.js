import test from "node:test";
import assert from "node:assert/strict";
import { calculateQuestionScore } from "../src/game/scoring.js";

test("błędna odpowiedź daje zero i zeruje serię", () => {
  const score = calculateQuestionScore({
    correct: false,
    basePoints: 100,
    difficulty: 5,
    currentStreak: 4
  });

  assert.equal(score.total, 0);
  assert.equal(score.nextStreak, 0);
});

test("trudność i seria zwiększają wynik poprawnej odpowiedzi", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 3,
    currentStreak: 2
  });

  assert.equal(score.basePoints, 100);
  assert.equal(score.difficultyBonus, 30);
  assert.equal(score.streakBonus, 20);
  assert.equal(score.total, 150);
  assert.equal(score.nextStreak, 3);
});

test("podpowiedź odejmuje 25 procent od zdobytej puli", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 1,
    currentStreak: 0,
    hintUsed: true
  });

  assert.equal(score.hintPenalty, 25);
  assert.equal(score.total, 75);
});

test("premia za serię nie przekracza 40 punktów", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 1,
    currentStreak: 20
  });

  assert.equal(score.streakBonus, 40);
});

test("dodatkowo odsłonięte tropy odejmują stałą liczbę punktów", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 150,
    difficulty: 1,
    extraPenalty: 20
  });

  assert.equal(score.revealPenalty, 20);
  assert.equal(score.total, 130);
});
