import test from "node:test";
import assert from "node:assert/strict";
import { reorderForTouch } from "../src/ui/screens/timeline-screen.js";

test("gest przesuwa kartę Timeline o liczbę wyczuwalnych kroków", () => {
  const ids = ["a", "b", "c", "d", "e"];
  assert.deepEqual(reorderForTouch(ids, "b", 150), ["a", "c", "d", "b", "e"]);
  assert.deepEqual(reorderForTouch(ids, "d", -145), ["a", "d", "b", "c", "e"]);
  assert.deepEqual(ids, ["a", "b", "c", "d", "e"]);
});

test("krótki gest nie zmienia kolejności, a skrajny zatrzymuje się na granicy", () => {
  const ids = ["a", "b", "c", "d"];
  assert.deepEqual(reorderForTouch(ids, "b", 20), ids);
  assert.deepEqual(reorderForTouch(ids, "c", -999), ["c", "a", "b", "d"]);
  assert.deepEqual(reorderForTouch(ids, "brak", 100), ids);
});
