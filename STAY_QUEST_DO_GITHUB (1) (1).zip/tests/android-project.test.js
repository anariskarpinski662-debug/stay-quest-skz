import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (path) => readFile(resolve(root, path), "utf8");

test("projekt Android celuje w API 36 i nie wymaga bibliotek AndroidX", async () => {
  const [rootBuild, appBuild, settings] = await Promise.all([
    read("android/build.gradle.kts"),
    read("android/app/build.gradle.kts"),
    read("android/settings.gradle.kts")
  ]);

  assert.match(rootBuild, /com\.android\.application"\) version "9\.2\.1"/);
  assert.match(appBuild, /compileSdk = 36/);
  assert.match(appBuild, /minSdk = 28/);
  assert.match(appBuild, /targetSdk = 36/);
  assert.match(appBuild, /versionName = "0\.6\.0"/);
  assert.doesNotMatch(`${rootBuild}${appBuild}${settings}`, /androidx\./i);
});

test("manifest tworzy instalowalną aktywność i pozostawia sieć przeglądarce", async () => {
  const manifest = await read("android/app/src/main/AndroidManifest.xml");
  assert.match(manifest, /android\.permission\.VIBRATE/);
  assert.match(manifest, /android:name="\.MainActivity"/);
  assert.match(manifest, /android:exported="true"/);
  assert.match(manifest, /android\.intent\.category\.LAUNCHER/);
  assert.match(manifest, /android:usesCleartextTraffic="false"/);
  assert.doesNotMatch(manifest, /android\.permission\.INTERNET/);
});

test("natywna osłona blokuje file URL i obsługuje pliki, linki oraz cofanie", async () => {
  const activity = await read("android/app/src/main/java/pl/anaris/stayquest/MainActivity.java");
  assert.match(activity, /appassets\.androidplatform\.net/);
  assert.match(activity, /shouldInterceptRequest/);
  assert.match(activity, /setAllowFileAccess\(false\)/);
  assert.match(activity, /setAllowUniversalAccessFromFileURLs\(false\)/);
  assert.match(activity, /setJavaScriptEnabled\(true\)/);
  assert.match(activity, /addJavascriptInterface\(new StayQuestBridge\(\), "StayQuestAndroid"\)/);
  assert.match(activity, /Intent\.ACTION_CREATE_DOCUMENT/);
  assert.match(activity, /onShowFileChooser/);
  assert.match(activity, /onBackPressed/);
});

test("każdy plik gry osadzony w Androidzie jest identyczny ze źródłem", async () => {
  const serviceWorker = await read("service-worker.js");
  const shell = serviceWorker.match(/const APP_SHELL = \[([\s\S]*?)\];/)?.[1] ?? "";
  const paths = [...shell.matchAll(/"(\.\/[^\"]+)"/g)]
    .map((match) => match[1].slice(2))
    .filter((path) => path && !path.endsWith("/"));

  assert.equal(paths.length, 38);
  for (const path of paths) {
    const [source, embedded] = await Promise.all([
      readFile(resolve(root, path)),
      readFile(resolve(root, "android/app/src/main/assets/www", path))
    ]);
    assert.deepEqual(embedded, source, `${path} różni się od kopii Android`);
  }
});

test("wersja Android wyłącza service workera i używa natywnego eksportu", async () => {
  const [main, app, home] = await Promise.all([
    read("src/main.js"),
    read("src/app/app.js"),
    read("src/ui/screens/home-screen.js")
  ]);
  assert.match(main, /location\.hostname === "appassets\.androidplatform\.net"/);
  assert.match(main, /!isAndroidWrapper && "serviceWorker" in navigator/);
  assert.match(app, /StayQuestAndroid\.saveBackup/);
  assert.match(home, /Aplikacja Android/);
});
