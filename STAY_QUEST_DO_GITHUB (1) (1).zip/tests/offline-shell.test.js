import test from "node:test";
import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");

test("każdy plik zapisany w powłoce offline istnieje", async () => {
  const serviceWorker = await readFile(resolve(root, "service-worker.js"), "utf8");
  const cachedPaths = [
    ...new Set([...serviceWorker.matchAll(/"(\.\/[^"?]+)"/g)].map((match) => match[1]))
  ];

  assert.ok(cachedPaths.length >= 15);

  await Promise.all(
    cachedPaths.map(async (cachedPath) => {
      await assert.doesNotReject(access(resolve(root, cachedPath)));
    })
  );
});
