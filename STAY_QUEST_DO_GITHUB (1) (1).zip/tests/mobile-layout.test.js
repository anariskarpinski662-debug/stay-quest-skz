import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (path) => readFile(resolve(root, path), "utf8");

test("układ obejmuje wąski telefon, wycięcia ekranu i cztery kolumny Memory", async () => {
  const [html, base, layout, components] = await Promise.all([
    read("index.html"),
    read("src/styles/base.css"),
    read("src/styles/layout.css"),
    read("src/styles/components.css")
  ]);
  assert.match(html, /width=device-width, initial-scale=1, viewport-fit=cover/);
  assert.match(base, /min-width: 320px/);
  assert.match(layout, /safe-area-inset-top/);
  assert.match(layout, /safe-area-inset-bottom/);
  assert.match(components, /grid-template-columns: repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(components, /@media \(max-width: 360px\)/);
});

test("Timeline ma osobny uchwyt dotykowy i zachowuje przyciski kierunku", async () => {
  const [screen, components] = await Promise.all([
    read("src/ui/screens/timeline-screen.js"),
    read("src/styles/components.css")
  ]);
  assert.match(screen, /data-timeline-grab/);
  assert.match(screen, /addEventListener\("pointerdown"/);
  assert.match(screen, /addEventListener\("pointermove"/);
  assert.match(screen, /data-action="timeline-move"/);
  assert.match(components, /touch-action: none/);
});
