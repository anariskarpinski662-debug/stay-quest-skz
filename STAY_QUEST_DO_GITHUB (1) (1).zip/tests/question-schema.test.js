import test from "node:test";
import assert from "node:assert/strict";
import {
  QUESTION_TYPES,
  isAnswerCorrect,
  normalizeAnswer,
  validateQuestion,
  validateQuestionBank
} from "../src/game/question-schema.js";
import { QUIZ_QUESTION_COUNT, getQuizQuestions } from "../src/data/question-bank.js";

const choiceQuestion = {
  id: "choice-1",
  modeId: "demo",
  type: QUESTION_TYPES.SINGLE_CHOICE,
  prompt: "Wybierz poprawną odpowiedź.",
  category: "Test",
  kind: "puzzle_interpretation",
  difficulty: 2,
  basePoints: 100,
  options: [
    { id: "a", label: "Pierwsza" },
    { id: "b", label: "Druga" }
  ],
  correctOptionId: "b",
  explanation: "Druga odpowiedź została oznaczona jako poprawna."
};

const textQuestion = {
  id: "text-1",
  modeId: "demo",
  type: QUESTION_TYPES.TEXT,
  prompt: "Wpisz tytuł.",
  category: "Test",
  kind: "puzzle_interpretation",
  difficulty: 1,
  basePoints: 100,
  acceptedAnswers: ["God's Menu", "Gods Menu"],
  displayAnswer: "God's Menu",
  explanation: "Obie wersje zapisu są akceptowane."
};

test("walidator przyjmuje poprawne pytania wyboru i tekstowe", () => {
  assert.deepEqual(validateQuestion(choiceQuestion), { valid: true, errors: [] });
  assert.deepEqual(validateQuestion(textQuestion), { valid: true, errors: [] });
});

test("oficjalny fakt wymaga kompletnego źródła", () => {
  const result = validateQuestion({ ...choiceQuestion, kind: "official_fact" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((error) => error.includes("źródła")));
});

test("oficjalny fakt przyjmuje wyłącznie bezpieczny adres i datę weryfikacji", () => {
  const validOfficial = {
    ...choiceQuestion,
    kind: "official_fact",
    source: {
      title: "Oficjalna strona",
      url: "https://example.com/source",
      checkedAt: "2026-08-19"
    }
  };

  assert.equal(validateQuestion(validOfficial).valid, true);
  assert.equal(
    validateQuestion({ ...validOfficial, source: { ...validOfficial.source, url: "javascript:alert(1)" } }).valid,
    false
  );
});

test("bank odrzuca powtórzone identyfikatory", () => {
  const result = validateQuestionBank([choiceQuestion, { ...textQuestion, id: choiceQuestion.id }]);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((error) => error.includes("Powtórzony")));
});

test("normalizacja ignoruje wielkość liter, apostrof i nadmiarowe odstępy", () => {
  assert.equal(normalizeAnswer("  GOD'S   MENU! "), "gods menu");
  assert.equal(isAnswerCorrect(textQuestion, "gOdS mEnU"), true);
  assert.equal(isAnswerCorrect(textQuestion, "Back Door"), false);
});

test("pytanie wyboru rozpoznaje odpowiedź po identyfikatorze opcji", () => {
  assert.equal(isAnswerCorrect(choiceQuestion, "b"), true);
  assert.equal(isAnswerCorrect(choiceQuestion, "a"), false);
});

test("cały bank pytań przechodzi walidację", () => {
  const bank = ["assoc-master", "emoji-guesser", "hardcore-lore"].flatMap(getQuizQuestions);
  assert.equal(bank.length, QUIZ_QUESTION_COUNT);
  assert.equal(bank.length, 87);
  assert.deepEqual(validateQuestionBank(bank), { valid: true, errors: [] });
});

test("walidator sprawdza zasady stopniowego odsłaniania tropów", () => {
  const question = {
    ...choiceQuestion,
    clues: ["jeden", "dwa", "trzy"],
    cluePolicy: { initialVisible: 2, penaltyPerReveal: 10 }
  };

  assert.equal(validateQuestion(question).valid, true);
  assert.equal(validateQuestion({ ...question, cluePolicy: { initialVisible: 4, penaltyPerReveal: 10 } }).valid, false);
});
