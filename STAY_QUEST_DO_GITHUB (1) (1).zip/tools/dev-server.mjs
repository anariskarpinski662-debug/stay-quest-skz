import { createReadStream, existsSync, statSync } from "node:fs";
import { createServer } from "node:http";
import { extname, resolve, sep } from "node:path";
import { pathToFileURL } from "node:url";

const root = resolve(import.meta.dirname, "..");

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8"
};

export function createStaticServer(rootDirectory = root) {
  return createServer((request, response) => {
    const requestPath = decodeURIComponent(new URL(request.url, `http://${request.headers.host}`).pathname);
    const relativePath = requestPath === "/" ? "index.html" : requestPath.replace(/^\/+/, "");
    let filePath = resolve(rootDirectory, relativePath);

    if (!filePath.startsWith(`${rootDirectory}${sep}`) || !existsSync(filePath)) {
      const acceptsHtml = request.headers.accept?.includes("text/html");
      if (!acceptsHtml) {
        response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        response.end("Nie znaleziono pliku.");
        return;
      }
      filePath = resolve(rootDirectory, "index.html");
    }

    if (statSync(filePath).isDirectory()) filePath = resolve(filePath, "index.html");

    response.writeHead(200, {
      "Cache-Control": "no-cache",
      "Content-Type": contentTypes[extname(filePath)] || "application/octet-stream"
    });

    if (request.method === "HEAD") response.end();
    else createReadStream(filePath).pipe(response);
  });
}

const isMainModule = process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href;

if (isMainModule) {
  const port = Number(process.env.STAY_QUEST_PORT || 4173);
  createStaticServer().listen(port, "0.0.0.0", () => {
    console.log(`STAY QUEST działa pod adresem http://localhost:${port}`);
  });
}
