import { copyFile, mkdir, readFile, rm, stat } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const destination = resolve(root, "android/app/src/main/assets/www");
const serviceWorker = await readFile(resolve(root, "service-worker.js"), "utf8");
const shell = serviceWorker.match(/const APP_SHELL = \[([\s\S]*?)\];/)?.[1];

if (!shell) throw new Error("Nie znaleziono listy APP_SHELL.");

const paths = [...shell.matchAll(/"(\.\/[^\"]+)"/g)]
  .map((match) => match[1].slice(2))
  .filter((path) => path && !path.endsWith("/"));

if (paths.some((path) => path.includes(".."))) throw new Error("Niedozwolona ścieżka w APP_SHELL.");

await rm(destination, { recursive: true, force: true });
await mkdir(destination, { recursive: true });

let totalBytes = 0;
for (const path of paths) {
  const source = resolve(root, path);
  const target = resolve(destination, path);
  await mkdir(dirname(target), { recursive: true });
  await copyFile(source, target);
  totalBytes += (await stat(source)).size;
}

console.log(`Android assets: ${paths.length} plików, ${(totalBytes / 1024).toFixed(1)} KiB`);
