import { readdirSync } from "node:fs";
import { extname, resolve } from "node:path";
import { spawnSync } from "node:child_process";

const root = resolve(import.meta.dirname, "..");
const targets = [resolve(root, "service-worker.js")];

function collect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) collect(path);
    else if ([".js", ".mjs"].includes(extname(path))) targets.push(path);
  }
}

collect(resolve(root, "src"));
collect(resolve(root, "tools"));

for (const path of targets) {
  const result = spawnSync(process.execPath, ["--check", path], { encoding: "utf8" });
  if (result.status !== 0) {
    process.stderr.write(result.stderr);
    process.exit(result.status ?? 1);
  }
}

console.log(`Kontrola składni: OK (${targets.length} plików)`);
