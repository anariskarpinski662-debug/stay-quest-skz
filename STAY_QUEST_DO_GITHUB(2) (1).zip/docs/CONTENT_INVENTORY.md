# Inwentarz treści — wersja 2.0.0

Stan banków dużej aktualizacji:

| Tryb | Zawartość | Długość rundy |
| --- | ---: | --- |
| Mistrz Skojarzeń | 40 zagadek, w tym poziomy Master i Insane | 10 losowych pytań |
| Zgadnij Utwór po Emoji | 40 zagadek, zawsze cztery odpowiedzi A–D | 10 losowych pytań |
| Hardcore Lore Quiz | 147 zagadnień, po 49 na Veteran, Master i Insane | 10 losowych pytań |
| Who Is Who? | 200 zestawów, po 40 na każdy poziom | 10 losowych pytań |
| Discography Builder | 123 konfiguracje | 10 losowych pytań |
| SKZ Timeline Architect | 30 wydarzeń i 40 konfiguracji osi | 4, 6 lub 8 kart, trudność liczona osobno |
| SKZOO Memory Game | 8 postaci i 5 typów dopasowania | 4, 6 lub 8 par zależnie od poziomu |
| Daily Challenge | 10 zadań wybranych deterministycznie na dany dzień | 1 punktowany wynik dziennie |
| STAY Lab: Bratnia Dusza | 40 pytań sytuacyjnych | 25 losowych pytań bez punktów |

Pięć głównych banków quizowych zawiera łącznie 550 zadań. Tasowanie A–D nie jest liczone jako nowa treść. Zagadki skojarzeniowe i emoji są oznaczone jako autorskie interpretacje. Fakty oficjalne mają źródło oraz datę ostatniego sprawdzenia.

Skojarzenia i Emoji mają po 40 jakościowych zadań startowych. Architektura pozwala dodawać dalsze warianty merytoryczne bez przebudowy trybu; docelowe pule 150 Skojarzeń oraz 80–120 wariantów Emoji pozostają kierunkiem dalszej ręcznej rozbudowy i kontroli źródeł.

Bank obejmuje dyskografię od `Mixtape` i `I am NOT` do `RUN IT` oraz `THIS & THAT`, a oś czasu uwzględnia również zwycięstwo w `Kingdom: Legendary War` i serię wejść na pierwsze miejsce Billboard 200.
