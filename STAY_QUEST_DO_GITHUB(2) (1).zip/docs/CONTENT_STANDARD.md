# Standard treści i pytań

## Cel

Gra ma być trudna i fandomowa, ale nie może udawać pewności tam, gdzie istnieje tylko interpretacja lub mem. Warstwa danych musi pozwalać poprawić jedno pytanie bez grzebania w kodzie interfejsu.

## Rodzaje treści

Każdy wpis otrzyma jedno z oznaczeń:

- `official_fact` — informacja możliwa do potwierdzenia w oficjalnym materiale,
- `official_media_detail` — szczegół z oficjalnego filmu, programu, wywiadu lub transmisji,
- `puzzle_interpretation` — autorski skrót symboliczny użyty w skojarzeniu albo emoji,
- `fandom_lore` — mem, przezwisko lub utrwalona interpretacja fandomu,
- `fan_theory` — teoria, której gra nie przedstawia jako faktu.

## Minimalny rekord pytania

Docelowo każde pytanie będzie zawierało:

```js
{
  id: "unikalny-identyfikator",
  mode: "hardcore-lore",
  category: "discography",
  difficulty: 3,
  kind: "official_fact",
  prompt: "Treść pytania",
  answers: ["A", "B", "C", "D"],
  correctAnswer: "A",
  explanation: "Dlaczego ta odpowiedź jest poprawna",
  source: {
    title: "Nazwa oficjalnego materiału",
    url: "https://…",
    checkedAt: "RRRR-MM-DD"
  }
}
```

## Reguły jakości

1. Jedno pytanie ma jedną jednoznaczną odpowiedź.
2. Dystraktory powinny być wiarygodne, ale nie podchwytliwe z powodu nieprecyzyjnego języka.
3. Aktualne osiągnięcia, trasy, ambasadorstwa i harmonogramy wymagają ponownej weryfikacji przed publikacją bazy.
4. Płatne lub prywatne materiały nie są przepisywane ani traktowane jak publiczne źródło.
5. Cytaty nie są wydłużane ponad fragment potrzebny do rozpoznania zagadki.
6. Fandomowy mem albo teoria zawsze otrzymuje widoczną etykietę.
7. Błędne pytanie można wyłączyć bez usuwania historii wyników gracza.
8. W quizach A–D wszystkie odpowiedzi są wiarygodne; nie używamy żartobliwego lub oczywiście zmyślonego dystraktora.
9. Trudność wynika z wymaganej wiedzy, bliskości dat albo jakości tropów, a nie z literówek, języka angielskiego czy niejasnego sformułowania.
10. W trybie Emoji odpowiedzi są oficjalnymi, nieprzetłumaczonymi tytułami utworów i nie wymagają wpisywania tekstu.
11. Duże partie automatycznie przygotowanych pytań nie trafiają do wydania bez kontroli treści oraz źródeł.
