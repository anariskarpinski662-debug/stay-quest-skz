# STAY QUEST 2.0 — wydanie dużej aktualizacji

## Bezpieczeństwo starego postępu

- Aktualizacja używa tego samego głównego klucza zapisu co poprzednia wersja.
- Migrator rozpoznaje również starsze nazwy zapisu i wybiera poprawny profil z największą liczbą punktów.
- Surowy stary zapis jest kopiowany do osobnego klucza bezpieczeństwa przed utrwaleniem wersji 5.
- Stare klucze nie są automatycznie usuwane.
- Zwykły zapis oraz import starszej kopii nie mogą obniżyć punktów.
- Wyzerowanie profilu jest możliwe wyłącznie przez osobną, potwierdzoną funkcję resetu.
- Automatyczny test zachowuje profil 11 076 pkt i rangę Master STAY.

Na telefonie nowy APK należy instalować jako aktualizację istniejącej aplikacji. Nie należy wcześniej odinstalowywać starej wersji, ponieważ Android może wtedy usunąć lokalne dane aplikacji.

## Zakres wersji

- ciepły kremowo-beżowy motyw i odświeżony znak „SQ”,
- osiem głównych trybów oraz osobny STAY Lab,
- 550 zadań quizowych, 40 konfiguracji Timeline i pięć mechanik Memory,
- Emoji wyłącznie w formie A–D,
- dwa poziomy podpowiedzi i edukacyjny feedback,
- anty-powtórki na poziomie identyfikatora i faktu,
- ograniczenie punktów za szybkie powtarzanie tego samego materiału,
- nowa punktacja, progi poziomów i ochrona zdobytej rangi,
- deterministyczny Daily Challenge punktowany raz dziennie,
- Bratnia Dusza bez punktów rankingowych,
- aktywny czas Memory zatrzymywany poza rundą,
- pełna synchronizacja PWA z projektem Android.

## Kontrola wydania

Wersja przechodzi 85 testów automatycznych, kontrolę składni, test HTTP oraz porównanie wszystkich 45 plików osadzonych w Androidzie ze źródłem. Ostatnim krokiem jest beta-test aktualizacji na fizycznym telefonie: instalacja nad starą wersją, sprawdzenie punktów i rozegranie każdej gry.
