# Profil i trwały postęp — wersja 2.0.0

## Co jest zapisywane

Stan aplikacji obejmuje:

- nazwę gracza, punkty, poziom, rangę oraz serie,
- łączne statystyki odpowiedzi i ukończonych rund,
- rekordy każdego z ośmiu głównych trybów,
- najlepsze ruchy i czasy osobno dla plansz Memory,
- największą perfekcyjnie ułożoną oś czasu,
- zdobyte osiągnięcia wraz z datami,
- maksymalnie 30 ostatnich rund i 100 ostatnich pytań na tryb,
- wyniki oraz serię dni Daily Challenge,
- ostatnie dopasowanie i liczbę ukończeń STAY Lab,
- ustawienia interfejsu, dźwięku i wibracji.

Zapis korzysta ze schematu w wersji 5. Migrator rozpoznaje bieżący klucz oraz starsze nazwy zapisu, a następnie wybiera poprawny zapis z największą liczbą punktów. Surowa kopia danych sprzed migracji jest zachowywana, a stare klucze nie są automatycznie usuwane. Zwykły zapis i import nie mogą obniżyć punktów; wyzerowanie wymaga wyraźnie potwierdzonego resetu. Test migracji potwierdza zachowanie profilu 11 076 pkt / Master STAY.

## Poziomy i rangi

Progi zostały ponownie skalibrowane do spokojniejszej ekonomii. Od poziomu 8 kolejne poziomy wymagają po 7000 punktów. Rangi profilu są niezależne od poziomu trudności pytań:

| Minimalny poziom | Ranga |
| ---: | --- |
| 1 | Baby STAY |
| 2 | Rookie STAY |
| 3 | Core STAY |
| 4 | Veteran STAY |
| 5 | Master STAY |
| 8 | Legend STAY |

Pierwsze progi punktowe poziomów to: 0, 1500, 3500, 6000, 9000, 13 000, 18 000 i 24 000. Zapamiętana najwyższa ranga stanowi bezpieczną podłogę, więc migracja nowej ekonomii nie degraduje dotychczasowego profilu.

## Osiągnięcia

Wersja 2.0.0 zawiera 16 osiągnięć. Obejmują liczbę rund, punkty, serie, perfekcyjne rozgrywki, ukończenie pięciu i ośmiu trybów, Daily oraz odznakę Soul Connection. STAY Lab nie daje zwykłych punktów.

## Kopia bezpieczeństwa

Eksport tworzy plik JSON zawierający cały stan profilu. Import sprawdza format, identyfikator aplikacji i wymagane sekcje, a następnie normalizuje dane do bieżącego schematu. Reset wymaga osobnego potwierdzenia. Kopię warto pobrać przed resetem albo zmianą urządzenia.
