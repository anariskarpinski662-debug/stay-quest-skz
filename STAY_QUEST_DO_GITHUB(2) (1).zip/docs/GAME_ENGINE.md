# Wspólny silnik rozgrywki

## Po co istnieje osobny rdzeń

Ekrany nie obliczają samodzielnie punktów ani poprawności. Odpowiada za to warstwa `src/game`, dzięki czemu zasady pozostają identyczne w każdym trybie quizowym i mogą być testowane bez uruchamiania interfejsu.

## Obsługiwane pytania

### Jednokrotny wybór

Pytanie zawiera co najmniej dwie opcje z unikalnymi identyfikatorami. Silnik miesza ich kolejność w każdej nowej rundzie i porównuje identyfikator wybranej opcji z rozwiązaniem.

### Odpowiedź wpisywana

Pytanie może zawierać kilka akceptowanych zapisów. Porównanie ignoruje:

- wielkość liter,
- nadmiarowe odstępy,
- apostrofy i zwykłe znaki interpunkcyjne,
- polskie znaki diakrytyczne.

Poprawna odpowiedź nie jest udostępniana ekranowi przed zatwierdzeniem wyboru.

## Przebieg sesji

Sesja przechodzi przez trzy stany:

1. `active` — gracz odpowiada albo korzysta z podpowiedzi,
2. `answered` — rozwiązanie, punkty i wyjaśnienie są widoczne,
3. `complete` — wszystkie pytania zostały rozliczone i dostępne jest podsumowanie.

Pytania są losowane bez zwracania, więc w jednej rundzie żaden identyfikator się nie powtarza. Silnik daje pierwszeństwo zadaniom spoza historii ostatnich 100 pytań danego trybu. Historia zapisuje również temat/fakt, dlatego ten sam materiał nie wraca od razu pod innym identyfikatorem.

## Punktacja

1. Punkty bazowe pochodzą z rekordu pytania, a do profilu trafia 50% tej wartości przed premiami.
2. Każdy poziom trudności powyżej pierwszego dodaje 12% przyznanej bazy.
3. Od drugiej poprawnej odpowiedzi z rzędu naliczana jest premia 6 punktów za poziom serii, maksymalnie 24 punkty.
4. Pytanie może mieć dwie podpowiedzi z osobnymi kosztami; łączna kara nie przekracza 45% puli.
5. W Mistrzu Skojarzeń dodatkowy odsłonięty trop odejmuje stałą karę zapisaną przy pytaniu.
6. Szybki powrót tego samego faktu stopniowo obniża wartość do 75%, 50% albo 35%; po odpowiednio długiej przerwie wraca pełna wartość.
7. Błędna lub pominięta odpowiedź daje 0 punktów i zeruje bieżącą serię.

Ekran wyniku pokazuje osobno bazę, premię trudności, premię serii, kary za podpowiedzi i tropy oraz ewentualne ograniczenie za szybką powtórkę.

## Ochrona jakości treści

Walidator blokuje uruchomienie wadliwego banku, między innymi gdy:

- dwa pytania mają ten sam identyfikator,
- poprawna opcja nie istnieje,
- pytanie nie ma wyjaśnienia,
- oficjalny fakt nie ma tytułu źródła, bezpiecznego adresu HTTP/HTTPS i daty sprawdzenia,
- poziom trudności wykracza poza skalę 1–5.

## Silnik Timeline

Kontroler korzysta z 40 konfiguracji i rozdziela rozmiar osi od poziomu trudności. Baby może pokazać pełniejszą datę, STAY miesiąc i rok, Veteran rok, Master tylko część dat, a Insane minimalną pomoc. Wynik uwzględnia liczbę kart ustawionych dokładnie na właściwej pozycji, rzeczywistą trudność i premię za perfekcyjną oś.

## Silnik Memory

Kontroler buduje 4, 6 lub 8 par i zmienia typ relacji wraz z poziomem: symbol ↔ SKZOO, SKZOO ↔ członek, członek ↔ data lub trudniejsze zweryfikowane połączenia. Błędna para chwilowo blokuje ruchy. Najważniejsza jest efektywność ruchów; czas daje tylko mały bonus i zatrzymuje się po wyjściu z ekranu albo przejściu aplikacji do tła.

## Przekazanie wyniku do profilu

Każdy ekran przekazuje ujednolicony wynik dopiero przy przejściu sesji do stanu ukończonego. Rekord zawiera identyfikator trybu, rodzaj mechaniki, punkty, skuteczność oraz szczegóły właściwe dla quizu, Timeline albo Memory. Warstwa postępu następnie:

1. aktualizuje rekord danego trybu,
2. dodaje punkty do profilu i przelicza poziom,
3. aktualizuje serie oraz statystyki,
4. zapisuje wpis w historii,
5. sprawdza nowe osiągnięcia,
6. utrwala cały stan na urządzeniu.

Przycisk ponownej gry tworzy nową sesję. Samo ponowne wyrenderowanie podsumowania nie zapisuje wyniku drugi raz.
