# STAY QUEST 1.0 — specyfikacja dużej aktualizacji

Data decyzji: 19.08.2026  
Status: zakres wdrożony; oczekuje na zbudowanie APK i test beta na telefonie.

## 1. Cel aktualizacji

STAY QUEST ma stać się osobistym, instalowanym na telefonie centrum gier dla STAY, a nie tylko listą kilku quizów. Aktualizacja ma:

- zachować szybkie, dotykowe sterowanie i działanie bez internetu,
- rozbudować aplikację z 5 do 8 głównych trybów,
- dodać osobną sekcję rozrywkową STAY Lab,
- zmniejszyć liczbę powtórek,
- wyraźnie rozdzielić rangę gracza od trudności rundy,
- przebudować pytania Emoji na wybór A–D,
- oprzeć fakty na sprawdzonych źródłach,
- poprawić tempo zdobywania punktów i rang,
- przejść z czarnego motywu na ciepły, beżowo-kremowy styl premium.

Prace mogą być wykonywane etapami wewnętrznie, ale Anaris otrzyma jedną dużą aktualizację do zainstalowania po zakończeniu obecnych testów.

## 2. Kierunek wizualny

### Motyw główny

- ciepły krem jako najjaśniejsze tło,
- piaskowy beż dla większych powierzchni,
- taupe i brąz dla obramowań, elementów wtórnych oraz tekstu,
- ciemny, czytelny tekst zamiast jasnego tekstu na kilometrach czerni,
- zachowany elegancki, premium i lekko gamingowy charakter,
- własny kolor akcentu dla każdego trybu,
- duże pola dotykowe i wyraźne stany zaznaczenia.

Beżowy motyw ma być dojrzały i elegancki, a nie przesadnie słodki. Obecny ciemny wygląd może później zostać jako opcja, ale nie jest to warunek pierwszej dużej aktualizacji.

### Proponowany porządek ekranu głównego

1. **Dzisiaj** — wysoko umieszczone Dzisiejsze wyzwanie.
2. **Gry wiedzy** — Skojarzenia, Emoji, Timeline, Hardcore Lore, Who Is Who i Discography Builder.
3. **Gry pamięciowe** — SKZOO Memory.
4. **STAY Lab** — Bratnia Dusza oraz przyszłe zabawy bez dobrych i złych odpowiedzi.

Nie tworzymy jednej bardzo długiej listy dziewięciu równorzędnych kart.

## 3. Główne tryby

| Nr | Tryb | Główna mechanika | Docelowa baza |
|---:|---|---|---:|
| 1 | ✨ Mistrz Skojarzeń | Rozpoznanie utworu, członka lub motywu po 3–5 tropach | minimum 150 zestawów |
| 2 | 🧩 Zgadnij Utwór po Emoji | Wybór oficjalnego tytułu spośród A–D | minimum 40 utworów i 80–120 wariantów |
| 3 | ⏳ SKZ Timeline Architect | Układanie wydarzeń w prawidłowej kolejności | minimum 40 układanek |
| 4 | ⚡ Hardcore Lore Quiz | Trudne pytania faktograficzne A–D | docelowo 180–210 pytań |
| 5 | 💎 SKZOO Memory Game | Odkrywanie i łączenie par | minimum 40 konfiguracji |
| 6 | 👤 Who Is Who? | Rozpoznanie członka po przecięciu kilku faktów | minimum 40 zestawów na poziom |
| 7 | 💿 Discography Builder | Albumy, utwory, tracklisty, unity i chronologia | minimum 100 konfiguracji, docelowo 200+ |
| 8 | 🎯 Daily Challenge | Jeden wspólny zestaw z kilku trybów na dany dzień | korzysta z pozostałych baz |

### Mistrz Skojarzeń

- Każda zagadka ma 3–5 tropów.
- Żaden pojedynczy trop nie może praktycznie podawać odpowiedzi.
- Zestawy otrzymują poziomy trudności 1–5.
- Kolejność tropów i odpowiedzi może się zmieniać.
- Trudniejsza runda ma wymagać lepszej znajomości materiału, a nie rozszyfrowania niejasnego zdania.

### Zgadnij Utwór po Emoji

- Odpowiedź jest zawsze wybierana przyciskiem A–D; nie trzeba wpisywać angielskiego tytułu.
- Wszystkie cztery opcje są prawdziwymi, oficjalnymi tytułami utworów Stray Kids.
- Tytułów nie tłumaczymy na polski.
- Nie używamy żartobliwych, zmyślonych lub oczywiście błędnych odpowiedzi.
- Dystraktory są wiarygodne i na wyższych poziomach bardziej zbliżone znaczeniowo.
- Pozycja poprawnej odpowiedzi jest losowana.
- Jeden utwór może mieć 2–3 różne układy emoji oraz różne zestawy odpowiedzi.
- Trudność wynika z liczby i nieoczywistości emoji oraz jakości dystraktorów, nigdy z pisowni tytułu.

### Timeline Architect

- Jedna układanka zawiera 5–10 wydarzeń zależnie od poziomu.
- Na łatwiejszym poziomie wydarzenia są oddalone od siebie o lata.
- Na trudniejszym poziomie mogą pochodzić z tego samego roku albo być oddalone o miesiące lub tygodnie.
- Trudność nie polega wyłącznie na dokładaniu kolejnych kart.
- Każde wydarzenie wymagające dokładnej daty ma sprawdzone źródło.

### Hardcore Lore Quiz

- Nazwa „Hardcore” ma zachować znaczenie, dlatego tryb zaczyna się od trudniejszej wiedzy.
- Preferowany podział: Veteran, Master i Insane, po 60–70 sprawdzonych pytań.
- Wszystkie pytania mają jasne brzmienie i cztery wiarygodne odpowiedzi.
- Nie używamy pytań, które zdradzają odpowiedź w samej treści.
- Nie mylimy oficjalnych faktów z fandomowymi memami lub teoriami.

### SKZOO Memory Game

- poziom 1: 4 pary,
- poziom 2: 6 par,
- poziom 3: 8 par,
- poziom 4: więcej kart lub wizualnie podobniejsze warianty,
- poziom 5: limit czasu albo liczby ruchów,
- układ kart jest losowany przy każdej rozgrywce,
- punktacja zostanie obniżona lub przeliczona, ponieważ krótka plansza 4 par obecnie daje około 1125–1150 pkt i zbyt szybko podnosi rangę.

### Who Is Who?

- Odpowiedź wynika z połączenia kilku faktów, a nie z jednego oczywistego hasła.
- Unikamy pytań w rodzaju „Który członek jest liderem?”.
- Wyższe poziomy korzystają z mniej oczywistych oficjalnych materiałów, historii grupy, unitów i dyskografii.
- Format odpowiedzi: A–D.

### Discography Builder

Tryb obsługuje kilka rodzajów zadań:

- album → utwory,
- utwór → album,
- chronologia albumów,
- chronologia utworów,
- unit → utwór,
- wydanie koreańskie lub japońskie,
- title track lub B-side,
- wybór intruza,
- ułożenie poprawnej tracklisty.

## 4. Daily Challenge

Dzisiejsze wyzwanie pojawia się wysoko na ekranie głównym i stanowi powód do codziennego powrotu.

### Ustalony zestaw dzienny

Jedna sesja zawiera **10 zadań**:

- 2 × Mistrz Skojarzeń,
- 2 × Emoji,
- 1 × Timeline,
- 2 × Hardcore Lore,
- 1 × Who Is Who,
- 2 × Discography Builder.

Memory może pojawić się czasem jako dodatkowy bonus, ale nie zastępuje stałej dziesiątki.

### Zasady

- Wszyscy gracze na danym urządzeniu otrzymują ten sam zestaw dla konkretnej daty.
- Ponowne uruchomienie aplikacji nie losuje łatwiejszych pytań.
- Główny wynik można zapisać tylko raz dziennie.
- Ekran pokazuje wynik, punkty i serię kolejnych dni, np. `7/10 • 1450 pkt • seria 12 dni`.
- Nie tworzymy osobnej bazy pytań — Daily korzysta ze sprawdzonych baz pozostałych trybów.

## 5. STAY Lab — Bratnia Dusza

„Kto jest Twoją bratnią duszą?” jest osobną zabawą fandomową, a nie dziewiątą grą wiedzy.

### Zasady

- Wyraźna informacja, że wynik jest zabawą fandomową, a nie testem psychologicznym.
- Baza zawiera 40–50 pytań sytuacyjnych.
- Jedna sesja losuje 25–30 pytań.
- Pytania dotyczą zachowania, komunikacji, odpoczynku, spontaniczności, planowania, humoru, relacji, kreatywności i podejmowania decyzji.
- Nie pytamy bezpośrednio o ulubionego członka.
- Nie używamy odpowiedzi, które zbyt łatwo wskazują konkretną osobę.
- Każda odpowiedź przyznaje niewidoczne w trakcie testu wagi kilku członkom.
- Wynik pokazuje pierwsze trzy dopasowania procentowe oraz krótkie wyjaśnienie wspólnych cech.
- Quiz nie przyznaje zwykłych punktów do poziomu profilu.
- Pierwsze ukończenie odblokowuje osobną odznakę **Soul Connection**.
- Kolejne podejścia są dostępne wyłącznie dla zabawy.

## 6. Ranga gracza a trudność gry

To są dwa oddzielne systemy.

### Ranga profilu

Ranga pokazuje całe doświadczenie i dotychczasowy postęp gracza. Nie obniża się po wybraniu łatwiejszej rundy. Obecne rangi profilu mogą pozostać, w tym Rookie STAY, Core STAY i Master STAY.

### Poziom rundy

Poziom rundy określa trudność aktualnie losowanych zadań:

1. Poziom 1 — podstawowy,
2. Poziom 2 — standardowy,
3. Poziom 3 — Veteran,
4. Poziom 4 — Master,
5. Poziom 5 — Insane.

Na ekranie używamy opisu **Poziom gry**, aby nie pomylić go z rangą profilu. Konkretne nazwy dwóch pierwszych poziomów można jeszcze dopracować po testach.

### Skład rundy

- Gracz może wybrać konkretny poziom albo rundę mieszaną.
- Runda mieszana korzysta z ustalonego rozkładu trudności, nie z całkowicie przypadkowych 10 pytań.
- Wysoki poziom profilu może domyślnie proponować trudniejszy zestaw, ale nie blokuje łatwiejszych rozgrywek.

## 7. Reguły wszystkich quizów A–D

1. Pytanie nie zawiera odpowiedzi w swojej treści.
2. Jedna odpowiedź jest jednoznacznie poprawna.
3. Wszystkie odpowiedzi są wiarygodne w kontekście pytania.
4. Pozycja poprawnej odpowiedzi jest tasowana.
5. Nie zwiększamy trudności literówkami, złym tłumaczeniem ani niejasnym językiem.
6. Po odpowiedzi pokazujemy krótkie wyjaśnienie lub ciekawostkę.
7. Lore i Who Is Who zawsze korzystają z A–D.
8. Emoji zawsze korzysta z A–D i oficjalnych, nieprzetłumaczonych tytułów.

## 8. System anty-powtórkowy

- Każdy tryb pamięta identyfikatory ostatnich 50–100 pokazanych zadań.
- Ostatnio widziane zadania otrzymują znacznie mniejszą szansę ponownego losowania.
- Starsze pytania wracają stopniowo dopiero po wykorzystaniu dużej części dostępnej puli.
- Osobno tasujemy kolejność odpowiedzi, warianty emoji, tropy i konfiguracje zadania.
- System zapisuje historię lokalnie razem z postępem użytkownika.

Nie obiecujemy absolutnego braku powtórek w nieskończoność; celem jest rozsądne wykorzystanie całej puli przed powrotem do znanych zadań.

## 9. Standard faktów i źródeł

- Oficjalny fakt, szczegół oficjalnego materiału, fandomowy mem, interpretacja zagadki i teoria fana pozostają osobnymi rodzajami treści.
- Pytania faktograficzne przechodzą kontrolę źródła przed dodaniem do wydania.
- Przy faktach zmieniających się w czasie zapisujemy datę ostatniego sprawdzenia.
- Nie generujemy automatycznie setek pytań i nie publikujemy ich bez ręcznej kontroli.
- Błędne lub niepewne pytanie można wyłączyć bez usuwania historii gracza.
- Fandomowy mem lub teoria nie jest przedstawiana jako oficjalny fakt.

## 10. Wnioski z pierwszej bety

| Obserwacja Anarisa | Decyzja do aktualizacji |
|---|---|
| Emoji jest za trudne przez wpisywanie tytułów po angielsku | Stałe odpowiedzi A–D |
| Jedna runda Mistrza Skojarzeń była zdecydowanie za łatwa | Wybór poziomu i kontrolowany skład rundy |
| Krótki Memory daje ponad 1100 pkt | Ponowne wyważenie punktów Memory |
| Master STAY udało się zdobyć bardzo szybko | Ponowne wyważenie progów rang i całej punktacji |
| Ciemny wygląd działa, ale beżowo-kremowy byłby przyjemniejszy | Nowy ciepły motyw premium |
| Nakładanie się elementów systemowych nie przeszkadza obecnie w grze | Nie blokuje dużej aktualizacji; wracamy do tego tylko, jeśli zacznie przeszkadzać |

Dotychczasowy postęp Anarisa jest wartościowym materiałem testowym i nie powinien zostać utracony podczas aktualizacji.

## 11. Bezpieczna aktualizacja na telefonie

Przed przekazaniem dużej wersji:

1. eksportujemy kopię obecnego postępu,
2. przygotowujemy aplikację tak, aby kolejne wersje można było aktualizować w stały sposób,
3. instalujemy nową wersję,
4. przywracamy postęp, jeśli telefon wymagał usunięcia wcześniejszej wersji,
5. sprawdzamy punkty, rangę, rekordy i odznaki po migracji.

Użytkownik nie musi wykonywać aktualizacji po każdej drobnej zmianie.

## 12. Kolejność prac wewnętrznych

### Etap A — mechanika i wyważenie

- Emoji A–D,
- oddzielenie rangi od poziomu trudności,
- kontrolowany skład rund,
- system anty-powtórkowy,
- korekta punktacji Memory i progów rang.

### Etap B — nowy układ i tryby

- beżowo-kremowy interfejs,
- nowy podział strony głównej,
- Who Is Who,
- Discography Builder,
- Daily Challenge.

### Etap C — STAY Lab

- Bratnia Dusza,
- ukryte wagi odpowiedzi,
- karta trzech dopasowań,
- odznaka Soul Connection.

### Etap D — baza i kontrola jakości

- stopniowe rozszerzanie banków,
- weryfikacja źródeł,
- test różnych poziomów,
- sprawdzenie powtórek,
- test przeniesienia profilu,
- jedna duża paczka do instalacji i dalszej bety.

## 13. Otwarte decyzje do późniejszych testów

- czy obecny ciemny motyw zostaje jako opcjonalny drugi motyw,
- ostateczne nazwy poziomów 1 i 2,
- jak często Memory pojawia się jako bonus Daily,
- dokładne wartości punktów i progów rang,
- czy po prywatnej becie aplikacja pozostaje tylko dla Anarisa, czy przygotowujemy wydanie dla innych STAY.
