# STAY QUEST 2.0 — Duża aktualizacja

Mobilna, instalowalna gra dla STAY. Pełna zawartość działa offline w natywnej aplikacji Android, a postęp jest zapisywany lokalnie na telefonie.

## Najważniejsze zmiany wersji 2.0

- ciepły kremowo-beżowy motyw premium z osobnymi kolorami trybów,
- 8 głównych trybów: Skojarzenia, Emoji, Timeline, Lore, Who Is Who, Dyskografia, Memory i Daily,
- osobny STAY Lab z zabawą „Kto jest Twoją bratnią duszą?”,
- niezależny wybór trudności: Baby STAY, STAY, Veteran, Master, Insane albo runda mieszana,
- 550 rzeczywiście różnych zadań w pięciu bankach quizowych,
- 40 Skojarzeń, 40 Emoji, 147 Lore, 200 Who Is Who oraz 123 konfiguracje Dyskografii,
- 40 konfiguracji Timeline z różną bliskością wydarzeń i pomocą datami,
- Emoji zawsze jako cztery klikalne odpowiedzi A–D — bez wpisywania angielskiego tytułu,
- Hardcore Lore zaczyna się od poziomu Veteran,
- pamięć ostatnich 100 pytań w każdym trybie, pierwszeństwo świeżych zadań i blokowanie szybkiego powrotu tego samego faktu,
- Daily Challenge: 10 mieszanych zadań, stały zestaw na dany dzień i tylko jeden punktowany wynik,
- Bratnia Dusza: 25 pytań z puli 40, trzy wyniki dopasowania i odznaka za pierwsze ukończenie, ale bez punktów do rangi,
- dwupoziomowe podpowiedzi i edukacyjny feedback po każdej odpowiedzi,
- spokojniejsza punktacja Memory i całej gry oraz stopniowe ograniczanie punktów za szybkie powtórki,
- różne typy par Memory, aktywny licznik zatrzymywany po opuszczeniu gry i nacisk na liczbę ruchów,
- 16 osiągnięć, rekordy 8 trybów i historia 30 ostatnich rund,
- bezpieczna migracja poprzedniego zapisu do schematu wersji 5: aplikacja wybiera zapis z najwyższym progresem, zachowuje stare klucze i tworzy kopię danych sprzed migracji,
- eksport i import kopii postępu w pliku JSON,
- odświeżone logo „SQ” oraz ikona PWA/Android w kolorach kremu, taupe i ciepłego brązu,
- Android API 36, pełna gra offline i 45 zsynchronizowanych plików aplikacji,
- 85 automatycznych testów logiki, danych, migracji, Androida, dostępności i działania HTTP.

## Uruchomienie

W katalogu projektu:

```bash
npm run dev
```

Następnie otwórz `http://localhost:4173`. Projekt Android znajduje się w katalogu `android/`; szczegóły kompilacji opisuje `docs/ANDROID_BUILD.md`.

## Kontrola jakości

```bash
npm test
npm run check
npm run smoke
npm run sync:android
```

## Architektura

```text
android/                  natywna osłona Android i osadzona gra offline
assets/icons/             ikony PWA i Android
docs/                     specyfikacja, standard treści i instrukcje
src/app/                  uruchomienie, router, migracja i trwały stan
src/data/                 tryby, osiągnięcia, pytania i wydarzenia
src/game/                 sesje, punktacja oraz naliczanie postępu
src/styles/               tokeny, baza, układ i ciepły motyw
src/ui/components/        elementy wielokrotnego użytku
src/ui/screens/           kompletne ekrany aplikacji
tests/                    automatyczne testy
tools/                    serwer, synchronizacja Androida i kontrola składni
```

## Zasada treści

Fakty oficjalne, autorskie zagadki, fandomowe lore i interpretacje są rozdzielone. Każde pytanie faktograficzne ma wyjaśnienie oraz źródło z datą sprawdzenia. Nowe fakty nie trafiają do gry bez kontroli źródła.
