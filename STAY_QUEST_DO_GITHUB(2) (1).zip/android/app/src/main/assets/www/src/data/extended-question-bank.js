import { QUESTION_TYPES } from "../game/question-schema.js";

const CHECKED_AT = "2026-08-19";

const SOURCES = Object.freeze({
  profile: {
    title: "JYP Entertainment — oficjalny profil Stray Kids",
    url: "https://straykids.jype.com/Default/Profile?Idx=6",
    checkedAt: CHECKED_AT
  },
  early: {
    title: "JYP Entertainment — oficjalna dyskografia Stray Kids (2018)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=10",
    checkedAt: CHECKED_AT
  },
  middle: {
    title: "JYP Entertainment — oficjalna dyskografia Stray Kids (2018–2021)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=7",
    checkedAt: CHECKED_AT
  },
  recent: {
    title: "JYP Entertainment — oficjalna dyskografia Stray Kids (2021–2024)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=5",
    checkedAt: CHECKED_AT
  },
  current: {
    title: "JYP Entertainment — bieżąca dyskografia Stray Kids",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=1",
    checkedAt: CHECKED_AT
  },
  thisAndThat: {
    title: "JYP Entertainment — oficjalny opis albumu THIS & THAT",
    url: "https://straykids.jype.com/Mobile/DiscographyView?AamSeq=282&AmSeq=0&PgIndex=1",
    checkedAt: CHECKED_AT
  }
});

function optionId(label) {
  return String(label)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function options(answer, alternatives) {
  return [answer, ...alternatives].map((label) => ({ id: optionId(label), label }));
}

const WHO_MEMBERS = [
  {
    name: "Bang Chan",
    clueSets: [
      [1, "rocznik 1997", "najstarszy z całej ósemki", "Wolf Chan"],
      [2, "październikowe urodziny", "należy do 3RACHA", "jego SKZOO jest wilkiem"],
      [3, "urodziny trzeciego dnia miesiąca", "urodził się przed Lee Know", "nie należy do roczników 1999–2001"],
      [4, "najstarszy członek 3RACHA", "dzieli miesiąc urodzin z Lee Know", "jego maskotka nie jest królikiem"],
      [5, "jedyny członek urodzony w 1997 roku", "starszy od drugiego najstarszego o ponad rok", "jego SKZOO ma w nazwie Chan"]
    ]
  },
  {
    name: "Lee Know",
    clueSets: [
      [1, "rocznik 1998", "październikowe urodziny", "Leebit"],
      [2, "drugi najstarszy w grupie", "urodziny później w październiku niż Bang Chan", "jego SKZOO jest królikiem"],
      [3, "urodził się przed Changbinem", "nie należy do 3RACHA", "jest jedynym członkiem z rocznika 1998"],
      [4, "dzieli miesiąc urodzin z najstarszym członkiem", "jego urodziny przypadają 25. dnia miesiąca", "maskotka ma uszy królika"],
      [5, "między jego rokiem urodzenia a rokiem Hyunjina są dwa lata", "jest starszy od jedynego członka z rocznika 1999", "jego SKZOO zaczyna się literą L"]
    ]
  },
  {
    name: "Changbin",
    clueSets: [
      [1, "rocznik 1999", "sierpniowe urodziny", "Dwaekki"],
      [2, "należy do 3RACHA", "urodził się przed całą linią 2000", "jego SKZOO łączy dwa zwierzęta"],
      [3, "urodziny jedenastego dnia miesiąca", "młodszy od Lee Know", "starszy od Hyunjina"],
      [4, "jedyny członek urodzony w 1999 roku", "miesiąc urodzin ma bezpośrednio przed wrześniowym trio", "maskotka jest połączeniem świnki i królika"],
      [5, "środkowy wiekiem w 3RACHA", "nie jest częścią rocznika 2000", "jego SKZOO nie jest pojedynczym gatunkiem"]
    ]
  },
  {
    name: "Hyunjin",
    clueSets: [
      [1, "marcowe urodziny", "rocznik 2000", "Jiniret"],
      [2, "najstarszy spośród członków urodzonych w 2000 roku", "urodziny dwudziestego dnia miesiąca", "jego SKZOO ma smukłą sylwetkę"],
      [3, "urodził się po Changbinie, ale przed Hanem", "nie ma urodzin we wrześniu", "jego maskotka to Jiniret"],
      [4, "jedyny z rocznika 2000 urodzony w pierwszej połowie roku", "urodziny przypadają w pierwszym kwartale", "nie należy do 3RACHA"],
      [5, "od jego urodzin do urodzin Hana mija prawie pół roku", "jest czwarty w kolejności wieku", "nazwa jego SKZOO kończy się na -ret"]
    ]
  },
  {
    name: "Han",
    clueSets: [
      [1, "urodziny 14 września", "rocznik 2000", "HAN QUOKKA"],
      [2, "należy do 3RACHA", "urodził się dzień przed Felixem", "jego SKZOO jest kuoką"],
      [3, "pierwszy z wrześniowej trójki urodzinowej", "młodszy od Hyunjina", "starszy od Felixa dokładnie o jeden dzień"],
      [4, "środkowy członek pod względem wieku w całej ósemce", "jego data urodzin bezpośrednio poprzedza datę Felixa", "nazwa SKZOO zawiera jego pseudonim"],
      [5, "najmłodszy członek 3RACHA", "urodził się w tym samym miesiącu i roku co Felix i Seungmin", "jego maskotka nie jest ptakiem ani psem"]
    ]
  },
  {
    name: "Felix",
    clueSets: [
      [1, "urodziny 15 września", "rocznik 2000", "BbokAri"],
      [2, "urodził się dzień po Hanie", "urodziny tydzień przed Seungminem", "jego SKZOO jest pisklęciem"],
      [3, "drugi z wrześniowej trójki urodzinowej", "młodszy od Hana o jeden dzień", "starszy od Seungmina"],
      [4, "jego urodziny leżą dokładnie między datami Hana i Seungmina", "nie należy do 3RACHA", "nazwa jego maskotki zaczyna się na B"],
      [5, "piąty w kolejności wieku", "dzieli rok i miesiąc urodzin z dwoma członkami", "jego SKZOO ma dziób"]
    ]
  },
  {
    name: "Seungmin",
    clueSets: [
      [1, "urodziny 22 września", "rocznik 2000", "PuppyM"],
      [2, "najmłodszy spośród członków z rocznika 2000", "urodziny tydzień po Felixie", "jego SKZOO jest psem"],
      [3, "trzeci z wrześniowej trójki urodzinowej", "starszy od I.N", "młodszy od Felixa"],
      [4, "jego data zamyka serię wrześniowych urodzin", "nie należy do 3RACHA", "nazwa maskotki kończy się wielką literą M"],
      [5, "przedostatni w kolejności wieku", "urodził się siedem dni po Felixie", "jego SKZOO nie jest leśnym zwierzęciem"]
    ]
  },
  {
    name: "I.N",
    clueSets: [
      [1, "rocznik 2001", "lutowe urodziny", "FoxI.Ny"],
      [2, "najmłodszy z całej ósemki", "urodziny ósmego dnia miesiąca", "jego SKZOO jest lisem"],
      [3, "urodził się po wszystkich członkach rocznika 2000", "jako jedyny ma urodziny w lutym", "nazwa maskotki zawiera jego pseudonim"],
      [4, "jedyny członek urodzony po 2000 roku", "jego urodziny są najwcześniej w roku kalendarzowym", "maskotka ma lisie uszy"],
      [5, "od jego urodzin do urodzin Bang Chana dzielą ponad trzy lata", "zamyka kolejność wieku", "jego SKZOO kończy się literami Ny"]
    ]
  }
];

const WHO_NAMES = WHO_MEMBERS.map(({ name }) => name);

const WHO_REVIEWED_CLUES = Object.freeze({
  "Bang Chan": [
    [1, "należy do 3RACHA", "urodził się w latach 90.", "ma urodziny w drugiej połowie roku"],
    [2, "jest starszy od każdego członka z rocznika 2000", "należy do jednostki producenckiej", "miesiąc urodzin dzieli z innym członkiem"],
    [3, "urodził się przed Changbinem", "nie należy do rocznika 1998 ani 1999", "jest jednym z dwóch październikowych solenizantów"],
    [4, "w 3RACHA nie jest najmłodszy", "urodził się przed Lee Know", "jego miesiąc urodzin przypada po wrześniowej trójce"],
    [5, "należy do 3RACHA", "nie ma urodzin w sierpniu ani wrześniu", "jest starszy od członka urodzonego 25. dnia tego samego miesiąca"]
  ],
  "Lee Know": [
    [1, "nie należy do 3RACHA", "urodził się w latach 90.", "ma urodziny w drugiej połowie roku"],
    [2, "urodził się przed Changbinem", "miesiąc urodzin dzieli z innym członkiem", "nie jest najstarszy w grupie"],
    [3, "nie należy do rocznika 2000", "urodził się po Bang Chanie", "urodziny ma później w miesiącu niż Bang Chan"],
    [4, "jest starszy od członka 3RACHA z sierpnia", "nie należy do jednostki producenckiej", "jego miesiąc urodzin następuje po wrześniu"],
    [5, "urodził się w latach 90.", "nie ma urodzin w sierpniu", "jest młodszy od jednego październikowego solenizanta i starszy od drugiego członka 90s line"]
  ],
  Changbin: [
    [1, "należy do 3RACHA", "urodził się w latach 90.", "ma urodziny w drugiej połowie roku"],
    [2, "urodził się po Lee Know", "urodził się przed linią 2000", "należy do jednostki producenckiej"],
    [3, "nie ma urodzin we wrześniu ani październiku", "jest młodszy od Lee Know", "jest starszy od Hyunjina"],
    [4, "w 3RACHA nie jest ani najstarszy, ani najmłodszy", "urodził się przed Hanem", "miesiąc jego urodzin poprzedza wrzesień"],
    [5, "należy do 3RACHA", "urodził się w roku między Lee Know a linią 2000", "jego urodziny przypadają przed wrześniową serią"]
  ],
  Hyunjin: [
    [1, "urodził się w 2000 roku", "nie należy do 3RACHA", "ma urodziny w pierwszej połowie roku"],
    [2, "urodził się po Changbinie", "urodził się przed Hanem", "nie ma urodzin w drugiej połowie roku"],
    [3, "należy do linii 2000", "nie jest wrześniowym solenizantem", "nie należy do jednostki producenckiej"],
    [4, "jest starszy od całej wrześniowej trójki", "urodził się później niż członkowie z lat 90.", "urodziny ma przed początkiem lata"],
    [5, "nie należy do 3RACHA", "urodził się w tym samym roku co Han", "jego miesiąc urodzin jest wcześniejszy niż miesiące pozostałych członków z tego rocznika"]
  ],
  Han: [
    [1, "urodził się w 2000 roku", "należy do 3RACHA", "ma urodziny we wrześniu"],
    [2, "jest młodszy od Hyunjina", "jest starszy od Felixa", "należy do jednostki producenckiej"],
    [3, "należy do wrześniowej trójki", "urodził się przed Seungminem", "w 3RACHA jest młodszy od Changbina"],
    [4, "dzieli rok i miesiąc urodzin z dwoma członkami", "należy do 3RACHA", "jego data poprzedza datę jednego z nich"],
    [5, "urodził się po Hyunjinie", "należy do jednostki producenckiej", "w swoim miesiącu urodzin jest pierwszy w kolejności"]
  ],
  Felix: [
    [1, "urodził się w 2000 roku", "nie należy do 3RACHA", "ma urodziny we wrześniu"],
    [2, "urodził się po Hanie", "urodził się przed Seungminem", "należy do linii 2000"],
    [3, "jest jednym z trzech wrześniowych solenizantów", "nie należy do jednostki producenckiej", "jego data leży między datami dwóch członków"],
    [4, "dzieli rok i miesiąc urodzin z Hanem", "urodził się przed najmłodszym członkiem tej trójki", "nie należy do 3RACHA"],
    [5, "urodził się po członku 3RACHA z tego samego miesiąca", "urodził się przed Seungminem", "należy do rocznika 2000"]
  ],
  Seungmin: [
    [1, "urodził się w 2000 roku", "nie należy do 3RACHA", "ma urodziny we wrześniu"],
    [2, "urodził się po Felixie", "urodził się przed członkiem z rocznika 2001", "należy do wrześniowej trójki"],
    [3, "dzieli rok i miesiąc urodzin z Hanem", "nie należy do jednostki producenckiej", "jego data jest najpóźniejsza w tej trójce"],
    [4, "jest młodszy od Felixa", "jest starszy od I.N", "urodził się w drugiej połowie roku"],
    [5, "urodził się po dwóch członkach z tego samego miesiąca", "nie należy do 3RACHA", "należy do linii 2000"]
  ],
  "I.N": [
    [1, "nie należy do 3RACHA", "ma urodziny w pierwszej połowie roku", "nie urodził się w latach 90."],
    [2, "urodził się po Hyunjinie", "ma urodziny przed początkiem lata", "nie należy do rocznika 2000"],
    [3, "nie należy do jednostki producenckiej", "jest młodszy od Seungmina", "miesiąc urodzin przypada przed marcem"],
    [4, "urodził się po całej wrześniowej trójce", "nie urodził się w latach 90.", "urodziny ma w pierwszym kwartale"],
    [5, "ma urodziny wcześniej w roku kalendarzowym niż Hyunjin", "urodził się później niż linia 2000", "nie należy do 3RACHA"]
  ]
});

const WHO_PROFILES = Object.freeze([
  { name: "Bang Chan", year: 1997, month: 10, day: 3, order: 1, racha: true },
  { name: "Lee Know", year: 1998, month: 10, day: 25, order: 2, racha: false },
  { name: "Changbin", year: 1999, month: 8, day: 11, order: 3, racha: true },
  { name: "Hyunjin", year: 2000, month: 3, day: 20, order: 4, racha: false },
  { name: "Han", year: 2000, month: 9, day: 14, order: 5, racha: true },
  { name: "Felix", year: 2000, month: 9, day: 15, order: 6, racha: false },
  { name: "Seungmin", year: 2000, month: 9, day: 22, order: 7, racha: false },
  { name: "I.N", year: 2001, month: 2, day: 8, order: 8, racha: false }
]);

const WHO_TRAITS = Object.freeze([
  { id: "racha", label: "należy do 3RACHA", test: (p) => p.racha },
  { id: "not-racha", label: "nie należy do 3RACHA", test: (p) => !p.racha },
  { id: "nineties", label: "urodził się w latach 90.", test: (p) => p.year < 2000 },
  { id: "new-millennium", label: "urodził się w 2000 roku lub później", test: (p) => p.year >= 2000 },
  { id: "year-2000", label: "należy do linii 2000", test: (p) => p.year === 2000 },
  { id: "not-2000", label: "nie należy do linii 2000", test: (p) => p.year !== 2000 },
  { id: "first-half", label: "ma urodziny w pierwszej połowie roku", test: (p) => p.month <= 6 },
  { id: "second-half", label: "ma urodziny w drugiej połowie roku", test: (p) => p.month >= 7 },
  { id: "september", label: "ma urodziny we wrześniu", test: (p) => p.month === 9 },
  { id: "not-september", label: "nie ma urodzin we wrześniu", test: (p) => p.month !== 9 },
  { id: "q1", label: "urodziny ma w pierwszym kwartale", test: (p) => p.month <= 3 },
  { id: "q3", label: "urodziny ma w trzecim kwartale", test: (p) => p.month >= 7 && p.month <= 9 },
  { id: "q4", label: "urodziny ma w czwartym kwartale", test: (p) => p.month >= 10 },
  { id: "day-low", label: "dzień urodzin ma mniejszy niż 15", test: (p) => p.day < 15 },
  { id: "day-high", label: "dzień urodzin ma równy 15 lub większy", test: (p) => p.day >= 15 },
  { id: "day-even", label: "dzień jego urodzin jest liczbą parzystą", test: (p) => p.day % 2 === 0 },
  { id: "day-odd", label: "dzień jego urodzin jest liczbą nieparzystą", test: (p) => p.day % 2 === 1 },
  { id: "top-half", label: "należy do starszej połowy grupy", test: (p) => p.order <= 4 },
  { id: "bottom-half", label: "należy do młodszej połowy grupy", test: (p) => p.order >= 5 },
  { id: "older-han", label: "jest starszy od Hana", test: (p) => p.order < 5 },
  { id: "younger-changbin", label: "jest młodszy od Changbina", test: (p) => p.order > 3 },
  { id: "older-felix", label: "jest starszy od Felixa", test: (p) => p.order < 6 },
  { id: "younger-hyunjin", label: "jest młodszy od Hyunjina", test: (p) => p.order > 4 },
  { id: "month-early", label: "jego miesiąc urodzin wypada przed wrześniem", test: (p) => p.month < 9 },
  { id: "month-late", label: "jego miesiąc urodzin wypada we wrześniu lub później", test: (p) => p.month >= 9 },
  { id: "year-even", label: "jego rok urodzenia jest liczbą parzystą", test: (p) => p.year % 2 === 0 },
  { id: "year-odd", label: "jego rok urodzenia jest liczbą nieparzystą", test: (p) => p.year % 2 === 1 }
]);

function combinations(items, size, start = 0, selected = [], output = []) {
  if (selected.length === size) {
    output.push([...selected]);
    return output;
  }
  for (let index = start; index <= items.length - (size - selected.length); index += 1) {
    selected.push(items[index]);
    combinations(items, size, index + 1, selected, output);
    selected.pop();
  }
  return output;
}

function createWhoLogicSets(profile) {
  const usableTraits = WHO_TRAITS.filter((trait) => trait.test(profile));
  const valid = [2, 3, 4].flatMap((size) => combinations(usableTraits, size))
    .filter((traits) => {
      const matches = WHO_PROFILES.filter((candidate) => traits.every((trait) => trait.test(candidate)));
      return matches.length === 1 && matches[0].name === profile.name;
    })
    .sort((first, second) => first.length - second.length || first.map(({ id }) => id).join("-").localeCompare(second.map(({ id }) => id).join("-")));

  const selected = [];
  const used = new Set();
  const take = (preferredSizes, count) => {
    const candidates = valid.filter((traits) => preferredSizes.includes(traits.length) && !used.has(traits.map(({ id }) => id).join("|")));
    for (let index = 0; index < count; index += 1) {
      const candidate = candidates[Math.floor(index * candidates.length / count)];
      if (!candidate) break;
      const signature = candidate.map(({ id }) => id).join("|");
      if (used.has(signature)) continue;
      used.add(signature);
      selected.push(candidate);
    }
    for (const candidate of candidates) {
      if (selected.length >= count + (selected.length - Math.min(selected.length, count))) break;
      const signature = candidate.map(({ id }) => id).join("|");
      if (!used.has(signature)) {
        used.add(signature);
        selected.push(candidate);
      }
    }
  };

  const buckets = [
    valid.filter((traits) => traits.length === 2),
    valid.filter((traits) => traits.length <= 3),
    valid.filter((traits) => traits.length === 3),
    valid.filter((traits) => traits.length >= 3),
    valid.filter((traits) => traits.length === 4)
  ];
  const chosen = [];
  for (const bucket of buckets) {
    const available = bucket.filter((traits) => !used.has(traits.map(({ id }) => id).join("|")));
    const picks = [];
    for (let index = 0; index < 5 && available.length; index += 1) {
      const candidateIndex = Math.min(available.length - 1, Math.floor(index * available.length / 5));
      const [candidate] = available.splice(candidateIndex, 1);
      const signature = candidate.map(({ id }) => id).join("|");
      if (!used.has(signature)) {
        used.add(signature);
        picks.push(candidate);
      }
    }
    for (const candidate of valid) {
      if (picks.length >= 5) break;
      const signature = candidate.map(({ id }) => id).join("|");
      if (!used.has(signature)) {
        used.add(signature);
        picks.push(candidate);
      }
    }
    chosen.push(...picks);
  }
  if (chosen.length < 25) throw new Error(`Brakuje logicznych zestawów Who Is Who dla ${profile.name}.`);
  return chosen.slice(0, 25);
}

export const WHO_IS_WHO_QUESTIONS = Object.freeze(
  WHO_PROFILES.flatMap((profile, memberIndex) => createWhoLogicSets(profile).map((traits, clueIndex) => {
    const difficulty = Math.floor(clueIndex / 5) + 1;
    const candidates = WHO_NAMES.filter((name) => name !== profile.name);
    const shift = (memberIndex + clueIndex) % candidates.length;
    const alternatives = [...candidates.slice(shift), ...candidates.slice(0, shift)].slice(0, 3);
    return Object.freeze({
      id: `who-logic-${optionId(profile.name)}-${clueIndex + 1}`,
      topicId: `member-profile-${optionId(profile.name)}`,
      modeId: "who-is-who",
      type: QUESTION_TYPES.SINGLE_CHOICE,
      prompt: "Którego członka opisuje przecięcie wszystkich tropów?",
      category: "Who Is Who?",
      kind: "puzzle_interpretation",
      difficulty,
      basePoints: 95 + difficulty * 12,
      clues: traits.map(({ label }) => label),
      cluePolicy: { initialVisible: Math.min(2, traits.length), penaltyPerReveal: 6 },
      options: options(profile.name, alternatives),
      correctOptionId: optionId(profile.name),
      hints: [
        { text: "Nie wybieraj po jednym tropie — sprawdź wspólną część dwóch pierwszych.", penaltyRate: 0.12 },
        { text: "Porównaj przynależność do 3RACHA, chronologię wieku i cechy daty urodzin.", penaltyRate: 0.2 }
      ],
      explanation: `Każdy trop pasuje do kilku osób, lecz ich wspólna część prowadzi wyłącznie do: ${profile.name}.`,
      source: SOURCES.profile
    });
  }))
);

export const DISCOGRAPHY_RELEASES = Object.freeze([
  { album: "I am NOT", title: "District 9", date: "2018-03-26", source: SOURCES.early },
  { album: "I am WHO", title: "My Pace", date: "2018-08-06", source: SOURCES.early },
  { album: "I am YOU", title: "I am YOU", date: "2018-10-22", source: SOURCES.early },
  { album: "Clé 1 : MIROH", title: "MIROH", date: "2019-03-25", source: SOURCES.early },
  { album: "Clé 2 : Yellow Wood", title: "Side Effects", date: "2019-06-19", source: SOURCES.early },
  { album: "Clé : LEVANTER", title: "Levanter", date: "2019-12-09", source: SOURCES.early },
  { album: "GO生 (GO LIVE)", title: "God's Menu", date: "2020-06-17", source: SOURCES.middle },
  { album: "IN生 (IN LIFE)", title: "Back Door", date: "2020-09-14", source: SOURCES.middle },
  { album: "NOEASY", title: "Thunderous", date: "2021-08-23", source: SOURCES.recent },
  { album: "Christmas EveL", title: "Christmas EveL", date: "2021-11-29", source: SOURCES.recent },
  { album: "ODDINARY", title: "MANIAC", date: "2022-03-18", source: SOURCES.recent },
  { album: "MAXIDENT", title: "CASE 143", date: "2022-10-07", source: SOURCES.recent },
  { album: "★★★★★ (5-STAR)", title: "S-Class", date: "2023-06-02", source: SOURCES.recent },
  { album: "樂-STAR (ROCK-STAR)", title: "LALALALA", date: "2023-11-10", source: SOURCES.recent },
  { album: "ATE", title: "Chk Chk Boom", date: "2024-07-19", source: SOURCES.recent },
  { album: "合 (HOP)", title: "Walkin On Water", date: "2024-12-13", source: SOURCES.current },
  { album: "THIS & THAT", title: "This & That", date: "2026-08-07", source: SOURCES.thisAndThat }
]);

const RELEASES = DISCOGRAPHY_RELEASES;

function rotatingAlternatives(items, index, property) {
  return [1, 4, 7].map((offset) => items[(index + offset) % items.length][property]);
}

const TRACK_TO_ALBUM = RELEASES.map((release, index) => ({
  id: `disc-track-album-${optionId(release.title)}`,
  modeId: "discography-builder",
  type: QUESTION_TYPES.SINGLE_CHOICE,
  prompt: `Na którym albumie znajduje się title track „${release.title}”?`,
  category: "Utwór → album",
  kind: "official_fact",
  difficulty: Math.min(5, 1 + Math.floor(index / 4)),
  basePoints: 130,
  options: options(release.album, rotatingAlternatives(RELEASES, index, "album")),
  correctOptionId: optionId(release.album),
  explanation: `„${release.title}” jest title trackiem wydawnictwa ${release.album}.`,
  source: release.source
}));

const ALBUM_TO_TRACK = RELEASES.slice(0, 15).map((release, index) => ({
  id: `disc-album-track-${optionId(release.album)}`,
  modeId: "discography-builder",
  type: QUESTION_TYPES.SINGLE_CHOICE,
  prompt: `Który utwór jest title trackiem albumu ${release.album}?`,
  category: "Album → title track",
  kind: "official_fact",
  difficulty: Math.min(5, 1 + Math.floor(index / 4)),
  basePoints: 130,
  options: options(release.title, rotatingAlternatives(RELEASES, index, "title")),
  correctOptionId: optionId(release.title),
  explanation: `Title trackiem albumu ${release.album} jest „${release.title}”.`,
  source: release.source
}));

const CHRONOLOGY_GROUPS = [
  [0, 3, 6, 10],
  [1, 4, 7, 11],
  [2, 5, 8, 12],
  [6, 9, 13, 15],
  [8, 10, 12, 14],
  [11, 13, 14, 16]
];

const CHRONOLOGY_QUESTIONS = CHRONOLOGY_GROUPS.map((indexes, questionIndex) => {
  const releases = indexes.map((index) => RELEASES[index]).sort((a, b) => a.date.localeCompare(b.date));
  const answer = releases[0];
  return {
    id: `disc-chronology-${questionIndex + 1}`,
    modeId: "discography-builder",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Które z tych wydań ukazało się najwcześniej?",
    category: "Chronologia albumów",
    kind: "official_fact",
    difficulty: Math.min(5, questionIndex + 2),
    basePoints: 140,
    options: options(answer.album, releases.slice(1).map(({ album }) => album)),
    correctOptionId: optionId(answer.album),
    explanation: `${answer.album} ukazało się ${answer.date} i jest najwcześniejsze z podanej czwórki.`,
    source: answer.source
  };
});

const THIS_AND_THAT_TRACKS = ["RUN IT", "This & That", "After You", "FARMING", "I Do", "Way Out", "Back Than", "This & That (Festival Ver.)"];
const INTRUDERS = ["MANIAC", "S-Class", "Back Door", "Chk Chk Boom"];

const INTRUDER_QUESTIONS = INTRUDERS.map((intruder, index) => {
  const included = [
    THIS_AND_THAT_TRACKS[index],
    THIS_AND_THAT_TRACKS[index + 2],
    THIS_AND_THAT_TRACKS[index + 4]
  ];
  return {
    id: `disc-this-that-intruder-${index + 1}`,
    modeId: "discography-builder",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Który utwór nie należy do albumu THIS & THAT?",
    category: "Wybierz intruza",
    kind: "official_media_detail",
    difficulty: 2 + index,
    basePoints: 130,
    options: options(intruder, included),
    correctOptionId: optionId(intruder),
    explanation: `${included.join(", ")} znajdują się na THIS & THAT. „${intruder}” pochodzi z innego wydawnictwa.`,
    source: SOURCES.thisAndThat
  };
});

const NEXT_RELEASE_QUESTIONS = RELEASES.slice(0, -1).map((release, index) => {
  const answer = RELEASES[index + 1];
  return {
    id: `disc-next-${optionId(release.album)}`,
    topicId: `disc-sequence-after-${optionId(release.album)}`,
    modeId: "discography-builder",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: `Które wydawnictwo z tej osi ukazało się bezpośrednio po ${release.album}?`,
    category: "Następne wydanie",
    kind: "official_fact",
    difficulty: Math.min(5, 2 + Math.floor(index / 5)),
    basePoints: 120,
    options: options(answer.album, rotatingAlternatives(RELEASES, index + 1, "album")),
    correctOptionId: optionId(answer.album),
    explanation: `${release.album} ukazało się ${release.date}, a kolejnym wydawnictwem w tej osi jest ${answer.album} z ${answer.date}.`,
    source: answer.source
  };
});

const PREVIOUS_RELEASE_QUESTIONS = RELEASES.slice(1).map((release, index) => {
  const answer = RELEASES[index];
  return {
    id: `disc-previous-${optionId(release.album)}`,
    topicId: `disc-sequence-before-${optionId(release.album)}`,
    modeId: "discography-builder",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: `Które wydawnictwo z tej osi ukazało się bezpośrednio przed ${release.album}?`,
    category: "Poprzednie wydanie",
    kind: "official_fact",
    difficulty: Math.min(5, 2 + Math.floor(index / 5)),
    basePoints: 120,
    options: options(answer.album, rotatingAlternatives(RELEASES, index, "album")),
    correctOptionId: optionId(answer.album),
    explanation: `Bezpośrednio przed ${release.album} (${release.date}) na tej osi znajduje się ${answer.album} (${answer.date}).`,
    source: answer.source
  };
});

function rollingWindow(start, size = 4) {
  return Array.from({ length: size }, (_, offset) => RELEASES[(start + offset) % RELEASES.length])
    .sort((first, second) => first.date.localeCompare(second.date));
}

const POSITION_QUESTIONS = RELEASES.flatMap((_, start) => {
  const window = rollingWindow(start);
  return [1, 2].map((positionIndex) => {
    const answer = window[positionIndex];
    const label = positionIndex === 1 ? "drugie" : "trzecie";
    return {
      id: `disc-window-${start + 1}-position-${positionIndex + 1}`,
      topicId: `disc-window-${window.map(({ album }) => optionId(album)).join("-")}`,
      modeId: "discography-builder",
      type: QUESTION_TYPES.SINGLE_CHOICE,
      prompt: `Które wydawnictwo zajmuje ${label} miejsce po ułożeniu tej czwórki chronologicznie?`,
      category: "Pozycja w chronologii",
      kind: "official_fact",
      difficulty: positionIndex === 1 ? 4 : 5,
      basePoints: positionIndex === 1 ? 135 : 150,
      options: options(answer.album, window.filter(({ album }) => album !== answer.album).map(({ album }) => album)),
      correctOptionId: optionId(answer.album),
      explanation: `Kolejność tej czwórki to: ${window.map(({ album }) => album).join(" → ")}.`,
      source: answer.source
    };
  });
});

const CHAIN_QUESTIONS = RELEASES.slice(1, -1).map((release, index) => {
  const previous = RELEASES[index];
  const next = RELEASES[index + 2];
  const answer = `${previous.album} → ${release.album} → ${next.album}`;
  const alternatives = [
    `${release.album} → ${previous.album} → ${next.album}`,
    `${previous.album} → ${next.album} → ${release.album}`,
    `${next.album} → ${release.album} → ${previous.album}`
  ];
  return {
    id: `disc-chain-${index + 1}`,
    topicId: `disc-chain-around-${optionId(release.album)}`,
    modeId: "discography-builder",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Który łańcuch trzech kolejnych wydań ma poprawną kolejność?",
    category: "Zbuduj fragment dyskografii",
    kind: "official_fact",
    difficulty: 5,
    basePoints: 150,
    options: options(answer, alternatives),
    correctOptionId: optionId(answer),
    explanation: `Poprawny fragment osi to ${answer}.`,
    source: release.source
  };
});

export const DISCOGRAPHY_QUESTIONS = Object.freeze(
  [
    ...TRACK_TO_ALBUM,
    ...ALBUM_TO_TRACK,
    ...CHRONOLOGY_QUESTIONS,
    ...INTRUDER_QUESTIONS,
    ...NEXT_RELEASE_QUESTIONS,
    ...PREVIOUS_RELEASE_QUESTIONS,
    ...POSITION_QUESTIONS,
    ...CHAIN_QUESTIONS
  ].map((question) => Object.freeze({ ...question, topicId: question.topicId || question.id }))
);

export const EXTENDED_QUIZ_QUESTION_COUNT = WHO_IS_WHO_QUESTIONS.length + DISCOGRAPHY_QUESTIONS.length;
