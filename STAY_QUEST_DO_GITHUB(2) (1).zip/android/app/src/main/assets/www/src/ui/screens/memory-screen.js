import { createMemorySession } from "../../game/memory-session.js";
import { escapeHtml } from "../html.js";

const BOARD_OPTIONS = [
  { level: "mixed", difficulty: 3, size: 6, pairType: "skzoo-member", moveTarget: null, name: "Mieszana", detail: "6 par • SKZOO ↔ członek", icon: "AUTO" },
  { level: "1", difficulty: 1, size: 4, pairType: "symbol-skzoo", moveTarget: null, name: "Baby STAY", detail: "4 pary • symbol ↔ nazwa SKZOO", icon: "01" },
  { level: "2", difficulty: 2, size: 6, pairType: "symbol-skzoo", moveTarget: null, name: "STAY", detail: "6 par • większa plansza", icon: "02" },
  { level: "3", difficulty: 3, size: 6, pairType: "skzoo-member", moveTarget: null, name: "Veteran", detail: "6 par • SKZOO ↔ członek", icon: "03" },
  { level: "4", difficulty: 4, size: 8, pairType: "member-birth", moveTarget: 14, name: "Master", detail: "8 par • członek ↔ data urodzin", icon: "04" },
  { level: "5", difficulty: 5, size: 8, pairType: "skzoo-birth", moveTarget: 12, name: "Insane", detail: "8 par • SKZOO ↔ data urodzin", icon: "05" }
];

const PAIR_TYPE_COPY = Object.freeze({
  "symbol-skzoo": "Połącz symbol z nazwą właściwej postaci SKZOO.",
  "skzoo-member": "Połącz nazwę SKZOO z właściwym członkiem.",
  "member-birth": "Połącz członka z jego oficjalną datą urodzin.",
  "skzoo-birth": "Połącz SKZOO z datą urodzin przypisanego członka."
});

function getBoardOption(level) {
  return BOARD_OPTIONS.find((option) => option.level === String(level)) ?? BOARD_OPTIONS[0];
}

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

function renderSetup(mode, itemCount) {
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="special-setup special-setup--pink">
      <span class="special-setup__icon" aria-hidden="true">◆</span>
      <p class="eyebrow">SKZOO Memory Game</p>
      <h1 tabindex="-1">Wybierz wyzwanie pamięciowe</h1>
      <p>Poziom zmienia nie tylko liczbę kart, ale także rodzaj relacji między nimi.</p>
      <div class="round-picker">
        ${BOARD_OPTIONS.map(
          (option) => `
            <button type="button" data-action="memory-start" data-level="${option.level}">
              <span>${option.icon}</span>
              <strong>${option.name}</strong>
              <small>${option.detail}</small>
            </button>
          `
        ).join("")}
      </div>
      <p class="content-count">Dostępnych postaci: ${itemCount}. Bez limitu czasu i bez presji.</p>
    </section>
  `;
}

function cardLabel(card, index) {
  if (!card.faceUp && !card.matched) return `Zakryta karta ${index + 1}`;
  const type = { symbol: "symbol", skzoo: "nazwa SKZOO", member: "członek", detail: "szczegół profilu" }[card.faceType] ?? "treść";
  return `${card.matched ? "Dopasowana" : "Odkryta"} karta: ${type}, ${card.value}`;
}

function renderCard(card, index) {
  const visible = card.faceUp || card.matched;
  const stateClass = card.matched ? " is-matched" : visible ? " is-revealed" : "";
  const faceClass = visible ? ` memory-card--${card.faceType}` : "";

  return `
    <button
      class="memory-card${stateClass}${faceClass}"
      type="button"
      data-action="memory-flip"
      data-card-id="${escapeHtml(card.id)}"
      aria-label="${escapeHtml(cardLabel(card, index))}"
      ${card.matched ? "disabled" : ""}
    >
      <span class="memory-card__back" aria-hidden="true">SQ</span>
      <span class="memory-card__face" aria-hidden="true">${visible ? escapeHtml(card.value) : ""}</span>
    </button>
  `;
}

function renderGame(mode, snapshot, message = "Wybierz pierwszą kartę.") {
  const goal = snapshot.moveTarget ? `<span>Cel <strong>≤ ${snapshot.moveTarget}</strong></span>` : "";
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Zakończ rundę</a>
    <section class="memory-status" aria-label="Stan planszy">
      <div><p class="eyebrow">Plansza ${snapshot.pairCount}-parowa</p><h1 tabindex="-1">Znajdź pary SKZOO</h1></div>
      <div class="memory-status__stats">
        <span>Ruchy <strong>${snapshot.moves}</strong></span>
        <span>Pary <strong>${snapshot.pairsFound}/${snapshot.pairCount}</strong></span>
        <span>Czas aktywny <strong data-memory-time>${formatTime(snapshot.elapsedSeconds)}</strong></span>
        ${goal}
      </div>
    </section>
    <p class="memory-instruction">${escapeHtml(PAIR_TYPE_COPY[snapshot.pairType] ?? "Znajdź wszystkie pary.")}</p>
    <p class="sr-only" role="status" aria-live="polite">${escapeHtml(message)}</p>
    <section class="memory-grid memory-grid--${snapshot.pairCount}" aria-label="Plansza Memory">
      ${snapshot.cards.map(renderCard).join("")}
    </section>
  `;
}

function renderSummary(mode, summary) {
  const efficiency = summary.moves === summary.pairCount ? "Perfekcyjna pamięć!" : "Wszystkie pary odnalezione!";
  const challenge = summary.moveTarget
    ? `<p class="memory-challenge-result ${summary.moves <= summary.moveTarget ? "is-complete" : ""}">${summary.moves <= summary.moveTarget ? "Cel ruchów osiągnięty — premia +100 pkt!" : `Cel wynosił ${summary.moveTarget} ruchów. Następnym razem będzie rewanż.`}</p>`
    : "";
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="memory-summary">
      <span class="memory-summary__badge" aria-hidden="true">◆</span>
      <p class="eyebrow">Plansza ukończona</p>
      <h1 tabindex="-1">${efficiency}</h1>
      <p>${escapeHtml(PAIR_TYPE_COPY[summary.pairType] ?? "Wszystkie pary zostały odnalezione.")}</p>
      <div class="memory-summary__score"><span>Wynik</span><strong>${summary.score} pkt</strong></div>
      <div class="memory-summary__stats">
        <span>Ruchy <strong>${summary.moves}</strong></span>
        <span>Pary <strong>${summary.pairsFound}/${summary.pairCount}</strong></span>
        <span>Czas <strong>${formatTime(summary.elapsedSeconds)}</strong></span>
      </div>
      ${challenge}
      ${summary.repeatMultiplier < 1 ? `<p class="demo-notice">Ta sama konfiguracja wróciła szybko, więc zadziałał mnożnik anty-farming ×${summary.repeatMultiplier}.</p>` : ""}
    </section>
    <div class="summary-actions">
      <button class="button button--primary button--wide" type="button" data-action="memory-restart">Nowa plansza</button>
      <button class="button button--secondary button--wide" type="button" data-action="memory-change-size">Zmień rozmiar</button>
    </div>
  `;
}

export function createMemoryScreen({ mode, items, difficulty = "mixed", recentTaskHistory = [], onComplete = () => {}, onFeedback = () => {} }) {
  const screen = document.createElement("div");
  screen.className = "screen memory-screen";
  let session = null;
  let selectedDifficulty = String(difficulty);
  let mismatchTimer = null;
  let clockTimer = null;

  function stopClock() {
    if (clockTimer) window.clearInterval(clockTimer);
    clockTimer = null;
  }

  function startClock() {
    stopClock();
    clockTimer = window.setInterval(() => {
      const output = screen.querySelector("[data-memory-time]");
      if (output && session) output.textContent = formatTime(session.getSnapshot().elapsedSeconds);
    }, 1000);
  }

  function clearMismatchTimer() {
    if (mismatchTimer) window.clearTimeout(mismatchTimer);
    mismatchTimer = null;
  }

  function renderSetupScreen() {
    clearMismatchTimer();
    stopClock();
    session?.pause();
    session = null;
    screen.innerHTML = renderSetup(mode, items.length);
    requestAnimationFrame(() => screen.querySelector("h1")?.focus({ preventScroll: true }));
  }

  function renderActive(snapshot = session.getSnapshot(), message, focusId = null) {
    screen.innerHTML = renderGame(mode, snapshot, message);
    const requestedCard = focusId
      ? screen.querySelector(`[data-card-id="${focusId}"]:not([disabled])`)
      : null;
    const focusTarget = requestedCard ?? screen.querySelector(".memory-card:not([disabled])") ?? screen.querySelector(".memory-status h1");
    requestAnimationFrame(() => focusTarget?.focus({ preventScroll: true }));
  }

  function start(level) {
    clearMismatchTimer();
    const option = getBoardOption(level);
    selectedDifficulty = option.level;
    session?.pause();
    session = createMemorySession({
      items,
      pairCount: option.size,
      pairType: option.pairType,
      difficulty: option.difficulty,
      moveTarget: option.moveTarget,
      recentFingerprints: recentTaskHistory.map((entry) => typeof entry === "string" ? entry : entry.id)
    });
    renderActive();
    startClock();
  }

  screen.addEventListener("click", (event) => {
    const actionTarget = event.target.closest("[data-action]");
    const action = actionTarget?.dataset.action;
    if (!action) return;

    if (action === "memory-start") {
      onFeedback("tap");
      start(actionTarget.dataset.level);
    }
    if (action === "memory-flip" && session) {
      const cardId = actionTarget.dataset.cardId;
      const response = session.flip(cardId);
      const messages = {
        first: "Pierwsza karta odkryta. Wybierz drugą.",
        match: "Para znaleziona!",
        mismatch: "To nie jest para. Zapamiętaj obie karty."
      };

      if (response.snapshot.status === "complete") {
        const summary = session.getSummary();
        onComplete({
          modeId: mode.id,
          kind: "memory",
          score: summary.score,
          accuracy: Math.round((summary.pairCount / summary.moves) * 100),
          details: {
            pairCount: summary.pairCount,
            moves: summary.moves,
            elapsedSeconds: summary.elapsedSeconds,
            difficulty: selectedDifficulty,
            moveTarget: summary.moveTarget,
            pairType: summary.pairType,
            wrongAttempts: summary.wrongAttempts,
            fingerprint: summary.fingerprint,
            topicId: summary.pairType
          }
        });
        stopClock();
        screen.innerHTML = renderSummary(mode, summary);
        requestAnimationFrame(() => screen.querySelector(".memory-summary h1")?.focus({ preventScroll: true }));
        return;
      }

      onFeedback(response.type === "match" ? "match" : response.type === "mismatch" ? "wrong" : "tap");
      renderActive(response.snapshot, messages[response.type], cardId);
      if (response.type === "mismatch") {
        const activeSession = session;
        mismatchTimer = window.setTimeout(() => {
          mismatchTimer = null;
          if (!screen.isConnected || session !== activeSession) return;
          const snapshot = session.concealMismatch();
          renderActive(snapshot, "Karty ponownie zakryte.");
        }, 850);
      }
    }
    if (action === "memory-restart") {
      onFeedback("tap");
      start(selectedDifficulty);
    }
    if (action === "memory-change-size") {
      onFeedback("tap");
      renderSetupScreen();
    }
  });

  function handleVisibility() {
    if (!session || session.getSnapshot().status !== "active") return;
    if (document.hidden) session.pause();
    else session.resume();
  }

  document.addEventListener("visibilitychange", handleVisibility);

  start(selectedDifficulty);
  screen.destroy = () => {
    clearMismatchTimer();
    stopClock();
    session?.pause();
    document.removeEventListener("visibilitychange", handleVisibility);
  };
  return screen;
}
