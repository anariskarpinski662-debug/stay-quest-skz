import { STAY_LAB_MODES, getModesBySection } from "../../data/game-modes.js";
import { MEMBER_EMOJI_LINE } from "../../data/member-symbols.js";
import { getLocalDateKey } from "../../data/daily-challenge.js";
import { getLevelInfo } from "../../game/progress.js";
import { createModeCard } from "../components/mode-card.js";
import { escapeHtml } from "../html.js";

function createModeSection({ eyebrow, title, countLabel, modes, className = "" }) {
  const fragment = document.createDocumentFragment();
  const heading = document.createElement("div");
  heading.className = "section-heading";
  heading.innerHTML = `<div><p class="eyebrow">${eyebrow}</p><h2>${title}</h2></div><span>${countLabel}</span>`;
  const grid = document.createElement("section");
  grid.className = `mode-grid ${className}`.trim();
  grid.setAttribute("aria-label", title);
  modes.forEach((mode) => grid.append(createModeCard(mode)));
  fragment.append(heading, grid);
  return fragment;
}

export function createHomeScreen(state) {
  const screen = document.createElement("div");
  screen.className = "screen home-screen";
  const level = getLevelInfo(state.player.totalPoints);
  const knowledgeModes = getModesBySection("knowledge");
  const memoryModes = getModesBySection("memory");
  const today = getLocalDateKey();
  const dailyDone = state.daily.completedDates.includes(today);
  const installControl = document.documentElement.dataset.platform === "android"
    ? `<span class="native-install-status"><span aria-hidden="true">✓</span> Aplikacja Android</span>`
    : `
      <button class="button button--primary" type="button" data-action="install">
        <span aria-hidden="true">↓</span> Zainstaluj aplikację
      </button>
    `;

  const hero = document.createElement("section");
  hero.className = "hero-card";
  hero.innerHTML = `
    <div class="hero-card__glow" aria-hidden="true"></div>
    <p class="eyebrow">Twoja strefa gry</p>
    <h1>Gotowy, <span>${escapeHtml(state.player.displayName)}</span>?</h1>
    <p class="hero-card__copy">${escapeHtml(state.player.rank)} • osiem trybów, codzienna misja i osobny STAY Lab.</p>
    <p class="member-line" aria-label="Ośmiu członków">${MEMBER_EMOJI_LINE}</p>
    ${installControl}
  `;

  const daily = document.createElement("section");
  daily.className = `daily-card${dailyDone ? " is-complete" : ""}`;
  daily.innerHTML = `
    <div class="daily-card__icon" aria-hidden="true">🎯</div>
    <div class="daily-card__copy">
      <p class="eyebrow">Dzisiaj • Daily Challenge</p>
      <h2>${dailyDone ? "Dzisiejsza misja ukończona" : "Dzisiejsze wyzwanie czeka"}</h2>
      <p>10 zadań z kilku trybów • ${dailyDone ? "wynik zapisany, powtórka będzie treningowa" : "pierwszy wynik zapisuje się do profilu"}</p>
      <span>🔥 Seria dni: <strong>${state.daily.currentStreak}</strong></span>
    </div>
    <a class="button button--primary" href="#/mode/daily-challenge">${dailyDone ? "Trening" : "Zagraj"} <span aria-hidden="true">→</span></a>
  `;

  const stats = document.createElement("section");
  stats.className = "stat-grid";
  stats.setAttribute("aria-label", "Statystyki gracza");
  stats.innerHTML = `
    <article class="stat-card"><span>Poziom</span><strong>${state.player.level}</strong></article>
    <article class="stat-card"><span>Punkty</span><strong>${state.player.totalPoints}</strong></article>
    <article class="stat-card"><span>Najlepsza seria</span><strong>${state.player.bestStreak}</strong></article>
  `;

  const levelStrip = document.createElement("section");
  levelStrip.className = "home-level-strip";
  levelStrip.innerHTML = `
    <div><span>Poziom ${state.player.level}</span><strong>${level.pointsToNextLevel} pkt do kolejnego</strong></div>
    <div class="progress-track" role="progressbar" aria-label="Postęp poziomu" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${level.progress}"><span style="width: ${level.progress}%"></span></div>
  `;

  screen.append(hero, daily, stats, levelStrip);
  screen.append(createModeSection({
    eyebrow: "Piosenki • historia • członkowie",
    title: "Gry wiedzy",
    countLabel: `${knowledgeModes.length} trybów`,
    modes: knowledgeModes
  }));
  screen.append(createModeSection({
    eyebrow: "Spokojniejsza rozgrywka",
    title: "Gry pamięciowe",
    countLabel: "1 tryb",
    modes: memoryModes,
    className: "mode-grid--single"
  }));
  screen.append(createModeSection({
    eyebrow: "Bez dobrych i złych odpowiedzi",
    title: "STAY Lab",
    countLabel: "dla zabawy",
    modes: STAY_LAB_MODES,
    className: "mode-grid--single"
  }));

  return screen;
}
