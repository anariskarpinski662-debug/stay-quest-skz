import { QUESTION_TYPES } from "../game/question-schema.js";
import { DISCOGRAPHY_RELEASES } from "./extended-question-bank.js";

function optionId(label) {
  return String(label)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function options(answer, alternatives) {
  return [answer, ...alternatives].map((label) => ({ id: optionId(label), label }));
}

const ASSOCIATIONS = [
  ["gods-menu", "God's Menu", ["Super Bowl", "CHEESE", "TASTE"], 1, ["era wydawnictwa z czerwca 2020", "motyw przygotowywania czegoś po swojemu", "pięciogwiazdkowa pewność", "rytmiczne onomatopeje w refrenie"]],
  ["back-door", "Back Door", ["District 9", "Side Effects", "Levanter"], 1, ["repackage z 2020 roku", "gest pukania w choreografii", "zaproszenie do dalszej zabawy", "singiel po kulinarnej erze"]],
  ["miroh", "MIROH", ["District 9", "MOUNTAINS", "Social Path"], 2, ["pierwsza połowa 2019 roku", "miejska dżungla", "ważny krok w historii wygranych", "era z serii Clé"]],
  ["thunderous", "Thunderous", ["MEGAVERSE", "LALALALA", "Chk Chk Boom"], 2, ["NOEASY", "odpowiedź na hałas krytyków", "tradycyjne koreańskie motywy wizualne", "energia sorikkun"]],
  ["cheese", "CHEESE", ["TASTE", "JJAM", "Super Bowl"], 2, ["otwarcie albumu z 2021 roku", "prowokacyjny uśmiech", "gra z reakcją na krytykę", "wspólny kulinarny trop z kilkoma innymi tytułami"]],
  ["christmas-evel", "Christmas EveL", ["Winter Falls", "24 to 25", "FREEZE"], 2, ["wydanie pod koniec 2021 roku", "przewrotna świąteczna energia", "nietypowa dostawa w materiale wizualnym", "tytułowa gra jedną literą"]],
  ["venom", "VENOM", ["Red Lights", "Charmer", "MANIAC"], 3, ["ODDINARY", "motyw utknięcia w pułapce", "napięta, lepka choreografia", "wizualne skojarzenie z siecią"]],
  ["domino", "DOMINO", ["Collision", "Side Effects", "ITEM"], 2, ["NOEASY", "narastający efekt jednego ruchu", "precyzyjnie układana choreografia", "reakcja obejmująca kolejne elementy"]],
  ["charmer", "Charmer", ["VENOM", "Red Lights", "TASTE"], 3, ["ODDINARY", "kontrola uwagi odbiorcy", "hipnotyczny charakter", "motyw nieodpartego przyciągania"]],
  ["freeze", "FREEZE", ["Winter Falls", "Christmas EveL", "Levanter"], 2, ["ODDINARY", "odrzucenie narzuconych ograniczeń", "zimna metafora", "gwałtowna energia zamiast bezruchu"]],
  ["red-lights", "Red Lights", ["Collision", "VENOM", "Drive"], 3, ["utwór unitowy", "konflikt kontroli i przyciągania", "wyrazisty czerwony motyw wizualny", "duet z 2021 roku"]],
  ["case-143", "CASE 143", ["Collision", "I Do", "Secret Secret"], 2, ["MAXIDENT", "uczucie potraktowane jak zagadka", "liczbowy kod w tytule", "serca obecne w erze promocyjnej"]],
  ["s-class", "S-Class", ["Hall of Fame", "Super Bowl", "TOP"], 2, ["★★★★★ (5-STAR)", "podkreślanie własnej wyjątkowości", "gwiazdy jako część identyfikacji ery", "singiel z czerwca 2023 roku"]],
  ["chk-chk-boom", "Chk Chk Boom", ["Thunderous", "DOMINO", "LALALALA"], 2, ["ATE", "latynoski akcent brzmieniowy", "precyzyjne celowanie", "krótka rytmiczna sekwencja w tytule"]],
  ["lalalala", "LALALALA", ["Thunderous", "MEGAVERSE", "Hall of Fame"], 3, ["樂-STAR", "rockowa celebracja muzyki", "powtarzana wokalna sylaba", "title track z końca 2023 roku"]],
  ["mountains", "MOUNTAINS", ["TOP", "MIROH", "Levanter"], 2, ["ATE", "ambicja mierzona wysokością", "pokonywanie kolejnych przeszkód", "utwór otwierający wydawnictwo"]],
  ["megaverse", "MEGAVERSE", ["Hall of Fame", "TOP", "Social Path"], 3, ["樂-STAR", "filmowe otwarcie krótkiego wydawnictwa", "rozmach większy niż pojedyncza scena", "utwór poprzedzający title track na trackliście"]],
  ["social-path", "Social Path", ["Lonely St.", "THE SOUND", "TOP"], 3, ["współpraca z LiSA", "japoński singiel", "droga wybrana mimo samotności", "temat osobistego rozwoju"]],
  ["hall-of-fame", "Hall of Fame", ["S-Class", "TOP", "MEGAVERSE"], 3, ["★★★★★ (5-STAR)", "otwarcie albumu", "odwołania do zapisania się w historii", "ambitny ton przed title trackiem"]],
  ["super-bowl", "Super Bowl", ["God's Menu", "CHEESE", "TASTE"], 3, ["★★★★★ (5-STAR)", "kulinarny obraz wykorzystany do opisu muzyki", "angielskojęzyczny utwór na albumie", "motyw wielkiej porcji i widowiska"]],
  ["taste", "TASTE", ["CHEESE", "Red Lights", "Drive"], 4, ["utwór unitowy", "MAXIDENT", "zmysłowe napięcie", "wykonanie trzech członków poza 3RACHA"]],
  ["collision", "Collision", ["CASE 143", "I Do", "Sorry, I Love You"], 4, ["MAXIDENT", "relacja pokazana jako zderzenie", "b-side z uczuciowym napięciem", "tytuł nie jest liczbowym kodem"]],
  ["this-and-that", "This & That", ["I Do", "Any", "Another Day"], 2, ["wydanie z 2026 roku", "motyw przesyłki w promocji", "istnieje także wersja festiwalowa", "tytułowy utwór albumu"]],
  ["run-it", "RUN IT", ["MIROH", "TOP", "Boxer"], 3, ["THIS & THAT", "hymniczny rozmach", "mosiężne brzmienie", "otwarcie o energii ciągłego ruchu"]],
  ["farming", "FARMING", ["DOMINO", "ITEM", "Charmer"], 4, ["THIS & THAT", "hip-hopowy koncept zaczerpnięty z gier", "powtarzanie prowadzące do rozwoju", "żartobliwe wykorzystanie cyfrowej mechaniki"]],
  ["after-you", "After You", ["Cover Me", "Secret Secret", "Another Day"], 4, ["THIS & THAT", "progressive house", "nostalgiczny gitarowy riff", "historia rozpoczynająca się od jednego spojrzenia"]],
  ["maniac", "MANIAC", ["Side Effects", "VENOM", "Charmer"], 2, ["ODDINARY", "odrzucenie maski normalności", "poluzowana śruba jako motyw choreografii", "title track z marca 2022 roku"]],
  ["side-effects", "Side Effects", ["MANIAC", "Levanter", "Collision"], 3, ["Clé 2 : Yellow Wood", "niepokój po podjęciu decyzji", "ostrzeżenie przypominające ulotkę", "wydanie z połowy 2019 roku"]],
  ["district-9", "District 9", ["MIROH", "Back Door", "Social Path"], 2, ["I am NOT", "debiutancka era", "wyznaczona przestrzeń poza narzuconymi zasadami", "liczba obecna w tytule"]],
  ["levanter", "Levanter", ["Winter Falls", "Cover Me", "Secret Secret"], 4, ["ostatnia część serii Clé", "uwolnienie zamiast kurczowego trzymania", "wiatr jako metafora", "grudzień 2019 roku"]],
  ["lonely-st", "Lonely St.", ["Social Path", "Way Out", "Streetlight"], 3, ["ODDINARY", "samotna droga pośród trudności", "skrót w oficjalnym tytule", "emocjonalny b-side z ulicznym obrazem"]],
  ["cover-me", "Cover Me", ["Secret Secret", "After You", "Levanter"], 4, ["樂-STAR", "prośba o ochronę w trudnym momencie", "emocjonalne narastanie", "utwór z końcówki tracklisty"]],
  ["secret-secret", "Secret Secret", ["Cover Me", "Another Day", "Collision"], 5, ["NOEASY", "niewypowiedziane emocje", "deszczowy ciężar w odbiorze utworu", "jedno słowo powtórzone w tytule"]],
  ["jjam", "JJAM", ["CHEESE", "FARMING", "DOMINO"], 3, ["ATE", "lepka energia w materiale promocyjnym", "podwojona litera w oficjalnym zapisie", "b-side promowany po title tracku"]],
  ["walkin-on-water", "Walkin On Water", ["MOUNTAINS", "TOP", "Social Path"], 3, ["合 (HOP)", "niemożliwy ruch potraktowany jak pewność siebie", "title track z grudnia 2024 roku", "woda jako centralny obraz"]],
  ["ceremony", "CEREMONY", ["Hall of Fame", "S-Class", "LALALALA"], 4, ["uroczysty charakter", "celebracja osiągnięcia", "królewska oprawa", "tytuł zapisany wielkimi literami"]],
  ["i-do", "I Do", ["CASE 143", "Collision", "After You"], 4, ["THIS & THAT", "krótka deklaracja", "motyw obietnicy", "dwa słowa bez znaku zapytania"]],
  ["way-out", "Way Out", ["Levanter", "Lonely St.", "Social Path"], 5, ["THIS & THAT", "acoustic hip-hop", "powściągliwa emocja rozstania", "szukanie kierunku poza relacją"]],
  ["back-than", "Back Than", ["After You", "Another Day", "Secret Secret"], 5, ["THIS & THAT", "retrospekcja", "dawny moment zamiast obecnego miejsca", "tytuł celowo zapisany w oficjalnej formie"]],
  ["scars", "Scars", ["Levanter", "Cover Me", "Social Path"], 5, ["japońskie wydanie", "ślady pozostawione przez trudną drogę", "wytrwałość mimo bólu", "singiel z 2021 roku"]]
];

export const QUALITY_ASSOCIATION_QUESTIONS = Object.freeze(ASSOCIATIONS.map(([id, answer, alternatives, difficulty, clues]) => Object.freeze({
  id: `assoc-quality-${id}`,
  topicId: `song-${optionId(answer)}`,
  modeId: "assoc-master",
  type: QUESTION_TYPES.SINGLE_CHOICE,
  prompt: "Który utwór pasuje do całego zestawu tropów?",
  category: "Mistrz Skojarzeń",
  kind: "puzzle_interpretation",
  difficulty,
  basePoints: 105 + difficulty * 10,
  clues,
  cluePolicy: { initialVisible: 1, penaltyPerReveal: 6 },
  options: options(answer, alternatives),
  correctOptionId: optionId(answer),
  hints: [
    { text: `Połącz erę lub wydawnictwo z motywem drugiego odsłoniętego tropu.`, penaltyRate: 0.12 },
    { text: `Nie tłumacz tytułu dosłownie — sprawdź, który kandydat pasuje do wszystkich odsłoniętych informacji.`, penaltyRate: 0.2 }
  ],
  explanation: `Dopiero zestaw informacji o erze, charakterze i materiale promocyjnym prowadzi do „${answer}”; żaden pojedynczy trop nie jest tłumaczeniem tytułu.`
})));

function tripleLabel(release) {
  return `${release.album} • ${release.title} • ${release.date.slice(0, 4)}`;
}

function rotatingReleases(index, offsets = [1, 5, 9]) {
  return offsets.map((offset) => DISCOGRAPHY_RELEASES[(index + offset) % DISCOGRAPHY_RELEASES.length]);
}

const VETERAN_TRIPLES = DISCOGRAPHY_RELEASES.map((release, index) => ({
  id: `lore-quality-triple-${index + 1}`,
  topicId: `release-triple-${optionId(release.album)}`,
  prompt: "Który zestaw łączy właściwy album, jego title track i rok wydania?",
  answer: tripleLabel(release),
  alternatives: rotatingReleases(index).map((other, altIndex) => `${other.album} • ${DISCOGRAPHY_RELEASES[(index + altIndex + 2) % DISCOGRAPHY_RELEASES.length].title} • ${other.date.slice(0, 4)}`),
  difficulty: 3,
  explanation: `Poprawne połączenie to ${tripleLabel(release)}.`,
  source: release.source
}));

const VETERAN_NEXT = DISCOGRAPHY_RELEASES.slice(0, -1).map((release, index) => {
  const answer = DISCOGRAPHY_RELEASES[index + 1];
  return {
    id: `lore-quality-next-${index + 1}`,
    topicId: `release-neighbour-${optionId(release.album)}`,
    prompt: `Które wydawnictwo wraz z title trackiem bezpośrednio następuje po ${release.album} na tej osi?`,
    answer: `${answer.album} • ${answer.title}`,
    alternatives: rotatingReleases(index + 1).map((item) => `${item.album} • ${item.title}`),
    difficulty: 3,
    explanation: `${release.album} (${release.date}) poprzedza ${answer.album} (${answer.date}), którego title trackiem jest ${answer.title}.`,
    source: answer.source
  };
});

const VETERAN_PREVIOUS = DISCOGRAPHY_RELEASES.slice(1).map((release, index) => {
  const answer = DISCOGRAPHY_RELEASES[index];
  return {
    id: `lore-quality-previous-${index + 1}`,
    topicId: `release-neighbour-${optionId(release.album)}`,
    prompt: `Które wydawnictwo wraz z title trackiem bezpośrednio poprzedza ${release.album} na tej osi?`,
    answer: `${answer.album} • ${answer.title}`,
    alternatives: rotatingReleases(index).map((item) => `${item.album} • ${item.title}`),
    difficulty: 3,
    explanation: `Przed ${release.album} (${release.date}) znajduje się ${answer.album} (${answer.date}) z title trackiem ${answer.title}.`,
    source: answer.source
  };
});

const MASTER_BETWEEN = DISCOGRAPHY_RELEASES.slice(1, -1).map((release, index) => {
  const previous = DISCOGRAPHY_RELEASES[index];
  const next = DISCOGRAPHY_RELEASES[index + 2];
  return {
    id: `lore-quality-between-${index + 1}`,
    topicId: `release-between-${optionId(previous.album)}-${optionId(next.album)}`,
    prompt: `Który album i title track znajdują się chronologicznie między ${previous.album} a ${next.album}?`,
    answer: `${release.album} • ${release.title}`,
    alternatives: rotatingReleases(index + 1).map((item) => `${item.album} • ${item.title}`),
    difficulty: 4,
    explanation: `Fragment osi to ${previous.album} → ${release.album} → ${next.album}; title track środkowego wydania to ${release.title}.`,
    source: release.source
  };
});

function windowAt(start) {
  return Array.from({ length: 4 }, (_, offset) => DISCOGRAPHY_RELEASES[(start + offset) % DISCOGRAPHY_RELEASES.length])
    .sort((first, second) => first.date.localeCompare(second.date));
}

const MASTER_SECOND = DISCOGRAPHY_RELEASES.map((_, index) => {
  const window = windowAt(index);
  const answer = window[1];
  return {
    id: `lore-quality-second-${index + 1}`,
    topicId: `release-window-${window.map(({ album }) => optionId(album)).join("-")}`,
    prompt: "Który zestaw album • title track zajmuje drugie miejsce po chronologicznym ułożeniu podanej czwórki odpowiedzi?",
    answer: `${answer.album} • ${answer.title}`,
    alternatives: window.filter(({ album }) => album !== answer.album).map((item) => `${item.album} • ${item.title}`),
    difficulty: 4,
    explanation: `Kolejność albumów to ${window.map(({ album }) => album).join(" → ")}; drugie miejsce zajmuje ${answer.album} z utworem ${answer.title}.`,
    source: answer.source
  };
});

const MASTER_LATER_PAIR = DISCOGRAPHY_RELEASES.map((release, index) => {
  const other = DISCOGRAPHY_RELEASES[(index + 6) % DISCOGRAPHY_RELEASES.length];
  const [earlier, later] = [release, other].sort((first, second) => first.date.localeCompare(second.date));
  return {
    id: `lore-quality-later-${index + 1}`,
    topicId: `release-compare-${optionId(earlier.album)}-${optionId(later.album)}`,
    prompt: `Która odpowiedź poprawnie wskazuje późniejsze wydawnictwo z pary ${earlier.album} / ${later.album} oraz jego title track?`,
    answer: `${later.album} • ${later.title}`,
    alternatives: [
      `${earlier.album} • ${earlier.title}`,
      `${later.album} • ${earlier.title}`,
      `${earlier.album} • ${later.title}`
    ],
    difficulty: 4,
    explanation: `${later.album} (${later.date}) jest późniejsze niż ${earlier.album} (${earlier.date}), a jego title track to ${later.title}.`,
    source: later.source
  };
});

const INSANE_THIRD = DISCOGRAPHY_RELEASES.map((_, index) => {
  const window = windowAt(index);
  const answer = window[2];
  return {
    id: `lore-quality-third-${index + 1}`,
    topicId: `release-window-${window.map(({ album }) => optionId(album)).join("-")}`,
    prompt: "Który zestaw album • title track zajmuje trzecie miejsce po chronologicznym ułożeniu podanej czwórki odpowiedzi?",
    answer: `${answer.album} • ${answer.title}`,
    alternatives: window.filter(({ album }) => album !== answer.album).map((item) => `${item.album} • ${item.title}`),
    difficulty: 5,
    explanation: `Pełna kolejność to ${window.map(({ album }) => album).join(" → ")}; trzecie miejsce zajmuje ${answer.album} z utworem ${answer.title}.`,
    source: answer.source
  };
});

const INSANE_MISMATCH = DISCOGRAPHY_RELEASES.map((release, index) => {
  const wrongTitle = DISCOGRAPHY_RELEASES[(index + 1) % DISCOGRAPHY_RELEASES.length].title;
  const answer = `${release.album} • ${wrongTitle} • ${release.date.slice(0, 4)}`;
  return {
    id: `lore-quality-mismatch-${index + 1}`,
    topicId: `release-mismatch-${optionId(release.album)}`,
    prompt: "W którym zestawie dokładnie jeden element nie pasuje do pozostałych dwóch?",
    answer,
    alternatives: rotatingReleases(index).map(tripleLabel),
    difficulty: 5,
    explanation: `${release.album} i rok ${release.date.slice(0, 4)} pasują do siebie, ale jego title trackiem jest ${release.title}, nie ${wrongTitle}.`,
    source: release.source
  };
});

const INSANE_CHAINS = DISCOGRAPHY_RELEASES.slice(1, -1).map((release, index) => {
  const previous = DISCOGRAPHY_RELEASES[index];
  const next = DISCOGRAPHY_RELEASES[index + 2];
  const answer = `${previous.album} → ${release.album} → ${next.album}`;
  return {
    id: `lore-quality-chain-${index + 1}`,
    topicId: `release-chain-${optionId(release.album)}`,
    prompt: "Który łańcuch trzech sąsiednich wydań jest chronologicznie poprawny?",
    answer,
    alternatives: [
      `${release.album} → ${previous.album} → ${next.album}`,
      `${previous.album} → ${next.album} → ${release.album}`,
      `${next.album} → ${release.album} → ${previous.album}`
    ],
    difficulty: 5,
    explanation: `Daty układają ten fragment jako ${answer}.`,
    source: release.source
  };
});

const LORE_ROWS = [
  ...VETERAN_TRIPLES,
  ...VETERAN_NEXT,
  ...VETERAN_PREVIOUS,
  ...MASTER_BETWEEN,
  ...MASTER_SECOND,
  ...MASTER_LATER_PAIR,
  ...INSANE_THIRD,
  ...INSANE_MISMATCH,
  ...INSANE_CHAINS
];

export const QUALITY_LORE_QUESTIONS = Object.freeze(LORE_ROWS.map((row) => Object.freeze({
  id: row.id,
  topicId: row.topicId,
  modeId: "hardcore-lore",
  type: QUESTION_TYPES.SINGLE_CHOICE,
  prompt: row.prompt,
  category: "Hardcore Lore",
  kind: "official_fact",
  difficulty: row.difficulty,
  basePoints: row.difficulty === 3 ? 125 : row.difficulty === 4 ? 145 : 170,
  options: options(row.answer, row.alternatives),
  correctOptionId: optionId(row.answer),
  explanation: row.explanation,
  source: row.source
})));
