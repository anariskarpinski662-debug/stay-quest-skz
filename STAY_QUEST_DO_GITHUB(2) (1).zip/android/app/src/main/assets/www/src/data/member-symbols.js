export const MEMBER_SYMBOLS = Object.freeze([
  { id: "bang-chan", name: "Bang Chan", skzoo: "Wolf Chan", emoji: "🐺", birthDate: "3 października 1997", birthOrder: "1. najstarszy" },
  { id: "lee-know", name: "Lee Know", skzoo: "Leebit", emoji: "🐰", birthDate: "25 października 1998", birthOrder: "2. najstarszy" },
  { id: "changbin", name: "Changbin", skzoo: "Dwaekki", emoji: "🐷🐰", birthDate: "11 sierpnia 1999", birthOrder: "3. najstarszy" },
  { id: "hyunjin", name: "Hyunjin", skzoo: "Jiniret", emoji: "🦙", birthDate: "20 marca 2000", birthOrder: "4. najstarszy" },
  { id: "han", name: "Han", skzoo: "HAN QUOKKA", emoji: "🐿️", birthDate: "14 września 2000", birthOrder: "5. najstarszy" },
  { id: "felix", name: "Felix", skzoo: "BbokAri", emoji: "🐥", birthDate: "15 września 2000", birthOrder: "6. najstarszy" },
  { id: "seungmin", name: "Seungmin", skzoo: "PuppyM", emoji: "🐶", birthDate: "22 września 2000", birthOrder: "7. najstarszy" },
  { id: "i-n", name: "I.N", skzoo: "FoxI.Ny", emoji: "🦊", birthDate: "8 lutego 2001", birthOrder: "8. najstarszy" }
]);

export const MEMBER_EMOJI_LINE = MEMBER_SYMBOLS.map(({ emoji }) => emoji).join(" ");
