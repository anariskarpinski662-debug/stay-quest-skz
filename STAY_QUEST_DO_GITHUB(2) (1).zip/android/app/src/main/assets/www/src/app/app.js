import { createRouter } from "./router.js";
import { createStore } from "./store.js";
import { createFeedbackController } from "./feedback.js";
import { renderAppShell } from "../ui/app-shell.js";
import { createHomeScreen } from "../ui/screens/home-screen.js";
import { createModeScreen } from "../ui/screens/mode-screen.js";
import { createStaticScreen } from "../ui/screens/static-screen.js";
import { createAchievementsScreen } from "../ui/screens/achievements-screen.js";
import { createSettingsScreen } from "../ui/screens/settings-screen.js";
import { createQuizScreen } from "../ui/screens/quiz-screen.js";
import { createTimelineScreen } from "../ui/screens/timeline-screen.js";
import { createMemoryScreen } from "../ui/screens/memory-screen.js";
import { createSoulmateScreen } from "../ui/screens/soulmate-screen.js";
import { getQuizQuestions } from "../data/question-bank.js";
import { TIMELINE_EVENTS, TIMELINE_SET_TEMPLATES } from "../data/timeline-events.js";
import { MEMBER_SYMBOLS } from "../data/member-symbols.js";
import { createDailyQuestions, createDailyRandom, getLocalDateKey } from "../data/daily-challenge.js";
import { SOULMATE_MEMBERS, SOULMATE_QUESTIONS } from "../data/soulmate-questions.js";
import { findGameMode } from "../data/game-modes.js";
import { findAchievement } from "../data/achievements.js";

export function createApp(target) {
  const store = createStore();
  const feedback = createFeedbackController({ getSettings: () => store.getState().settings });
  const shell = renderAppShell(target);
  let deferredInstallPrompt = null;
  let toastTimer = null;
  let router = null;
  let modalReturnFocus = null;
  let activeView = null;

  function updateConnectionStatus() {
    const online = navigator.onLine;
    shell.connectionStatus.textContent = online ? "online" : "offline";
    shell.connectionStatus.dataset.online = String(online);
  }

  function showToast(message) {
    window.clearTimeout(toastTimer);
    shell.toast.textContent = message;
    shell.toast.hidden = false;
    toastTimer = window.setTimeout(() => {
      shell.toast.hidden = true;
    }, 3200);
  }

  function applySettings(settings) {
    document.documentElement.dataset.textScale = settings.textScale;
    document.documentElement.dataset.highContrast = String(settings.highContrast);
    document.documentElement.dataset.reducedMotion = String(settings.reducedMotion);
  }

  function closeModal() {
    const returnFocus = modalReturnFocus;
    modalReturnFocus = null;
    shell.modalLayer.hidden = true;
    shell.modalLayer.replaceChildren();
    shell.appShell.inert = false;
    shell.appShell.removeAttribute("aria-hidden");
    document.body.classList.remove("has-modal");
    if (returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
  }

  function activateModal() {
    modalReturnFocus = document.activeElement;
    shell.appShell.inert = true;
    shell.appShell.setAttribute("aria-hidden", "true");
    document.body.classList.add("has-modal");
    shell.modalLayer.hidden = false;
    requestAnimationFrame(() => shell.modalLayer.querySelector(".modal__close")?.focus({ preventScroll: true }));
  }

  function showInstallHelp() {
    shell.modalLayer.innerHTML = `
      <section class="modal" role="dialog" aria-modal="true" aria-labelledby="install-title">
        <button class="modal__close" type="button" data-action="close-modal" aria-label="Zamknij">×</button>
        <span class="modal__icon" aria-hidden="true">↓</span>
        <p class="eyebrow">Instalacja na Androidzie</p>
        <h2 id="install-title">Dodaj STAY QUEST do telefonu</h2>
        <p>Otwórz menu przeglądarki i wybierz opcję instalacji aplikacji albo dodania jej do ekranu głównego.</p>
        <button class="button button--secondary" type="button" data-action="close-modal">Rozumiem</button>
      </section>
    `;
    activateModal();
  }

  function showResetConfirmation() {
    shell.modalLayer.innerHTML = `
      <section class="modal modal--danger" role="dialog" aria-modal="true" aria-labelledby="reset-title">
        <button class="modal__close" type="button" data-action="close-modal" aria-label="Zamknij">×</button>
        <span class="modal__icon" aria-hidden="true">!</span>
        <p class="eyebrow">Nieodwracalna zmiana</p>
        <h2 id="reset-title">Wyzerować cały postęp?</h2>
        <p>Punkty, poziom, rekordy, historia i odznaki znikną z tego urządzenia. Ustawienia również wrócą do domyślnych.</p>
        <div class="modal__actions">
          <button class="button button--danger button--wide" type="button" data-action="confirm-reset">Tak, wyzeruj wszystko</button>
          <button class="button button--secondary button--wide" type="button" data-action="close-modal">Anuluj</button>
        </div>
      </section>
    `;
    activateModal();
  }

  async function installApp() {
    if (!deferredInstallPrompt) {
      showInstallHelp();
      return;
    }

    deferredInstallPrompt.prompt();
    const choice = await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    if (choice.outcome === "accepted") {
      feedback.trigger("complete");
      showToast("STAY QUEST dodano do telefonu.");
    }
  }

  function downloadBackup() {
    const content = store.exportBackup();
    const filename = `stay-quest-backup-${new Date().toISOString().slice(0, 10)}.json`;

    if (globalThis.StayQuestAndroid && typeof globalThis.StayQuestAndroid.saveBackup === "function") {
      globalThis.StayQuestAndroid.saveBackup(content, filename);
      return;
    }

    const blob = new Blob([content], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  function refreshCurrentRoute() {
    if (router) renderRoute(router.current());
  }

  function recordCompletedRound(result) {
    const previousLevel = store.getState().player.level;
    const recorded = store.recordResult(result);
    const nextLevel = recorded.state.player.level;
    const achievement = findAchievement(recorded.newlyUnlocked[0]);

    if (achievement) {
      feedback.trigger("achievement");
      const extra = recorded.newlyUnlocked.length > 1 ? ` (+${recorded.newlyUnlocked.length - 1} kolejne)` : "";
      showToast(`Nowa odznaka: ${achievement.title}${extra}! +${result.score} pkt`);
    } else if (nextLevel > previousLevel) {
      feedback.trigger("achievement");
      showToast(`Poziom ${nextLevel} odblokowany! +${result.score} pkt`);
    } else {
      feedback.trigger("complete");
      showToast(`Wynik zapisany: +${result.score} pkt`);
    }
    return recorded;
  }

  function recordDailyRound(result, dateKey) {
    const recorded = store.recordDailyResult(result, dateKey);
    if (recorded.alreadyRecorded) {
      feedback.trigger("complete");
      showToast("Dzisiejszy wynik był już zapisany — ta runda była treningowa.");
      return recorded;
    }

    const achievement = findAchievement(recorded.newlyUnlocked[0]);
    if (achievement) {
      feedback.trigger("achievement");
      showToast(`Nowa odznaka: ${achievement.title}! +${result.score} pkt`);
    } else {
      feedback.trigger("complete");
      showToast(`Daily ukończone: +${result.score} pkt`);
    }
    return recorded;
  }

  function recordSoulmate(result) {
    const recorded = store.recordSoulmateResult(result);
    const achievement = findAchievement(recorded.newlyUnlocked[0]);
    if (achievement) {
      feedback.trigger("achievement");
      showToast(`Nowa odznaka: ${achievement.title}!`);
    } else {
      feedback.trigger("complete");
      showToast("Nowe dopasowanie zapisane w STAY Lab.");
    }
    return recorded;
  }

  function routeTitle(route) {
    if (route.name === "home") return "STAY QUEST — gra";
    if (route.name === "achievements") return "Osiągnięcia — STAY QUEST";
    if (route.name === "settings") return "Ustawienia — STAY QUEST";
    if (["mode", "play"].includes(route.name)) return `${findGameMode(route.params.modeId)?.name ?? "Tryb"} — STAY QUEST`;
    return "Nie znaleziono — STAY QUEST";
  }

  function updateNavigation(route) {
    const activeName = ["mode", "play"].includes(route.name) ? "home" : route.name;
    target.classList.toggle("is-playing", route.name === "play");
    target.querySelectorAll("[data-nav]").forEach((link) => {
      const active = link.dataset.nav === activeName;
      link.classList.toggle("is-active", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });
  }

  function renderRoute(route) {
    const state = store.getState();
    let view;

    if (route.name === "home") view = createHomeScreen(state);
    else if (route.name === "achievements") view = createAchievementsScreen(state);
    else if (route.name === "settings") {
      view = createSettingsScreen({
        state,
        onProfileSave: (displayName) => {
          store.updateProfile(displayName);
          feedback.trigger("tap");
          showToast("Profil gracza zapisany.");
        },
        onSettingsChange: (changes) => {
          store.updateSettings(changes);
          if (changes.soundEnabled === true || changes.hapticsEnabled === true) feedback.trigger("preview");
        },
        onPreview: () => feedback.trigger("preview"),
        onExport: downloadBackup,
        onImport: async (text) => {
          store.importBackup(text);
          feedback.trigger("complete");
          refreshCurrentRoute();
          showToast("Kopia postępu została przywrócona.");
        },
        onReset: showResetConfirmation
      });
    }
    else if (route.name === "mode") view = createModeScreen(route.params.modeId, state);
    else if (route.name === "play") {
      const mode = findGameMode(route.params.modeId);
      const questions = getQuizQuestions(route.params.modeId);
      const difficulty = route.params.difficulty ?? "mixed";

      if (!mode) view = createStaticScreen("not-found");
      else if (mode.id === "soulmate-lab") view = createSoulmateScreen({
        mode,
        questions: SOULMATE_QUESTIONS,
        members: SOULMATE_MEMBERS,
        previousResult: state.soulmate.lastResult,
        onComplete: recordSoulmate,
        onFeedback: (name) => feedback.trigger(name)
      });
      else if (mode.id === "daily-challenge") {
        const dateKey = getLocalDateKey();
        const dailyQuestions = createDailyQuestions(dateKey);
        view = createQuizScreen({
          mode,
          questions: dailyQuestions,
          difficulty: "mixed",
          recentQuestionIds: [],
          randomFactory: () => createDailyRandom(dateKey),
          onComplete: (result) => recordDailyRound(result, dateKey),
          onFeedback: (name) => feedback.trigger(name)
        });
      }
      else if (questions.length) view = createQuizScreen({
        mode,
        questions,
        difficulty,
        recentQuestionIds: store.getRecentQuestionIds(mode.id),
        recentQuestionHistory: store.getRecentQuestionHistory(mode.id),
        onComplete: recordCompletedRound,
        onFeedback: (name) => feedback.trigger(name)
      });
      else if (mode.id === "timeline") view = createTimelineScreen({
        mode,
        events: TIMELINE_EVENTS,
        setTemplates: TIMELINE_SET_TEMPLATES,
        difficulty,
        recentTaskHistory: store.getRecentQuestionHistory(mode.id),
        onComplete: recordCompletedRound,
        onFeedback: (name) => feedback.trigger(name)
      });
      else if (mode.id === "skzoo-memory") view = createMemoryScreen({
        mode,
        items: MEMBER_SYMBOLS,
        difficulty,
        recentTaskHistory: store.getRecentQuestionHistory(mode.id),
        onComplete: recordCompletedRound,
        onFeedback: (name) => feedback.trigger(name)
      });
      else view = createStaticScreen("not-found");
    }
    else view = createStaticScreen(route.name);

    activeView?.destroy?.();
    activeView = view;
    shell.screen.replaceChildren(view);
    document.title = routeTitle(route);
    updateNavigation(route);
    shell.screen.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: state.settings.reducedMotion ? "auto" : "smooth" });
  }

  target.addEventListener("click", (event) => {
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (action === "install") installApp();
    if (action === "close-modal") closeModal();
    if (action === "confirm-reset") {
      store.reset();
      feedback.trigger("wrong");
      closeModal();
      refreshCurrentRoute();
      showToast("Postęp został wyzerowany.");
    }
  });

  shell.modalLayer.addEventListener("click", (event) => {
    if (event.target === shell.modalLayer) closeModal();
  });

  window.addEventListener("keydown", (event) => {
    if (shell.modalLayer.hidden) return;
    if (event.key === "Escape") {
      closeModal();
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = [...shell.modalLayer.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), [tabindex]:not([tabindex="-1"])')];
    if (!focusable.length) {
      event.preventDefault();
      return;
    }
    const first = focusable[0];
    const last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstallPrompt = event;
  });
  window.addEventListener("appinstalled", () => showToast("Aplikacja jest gotowa do gry offline."));
  window.addEventListener("online", updateConnectionStatus);
  window.addEventListener("offline", updateConnectionStatus);
  window.addEventListener("pagehide", () => void feedback.destroy(), { once: true });

  store.subscribe((state) => applySettings(state.settings));
  applySettings(store.getState().settings);
  updateConnectionStatus();
  router = createRouter(renderRoute);

  return { router, store, notify: showToast };
}
