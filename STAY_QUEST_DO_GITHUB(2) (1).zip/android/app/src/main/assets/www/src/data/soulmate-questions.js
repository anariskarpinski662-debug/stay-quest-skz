const SCALE = [0, 0.33, 0.67, 1];

function question(id, dimension, prompt, labels, values = SCALE) {
  return Object.freeze({
    id: `soul-${id}`,
    dimension,
    prompt,
    options: Object.freeze(labels.map((label, index) => Object.freeze({
      id: `${id}-${index + 1}`,
      label,
      value: values[index]
    })))
  });
}

export const SOULMATE_DIMENSIONS = Object.freeze({
  planning: { label: "planowanie i spontaniczność" },
  social: { label: "sposób bycia wśród ludzi" },
  energy: { label: "tempo działania" },
  expression: { label: "okazywanie emocji" },
  humor: { label: "rodzaj humoru" },
  competition: { label: "podejście do rywalizacji" },
  creativity: { label: "kreatywne myślenie" },
  care: { label: "okazywanie troski" },
  risk: { label: "podejście do nowych sytuacji" },
  recharge: { label: "sposób odpoczywania" }
});

export const SOULMATE_QUESTIONS = Object.freeze([
  question("free-evening", "planning", "Masz kompletnie wolny wieczór. Co robisz?", ["Decyduję dopiero w ostatniej chwili", "Mam luźny pomysł", "Układam sobie kilka punktów", "Wiem wcześniej dokładnie, co i kiedy"]),
  question("trip-change", "planning", "Plan wyjazdu nagle się zmienia. Jaka jest Twoja pierwsza reakcja?", ["Super, zobaczymy, dokąd nas poniesie", "Chwilę się dziwię i dostosowuję", "Szybko tworzę plan zastępczy", "Muszę spokojnie poukładać wszystko od nowa"]),
  question("group-task", "planning", "Dostajecie wspólne zadanie. Jak zaczynasz?", ["Od razu coś robimy i poprawiamy po drodze", "Najpierw krótka burza mózgów", "Dzielę zadania i ustalam kolejność", "Tworzę dokładny plan oraz terminy"]),
  question("weekend", "planning", "Idealny weekend najbardziej przypomina…", ["pełną improwizację", "jeden plan i dużo luzu", "kilka wybranych punktów", "dobrze ułożony harmonogram"]),

  question("new-room", "social", "Wchodzisz do miejsca, gdzie prawie nikogo nie znasz.", ["Najpierw obserwuję z boku", "Rozmawiam z jedną spokojną osobą", "Dołączam do małej grupy", "Sam zaczynam rozmowy z wieloma osobami"]),
  question("good-news", "social", "Dostajesz świetną wiadomość. Komu mówisz najpierw?", ["Zachowuję ją chwilę dla siebie", "Jednej najbliższej osobie", "Małej grupie bliskich", "Od razu dzielę się z większą ekipą"]),
  question("party", "social", "Na większym spotkaniu najlepiej czujesz się…", ["w spokojnym kącie", "w rozmowie jeden na jeden", "w małej grupie", "w centrum wspólnej zabawy"]),
  question("team-role", "social", "W grupie najczęściej jesteś osobą, która…", ["działa po cichu na zapleczu", "wspiera wybraną osobę", "spaja kilka osób", "uruchamia energię całej grupy"]),

  question("busy-day", "energy", "Po intensywnym dniu nadal pojawia się ciekawa okazja.", ["Zostaję w domu bez wyrzutów", "Rozważam ją, ale wybieram spokój", "Idę, jeśli naprawdę mnie ciekawi", "Idę — szkoda tracić energię chwili"]),
  question("morning", "energy", "Jak wchodzisz w nowy dzień?", ["Bardzo powoli i cicho", "Potrzebuję spokojnego początku", "Rozkręcam się dość szybko", "Od razu działam na pełnych obrotach"]),
  question("deadline", "energy", "Termin jest blisko. Jak pracujesz?", ["Równo i spokojnie", "Przyspieszam dopiero pod koniec", "Wchodzę na wysokie tempo", "Odpalam pełny tryb turbo"]),
  question("surprise-plan", "energy", "Znajomi proponują spontaniczną aktywność.", ["Wolę spokojną alternatywę", "Dołączę na krótko", "Chętnie sprawdzę", "Jestem pierwszy gotowy"]),

  question("missing-someone", "expression", "Tęsknisz za kimś. Jak to pokazujesz?", ["Raczej zachowuję to dla siebie", "Wysyłam drobny znak", "Mówię wprost, ale spokojnie", "Bardzo otwarcie okazuję emocje"]),
  question("compliment", "expression", "Ktoś szczerze Cię chwali.", ["Trochę się chowam i zmieniam temat", "Dziękuję krótko", "Przyjmuję to z uśmiechem", "Od razu odpowiadam równie ciepło"]),
  question("conflict-feelings", "expression", "Ważna osoba Cię uraziła.", ["Najpierw długo układam emocje sam", "Daję delikatny sygnał", "Rozmawiam wprost, gdy ochłonę", "Od razu jasno mówię, co czuję"]),
  question("celebration", "expression", "Bliska osoba osiąga sukces.", ["Cieszę się po cichu i pamiętam o geście", "Wysyłam krótką wiadomość", "Mówię, jak bardzo jestem dumny", "Robię z tego wielkie, ciepłe święto"]),

  question("awkward-silence", "humor", "W rozmowie zapada niezręczna cisza.", ["Pozwalam jej spokojnie minąć", "Rzucam suchy komentarz", "Opowiadam zabawną historię", "Robię coś kompletnie absurdalnego"]),
  question("inside-joke", "humor", "Najlepszy żart to dla Ciebie…", ["subtelna ironia", "celny suchar", "dobra anegdota", "czysty, niekontrolowany chaos"]),
  question("friend-slip", "humor", "Przyjaciel myli słowa w zabawny sposób.", ["Tylko się uśmiecham", "Zapamiętuję i wracam do tego później", "Od razu tworzę z tego żart", "Rozwijam to w pełną legendę grupy"]),
  question("bad-mood", "humor", "Chcesz poprawić komuś humor.", ["Daję spokojne wsparcie", "Wysyłam jeden trafiony mem", "Rozkręcam lekkie wygłupy", "Urządzam totalny festiwal absurdu"]),

  question("board-game", "competition", "Gracie w grę planszową.", ["Najważniejsza jest wspólna zabawa", "Lubię wygrać, ale bez spiny", "Naprawdę próbuję zwyciężyć", "Włącza mi się pełny tryb turniejowy"]),
  question("challenge", "competition", "Ktoś mówi: „Nie dasz rady”.", ["Nie muszę niczego udowadniać", "Spróbuję dla siebie", "To mocno mnie motywuje", "Od tej chwili MUSZĘ to zrobić"]),
  question("team-loss", "competition", "Wasza drużyna przegrywa.", ["Doceniam wspólny czas", "Sprawdzam, czego się nauczyliśmy", "Od razu chcę rewanżu", "Analizuję wszystko, żeby następnym razem wygrać"]),
  question("personal-best", "competition", "Pobijasz własny rekord.", ["Miło, ale wynik nie jest najważniejszy", "Cieszę się postępem", "Od razu wyznaczam wyższy cel", "Próbuję poprawić go jeszcze tego samego dnia"]),

  question("empty-box", "creativity", "Dostajesz puste pudełko i dowolne materiały.", ["Robię coś użytecznego", "Ulepszam znany pomysł", "Tworzę coś własnego", "Buduję rzecz, której nikt się nie spodziewa"]),
  question("problem", "creativity", "Standardowy sposób rozwiązania problemu nie działa.", ["Szukam sprawdzonej instrukcji", "Łączę kilka znanych metod", "Testuję własny pomysł", "Całkowicie zmieniam punkt widzenia"]),
  question("story", "creativity", "Ktoś zaczyna historię i prosi Cię o zakończenie.", ["Wybieram logiczne rozwiązanie", "Dodaję jeden zwrot", "Tworzę nieoczywisty finał", "Wywracam cały świat historii do góry nogami"]),
  question("room", "creativity", "Masz urządzić pusty pokój.", ["Stawiam na funkcjonalność", "Dodaję kilka osobistych akcentów", "Buduję wyraźny klimat", "Tworzę kompletnie własny mały świat"]),

  question("friend-tired", "care", "Bliska osoba wraca kompletnie wykończona.", ["Po cichu ułatwiam jej obowiązki", "Przynoszę coś potrzebnego", "Pytam, czego teraz potrzebuje", "Długo rozmawiam i bardzo wyraźnie wspieram"]),
  question("birthday", "care", "Jak najchętniej pokazujesz komuś, że o nim pamiętasz?", ["Praktycznym gestem", "Dobrze dobranym drobiazgiem", "Osobistą wiadomością", "Dużym, emocjonalnym świętowaniem"]),
  question("rough-week", "care", "Przyjaciel ma trudny tydzień.", ["Zdejmuję mu coś z głowy", "Jestem obok bez nacisku", "Regularnie pytam, jak się czuje", "Otwarcie przypominam mu, ile dla mnie znaczy"]),
  question("thank-you", "care", "Chcesz komuś naprawdę podziękować.", ["Odwdzięczam się działaniem", "Daję mały, przemyślany prezent", "Piszę osobistą wiadomość", "Mówię wszystko wprost i bardzo emocjonalnie"]),

  question("new-food", "risk", "W menu widzisz rzecz, której nigdy nie próbowałeś.", ["Wybieram to, co znam", "Próbuję kawałek od kogoś", "Zamawiam, jeśli brzmi ciekawie", "Biorę najbardziej nieznaną opcję"]),
  question("unexpected-route", "risk", "Możesz wybrać znaną drogę albo nowy skrót.", ["Wybieram pewną trasę", "Sprawdzam mapę i dopiero decyduję", "Idę nową drogą", "Wybieram najbardziej nieoczywistą trasę"]),
  question("opportunity", "risk", "Pojawia się ciekawa szansa, ale nie masz pełnych informacji.", ["Czekam na pewność", "Zbieram jak najwięcej danych", "Podejmuję rozsądne ryzyko", "Wchodzę i uczę się w trakcie"]),
  question("stage", "risk", "Nagle proponują Ci wystąpienie przed ludźmi.", ["Grzecznie odmawiam", "Zgodzę się po przygotowaniu", "Podejmuję wyzwanie", "Wychodzę od razu, zanim zdążę się zestresować"]),

  question("day-off", "recharge", "Masz cały dzień tylko dla siebie.", ["Cisza, koc i brak planów", "Spokojne zajęcie w domu", "Krótki wypad lub spotkanie", "Aktywny dzień pełen wrażeń"]),
  question("stress", "recharge", "Po stresującym tygodniu najlepiej regeneruje Cię…", ["sen i pełne odcięcie", "samotny spokojny rytuał", "czas z jedną bliską osobą", "wspólna aktywność i zmiana otoczenia"]),
  question("holiday", "recharge", "Pierwszy dzień urlopu wygląda u Ciebie tak:", ["niczego ode mnie nie wymagajcie", "powolne wejście w odpoczynek", "jedna przyjemna aktywność", "od razu ruszam odkrywać nowe miejsca"]),
  question("evening-reset", "recharge", "Który wieczorny reset brzmi najlepiej?", ["zupełna cisza", "coś spokojnego tylko dla mnie", "rozmowa i lekka aktywność", "głośna zabawa albo intensywne wyjście"])
]);

export const SOULMATE_MEMBERS = Object.freeze([
  { id: "bang-chan", name: "Bang Chan", emoji: "🐺", profile: { planning: 0.78, social: 0.72, energy: 0.76, expression: 0.72, humor: 0.64, competition: 0.72, creativity: 0.82, care: 0.9, risk: 0.58, recharge: 0.36 } },
  { id: "lee-know", name: "Lee Know", emoji: "🐰", profile: { planning: 0.68, social: 0.38, energy: 0.56, expression: 0.34, humor: 0.74, competition: 0.62, creativity: 0.62, care: 0.28, risk: 0.5, recharge: 0.25 } },
  { id: "changbin", name: "Changbin", emoji: "🐷🐰", profile: { planning: 0.62, social: 0.82, energy: 0.92, expression: 0.86, humor: 0.82, competition: 0.86, creativity: 0.76, care: 0.76, risk: 0.68, recharge: 0.64 } },
  { id: "hyunjin", name: "Hyunjin", emoji: "🦙", profile: { planning: 0.46, social: 0.58, energy: 0.58, expression: 0.86, humor: 0.68, competition: 0.66, creativity: 0.96, care: 0.8, risk: 0.54, recharge: 0.3 } },
  { id: "han", name: "Han", emoji: "🐿️", profile: { planning: 0.34, social: 0.46, energy: 0.78, expression: 0.74, humor: 0.96, competition: 0.6, creativity: 0.94, care: 0.66, risk: 0.5, recharge: 0.18 } },
  { id: "felix", name: "Felix", emoji: "🐥", profile: { planning: 0.56, social: 0.88, energy: 0.76, expression: 0.94, humor: 0.78, competition: 0.58, creativity: 0.72, care: 0.96, risk: 0.7, recharge: 0.52 } },
  { id: "seungmin", name: "Seungmin", emoji: "🐶", profile: { planning: 0.84, social: 0.58, energy: 0.54, expression: 0.42, humor: 0.72, competition: 0.82, creativity: 0.58, care: 0.5, risk: 0.38, recharge: 0.3 } },
  { id: "i-n", name: "I.N", emoji: "🦊", profile: { planning: 0.58, social: 0.68, energy: 0.7, expression: 0.62, humor: 0.76, competition: 0.72, creativity: 0.66, care: 0.64, risk: 0.76, recharge: 0.54 } }
].map((member) => Object.freeze({ ...member, profile: Object.freeze(member.profile) })));
