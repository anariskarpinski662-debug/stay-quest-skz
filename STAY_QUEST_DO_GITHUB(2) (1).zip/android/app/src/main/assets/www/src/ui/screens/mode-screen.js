import { findGameMode } from "../../data/game-modes.js";
import { getQuizQuestionCount } from "../../data/question-bank.js";
import { TIMELINE_EVENT_COUNT, TIMELINE_SET_TEMPLATES } from "../../data/timeline-events.js";
import { MEMBER_SYMBOLS } from "../../data/member-symbols.js";
import { getLocalDateKey } from "../../data/daily-challenge.js";
import { escapeHtml } from "../html.js";

const DIFFICULTIES = Object.freeze([
  { value: "mixed", name: "Mieszana", level: "AUTO", description: "Równa mieszanka poziomów" },
  { value: "1", name: "Baby STAY", level: "01", description: "Przystępne, ale nadal wymagające tropy" },
  { value: "2", name: "STAY", level: "02", description: "Normalny fanowski poziom" },
  { value: "3", name: "Veteran", level: "03", description: "Szczegóły i bliższe odpowiedzi" },
  { value: "4", name: "Master", level: "04", description: "Trudne fakty i nieoczywiste tropy" },
  { value: "5", name: "Insane", level: "05", description: "Fandomowe piekło bez tanich sztuczek" }
]);

function getContentSummary(modeId) {
  const questionCount = getQuizQuestionCount(modeId);
  if (questionCount) return `${questionCount} zadań w banku • runda losuje 10`;
  if (modeId === "timeline") return `${TIMELINE_SET_TEMPLATES.length} gotowych układów z ${TIMELINE_EVENT_COUNT} wydarzeń`;
  if (modeId === "skzoo-memory") return `${MEMBER_SYMBOLS.length} postaci • pięć mechanik trudności i aktywny czas`;
  if (modeId === "daily-challenge") return "10 mieszanych zadań • jeden punktowany wynik dziennie";
  if (modeId === "soulmate-lab") return "25 pytań z puli 40 • bez punktów i błędnych odpowiedzi";
  return "Tryb gotowy";
}

function renderDifficultyPicker(mode) {
  const minimum = mode.minimumDifficulty ?? 1;
  const available = DIFFICULTIES.filter((difficulty) => difficulty.value === "mixed" || Number(difficulty.value) >= minimum);
  return `
    <section class="difficulty-picker" aria-labelledby="difficulty-title">
      <div class="section-heading section-heading--compact">
        <div><p class="eyebrow">Ranga profilu zostaje bez zmian</p><h2 id="difficulty-title">Wybierz poziom gry</h2></div>
      </div>
      <div class="difficulty-picker__grid">
        ${available.map((difficulty) => `
          <a href="#/play/${escapeHtml(mode.id)}/${difficulty.value}" class="difficulty-choice">
            <span>${difficulty.level}</span>
            <div><strong>${difficulty.name}</strong><small>${difficulty.description}</small></div>
            <b aria-hidden="true">→</b>
          </a>
        `).join("")}
      </div>
    </section>
  `;
}

function renderSingleAction(mode, state) {
  const completedToday = mode.id === "daily-challenge" && state?.daily?.completedDates?.includes(getLocalDateKey());
  const label = mode.id === "soulmate-lab"
    ? "Rozpocznij zabawę"
    : completedToday
      ? "Zagraj ponownie treningowo"
      : "Rozpocznij dzisiejsze wyzwanie";
  return `
    <a class="button button--primary button--wide" href="#/play/${escapeHtml(mode.id)}">
      ${label} <span aria-hidden="true">→</span>
    </a>
  `;
}

export function createModeScreen(modeId, state) {
  const mode = findGameMode(modeId);
  const screen = document.createElement("div");
  screen.className = "screen mode-screen";

  if (!mode) {
    screen.innerHTML = `
      <section class="empty-state">
        <span aria-hidden="true">?</span>
        <h1>Nie ma takiego trybu</h1>
        <p>Wróć do ekranu głównego i wybierz jedną z dostępnych kart.</p>
        <a class="button button--primary" href="#/home">Wróć do trybów</a>
      </section>
    `;
    return screen;
  }

  const items = mode.implementation.map((item) => `<li>${escapeHtml(item)}</li>`).join("");
  const reward = mode.reward > 0 ? "punkty zależą od realnej trudności i jakości wykonania" : "bez punktów do rangi";
  screen.innerHTML = `
    <a class="back-link" href="#/home">← Wszystkie tryby</a>
    <section class="mode-hero mode-hero--${escapeHtml(mode.accent)}">
      <span class="mode-hero__icon" aria-hidden="true">${escapeHtml(mode.icon)}</span>
      <p class="eyebrow">${escapeHtml(mode.eyebrow)}</p>
      <h1>${escapeHtml(mode.name)}</h1>
      <p>${escapeHtml(mode.description)}</p>
      <div class="mode-hero__meta"><strong>${reward}</strong><span>${escapeHtml(mode.plannedContent)}</span></div>
    </section>
    <section class="build-card">
      <p class="eyebrow">Zasady trybu</p>
      <h2>Co czeka w tej rozgrywce</h2>
      <ul>${items}</ul>
      <p class="build-card__note">${escapeHtml(getContentSummary(mode.id))}. Postęp zapisuje się automatycznie po ukończeniu.</p>
    </section>
    ${mode.supportsDifficulty ? renderDifficultyPicker(mode) : `<div class="mode-single-action">${renderSingleAction(mode, state)}</div>`}
  `;
  return screen;
}
