export const QUESTION_TYPES = Object.freeze({
  SINGLE_CHOICE: "single-choice",
  TEXT: "text"
});

export const CONTENT_KINDS = Object.freeze([
  "official_fact",
  "official_media_detail",
  "puzzle_interpretation",
  "fandom_lore",
  "fan_theory"
]);

function isNonEmptyString(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function hasValidOfficialSource(question) {
  if (!["official_fact", "official_media_detail"].includes(question.kind)) return true;

  let sourceUrl;
  try {
    sourceUrl = new URL(question.source?.url);
  } catch {
    return false;
  }

  return (
    question.source &&
    isNonEmptyString(question.source.title) &&
    ["http:", "https:"].includes(sourceUrl.protocol) &&
    /^\d{4}-\d{2}-\d{2}$/.test(question.source.checkedAt)
  );
}

export function normalizeAnswer(value) {
  return String(value ?? "")
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLocaleLowerCase("pl-PL")
    .replace(/&/g, " and ")
    .replace(/[’'`]/g, "")
    .replace(/[^\p{Letter}\p{Number}]+/gu, " ")
    .trim()
    .replace(/\s+/g, " ");
}

export function validateQuestion(question) {
  const errors = [];

  if (!question || typeof question !== "object") {
    return { valid: false, errors: ["Pytanie musi być obiektem."] };
  }

  if (!isNonEmptyString(question.id)) errors.push("Brakuje identyfikatora pytania.");
  if (question.topicId !== undefined && !isNonEmptyString(question.topicId)) errors.push("Identyfikator tematu nie może być pusty.");
  if (!isNonEmptyString(question.modeId)) errors.push("Brakuje identyfikatora trybu.");
  if (!Object.values(QUESTION_TYPES).includes(question.type)) errors.push("Nieobsługiwany typ pytania.");
  if (!isNonEmptyString(question.prompt)) errors.push("Treść pytania jest pusta.");
  if (!isNonEmptyString(question.category)) errors.push("Brakuje kategorii pytania.");
  if (!CONTENT_KINDS.includes(question.kind)) errors.push("Nieobsługiwany rodzaj treści.");
  if (!Number.isInteger(question.difficulty) || question.difficulty < 1 || question.difficulty > 5) {
    errors.push("Poziom trudności musi być liczbą od 1 do 5.");
  }
  if (!Number.isInteger(question.basePoints) || question.basePoints <= 0) {
    errors.push("Bazowa liczba punktów musi być dodatnią liczbą całkowitą.");
  }
  if (!isNonEmptyString(question.explanation)) errors.push("Brakuje wyjaśnienia odpowiedzi.");
  if (!hasValidOfficialSource(question)) errors.push("Oficjalny fakt wymaga kompletnego źródła.");

  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    if (!Array.isArray(question.options) || question.options.length < 2) {
      errors.push("Pytanie jednokrotnego wyboru wymaga co najmniej dwóch opcji.");
    } else {
      const optionIds = question.options.map((option) => option?.id);
      if (question.options.some((option) => !isNonEmptyString(option?.id) || !isNonEmptyString(option?.label))) {
        errors.push("Każda opcja wymaga identyfikatora i etykiety.");
      }
      if (new Set(optionIds).size !== optionIds.length) errors.push("Identyfikatory opcji muszą być unikalne.");
      if (!optionIds.includes(question.correctOptionId)) errors.push("Poprawna odpowiedź nie wskazuje istniejącej opcji.");
    }
  }

  if (question.type === QUESTION_TYPES.TEXT) {
    if (!Array.isArray(question.acceptedAnswers) || !question.acceptedAnswers.some(isNonEmptyString)) {
      errors.push("Pytanie tekstowe wymaga co najmniej jednej akceptowanej odpowiedzi.");
    }
    if (!isNonEmptyString(question.displayAnswer)) errors.push("Pytanie tekstowe wymaga odpowiedzi do wyświetlenia.");
  }

  if (question.clues !== undefined) {
    if (!Array.isArray(question.clues) || question.clues.length === 0 || !question.clues.every(isNonEmptyString)) {
      errors.push("Tropy muszą być niepustą tablicą tekstów.");
    }
  }

  if (question.cluePolicy !== undefined) {
    const policy = question.cluePolicy;
    if (!Array.isArray(question.clues) || question.clues.length < 2) {
      errors.push("Stopniowe odsłanianie wymaga co najmniej dwóch tropów.");
    } else if (
      !Number.isInteger(policy?.initialVisible) ||
      policy.initialVisible < 1 ||
      policy.initialVisible > question.clues.length
    ) {
      errors.push("Nieprawidłowa początkowa liczba widocznych tropów.");
    }
    if (!Number.isInteger(policy?.penaltyPerReveal) || policy.penaltyPerReveal < 0) {
      errors.push("Kara za dodatkowy trop musi być nieujemną liczbą całkowitą.");
    }
  }

  if (question.hint !== undefined && !isNonEmptyString(question.hint)) errors.push("Podpowiedź nie może być pusta.");
  if (question.hints !== undefined) {
    if (!Array.isArray(question.hints) || question.hints.length < 1 || question.hints.length > 2) {
      errors.push("Pytanie może mieć jeden albo dwa poziomy podpowiedzi.");
    } else if (question.hints.some((hint) => !isNonEmptyString(hint?.text) || !Number.isFinite(hint?.penaltyRate) || hint.penaltyRate < 0 || hint.penaltyRate > 0.4)) {
      errors.push("Każda podpowiedź wymaga tekstu i poprawnej kary punktowej.");
    }
  }

  return { valid: errors.length === 0, errors };
}

export function validateQuestionBank(questions) {
  const errors = [];

  if (!Array.isArray(questions) || questions.length === 0) {
    return { valid: false, errors: ["Bank pytań nie może być pusty."] };
  }

  const ids = new Set();
  questions.forEach((question, index) => {
    const validation = validateQuestion(question);
    validation.errors.forEach((error) => errors.push(`Pytanie ${index + 1}: ${error}`));

    if (isNonEmptyString(question?.id)) {
      if (ids.has(question.id)) errors.push(`Powtórzony identyfikator pytania: ${question.id}.`);
      ids.add(question.id);
    }
  });

  return { valid: errors.length === 0, errors };
}

export function isAnswerCorrect(question, answer) {
  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    return answer === question.correctOptionId;
  }

  if (question.type === QUESTION_TYPES.TEXT) {
    const normalized = normalizeAnswer(answer);
    if (!normalized) return false;
    return question.acceptedAnswers.some((accepted) => normalizeAnswer(accepted) === normalized);
  }

  return false;
}

export function getCorrectAnswerLabel(question) {
  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    return question.options.find(({ id }) => id === question.correctOptionId)?.label ?? "";
  }

  return question.displayAnswer ?? question.acceptedAnswers?.[0] ?? "";
}

export function getSubmittedAnswerLabel(question, answer) {
  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    return question.options.find(({ id }) => id === answer)?.label ?? "";
  }
  return String(answer ?? "").trim();
}
