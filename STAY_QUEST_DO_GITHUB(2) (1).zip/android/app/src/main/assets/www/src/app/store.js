import { GAME_MODES } from "../data/game-modes.js";
import { ACHIEVEMENTS } from "../data/achievements.js";
import { applyAchievementUnlocks, applyGameResult, getLevelInfo } from "../game/progress.js";

export const STORAGE_KEY = "stay-quest-state-v1";
export const LEGACY_STORAGE_KEYS = Object.freeze([
  "stay-quest-state",
  "stay-quest-progress",
  "stayQuestState",
  "stayQuestProgress",
  "skz-stay-quest-state"
]);
export const LEGACY_BACKUP_KEY = "stay-quest-legacy-backup-v1";
export const STATE_VERSION = 5;

const MODE_IDS = new Set(GAME_MODES.map(({ id }) => id));
const ACHIEVEMENT_IDS = new Set(ACHIEVEMENTS.map(({ id }) => id));
const TEXT_SCALES = new Set(["small", "standard", "large"]);
const DATE_KEY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function emptyRecord() {
  return {
    plays: 0,
    bestScore: 0,
    bestAccuracy: 0,
    bestStreak: 0,
    lastScore: 0,
    lastAccuracy: 0,
    lastPlayedAt: null,
    bestMovesBySize: {},
    bestTimeBySize: {},
    largestPerfectRound: 0
  };
}

function emptyRecords() {
  return Object.fromEntries(GAME_MODES.map(({ id }) => [id, emptyRecord()]));
}

function emptyQuestionHistory() {
  return Object.fromEntries(GAME_MODES.map(({ id }) => [id, []]));
}

export function createInitialState() {
  return {
    schemaVersion: STATE_VERSION,
    player: {
      displayName: "STAY",
      totalPoints: 0,
      level: 1,
      rank: "Baby STAY",
      rankFloor: "Baby STAY",
      currentStreak: 0,
      bestStreak: 0
    },
    stats: {
      gamesPlayed: 0,
      correctAnswers: 0,
      totalAnswers: 0,
      perfectQuizRounds: 0,
      perfectTimelineRounds: 0,
      perfectMemoryRounds: 0,
      completedModes: []
    },
    records: emptyRecords(),
    achievements: { unlocked: [] },
    history: [],
    questionHistory: emptyQuestionHistory(),
    daily: {
      completedDates: [],
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: null,
      results: []
    },
    soulmate: {
      completedCount: 0,
      lastCompletedAt: null,
      lastResult: null
    },
    migration: {
      version: STATE_VERSION,
      migratedAt: null,
      sourceKey: null,
      legacyPointsPreserved: 0
    },
    settings: {
      soundEnabled: true,
      hapticsEnabled: true,
      reducedMotion: false,
      highContrast: false,
      textScale: "standard"
    }
  };
}

const RANK_ORDER = Object.freeze(["Baby STAY", "Rookie STAY", "Core STAY", "Veteran STAY", "Master STAY", "Legend STAY"]);

function safeRank(value, fallback = "Baby STAY") {
  return RANK_ORDER.includes(value) ? value : fallback;
}

function higherRank(first, second) {
  return RANK_ORDER.indexOf(first) >= RANK_ORDER.indexOf(second) ? first : second;
}

function safeInteger(value, fallback = 0) {
  return Number.isInteger(value) && value >= 0 ? value : fallback;
}

function safePercentage(value, fallback = 0) {
  return Number.isFinite(value) && value >= 0 && value <= 100 ? Math.round(value) : fallback;
}

function safeDate(value) {
  if (typeof value !== "string" || Number.isNaN(Date.parse(value))) return null;
  return new Date(value).toISOString();
}

function safeDateKey(value) {
  if (typeof value !== "string" || !DATE_KEY_PATTERN.test(value)) return null;
  const parsed = Date.parse(`${value}T00:00:00Z`);
  return Number.isNaN(parsed) ? null : value;
}

function safeName(value) {
  const normalized = String(value ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 24);
  return normalized || "STAY";
}

function extractLegacyPoints(value) {
  const candidates = [
    value?.player?.totalPoints,
    value?.profile?.totalPoints,
    value?.profile?.points,
    value?.stats?.totalPoints,
    value?.totalPoints,
    value?.points,
    value?.score
  ].filter((entry) => Number.isInteger(entry) && entry >= 0);
  return candidates.length ? Math.max(...candidates) : 0;
}

function extractLegacyName(value) {
  return value?.player?.displayName ?? value?.profile?.displayName ?? value?.profile?.name ?? value?.displayName ?? value?.name;
}

function safeSizeMap(value) {
  if (!value || typeof value !== "object") return {};
  return Object.fromEntries(
    ["4", "6", "8"]
      .filter((key) => Number.isInteger(value[key]) && value[key] >= 0)
      .map((key) => [key, value[key]])
  );
}

function sanitizeRecord(value) {
  const initial = emptyRecord();
  if (!value || typeof value !== "object") return initial;
  return {
    plays: safeInteger(value.plays),
    bestScore: safeInteger(value.bestScore),
    bestAccuracy: safePercentage(value.bestAccuracy),
    bestStreak: safeInteger(value.bestStreak),
    lastScore: safeInteger(value.lastScore),
    lastAccuracy: safePercentage(value.lastAccuracy),
    lastPlayedAt: safeDate(value.lastPlayedAt),
    bestMovesBySize: safeSizeMap(value.bestMovesBySize),
    bestTimeBySize: safeSizeMap(value.bestTimeBySize),
    largestPerfectRound: [0, 4, 6, 8].includes(value.largestPerfectRound) ? value.largestPerfectRound : 0
  };
}

function sanitizeHistory(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((entry) => entry && MODE_IDS.has(entry.modeId) && ["quiz", "timeline", "memory"].includes(entry.kind))
    .map((entry, index) => ({
      id: String(entry.id ?? `history-${index}`).slice(0, 160),
      modeId: entry.modeId,
      kind: entry.kind,
      score: safeInteger(entry.score),
      accuracy: safePercentage(entry.accuracy),
      completedAt: safeDate(entry.completedAt) ?? new Date(0).toISOString(),
      details: entry.details && typeof entry.details === "object" ? structuredClone(entry.details) : {}
    }))
    .slice(0, 50);
}

function sanitizeQuestionHistory(value) {
  return Object.fromEntries(GAME_MODES.map(({ id }) => {
    const entries = Array.isArray(value?.[id]) ? value[id] : [];
    const safe = entries
      .map((entry) => {
        if (typeof entry === "string" && entry.length > 0) {
          return { id: entry.slice(0, 180), topicId: entry.slice(0, 180), seenAt: null, correct: null };
        }
        if (!entry || typeof entry !== "object" || typeof entry.id !== "string" || !entry.id) return null;
        return {
          id: entry.id.slice(0, 180),
          topicId: String(entry.topicId || entry.factId || entry.id).slice(0, 180),
          seenAt: safeDate(entry.seenAt),
          correct: typeof entry.correct === "boolean" ? entry.correct : null
        };
      })
      .filter(Boolean)
      .filter((entry, index, all) => all.findIndex((candidate) => candidate.id === entry.id) === index)
      .slice(0, 100);
    return [id, safe];
  }));
}

function sanitizeDaily(value) {
  const completedDates = Array.isArray(value?.completedDates)
    ? value.completedDates
        .map(safeDateKey)
        .filter(Boolean)
        .filter((date, index, dates) => dates.indexOf(date) === index)
        .sort()
        .slice(-400)
    : [];
  const results = Array.isArray(value?.results)
    ? value.results
        .map((result) => ({
          date: safeDateKey(result?.date),
          score: safeInteger(result?.score),
          accuracy: safePercentage(result?.accuracy),
          correctAnswers: safeInteger(result?.correctAnswers),
          completedAt: safeDate(result?.completedAt)
        }))
        .filter((result) => result.date && result.completedAt)
        .slice(0, 60)
    : [];
  return {
    completedDates,
    currentStreak: safeInteger(value?.currentStreak),
    bestStreak: safeInteger(value?.bestStreak),
    lastCompletedDate: safeDateKey(value?.lastCompletedDate),
    results
  };
}

function sanitizeSoulmate(value) {
  const lastResult = value?.lastResult && typeof value.lastResult === "object"
    ? structuredClone(value.lastResult)
    : null;
  return {
    completedCount: safeInteger(value?.completedCount),
    lastCompletedAt: safeDate(value?.lastCompletedAt),
    lastResult
  };
}

export function sanitizeState(value) {
  const initial = createInitialState();
  if (!value || typeof value !== "object") return initial;

  const totalPoints = extractLegacyPoints(value);
  const levelInfo = getLevelInfo(totalPoints);
  const legacyRank = safeRank(value.player?.rank ?? value.profile?.rank);
  const rankFloor = higherRank(safeRank(value.player?.rankFloor), legacyRank);
  const completedModes = Array.isArray(value.stats?.completedModes)
    ? [...new Set(value.stats.completedModes.filter((id) => MODE_IDS.has(id)))]
    : [];
  const unlocked = Array.isArray(value.achievements?.unlocked)
    ? value.achievements.unlocked
        .filter((entry) => entry && ACHIEVEMENT_IDS.has(entry.id))
        .filter((entry, index, entries) => entries.findIndex(({ id }) => id === entry.id) === index)
        .map((entry) => ({ id: entry.id, unlockedAt: safeDate(entry.unlockedAt) ?? new Date(0).toISOString() }))
    : [];

  return {
    schemaVersion: STATE_VERSION,
    player: {
      displayName: safeName(extractLegacyName(value)),
      totalPoints,
      level: levelInfo.level,
      rank: higherRank(levelInfo.rank, rankFloor),
      rankFloor,
      currentStreak: safeInteger(value.player?.currentStreak),
      bestStreak: safeInteger(value.player?.bestStreak ?? value.player?.currentStreak)
    },
    stats: {
      gamesPlayed: safeInteger(value.stats?.gamesPlayed),
      correctAnswers: safeInteger(value.stats?.correctAnswers),
      totalAnswers: safeInteger(value.stats?.totalAnswers),
      perfectQuizRounds: safeInteger(value.stats?.perfectQuizRounds),
      perfectTimelineRounds: safeInteger(value.stats?.perfectTimelineRounds),
      perfectMemoryRounds: safeInteger(value.stats?.perfectMemoryRounds),
      completedModes
    },
    records: Object.fromEntries(
      GAME_MODES.map(({ id }) => [id, sanitizeRecord(value.records?.[id])])
    ),
    achievements: { unlocked },
    history: sanitizeHistory(value.history),
    questionHistory: sanitizeQuestionHistory(value.questionHistory),
    daily: sanitizeDaily(value.daily),
    soulmate: sanitizeSoulmate(value.soulmate),
    migration: {
      version: STATE_VERSION,
      migratedAt: safeDate(value.migration?.migratedAt),
      sourceKey: typeof value.migration?.sourceKey === "string" ? value.migration.sourceKey.slice(0, 100) : null,
      legacyPointsPreserved: Math.max(totalPoints, safeInteger(value.migration?.legacyPointsPreserved))
    },
    settings: {
      soundEnabled: typeof value.settings?.soundEnabled === "boolean" ? value.settings.soundEnabled : initial.settings.soundEnabled,
      hapticsEnabled: typeof value.settings?.hapticsEnabled === "boolean" ? value.settings.hapticsEnabled : initial.settings.hapticsEnabled,
      reducedMotion: typeof value.settings?.reducedMotion === "boolean" ? value.settings.reducedMotion : initial.settings.reducedMotion,
      highContrast: typeof value.settings?.highContrast === "boolean" ? value.settings.highContrast : initial.settings.highContrast,
      textScale: TEXT_SCALES.has(value.settings?.textScale) ? value.settings.textScale : initial.settings.textScale
    }
  };
}

function parseStoredCandidate(storage, key) {
  try {
    const raw = storage?.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const value = parsed?.state && typeof parsed.state === "object" ? parsed.state : parsed;
    if (!value || typeof value !== "object") return null;
    return { key, raw, state: sanitizeState(value), schemaVersion: Number(value.schemaVersion) || 0 };
  } catch {
    return null;
  }
}

function compareCandidates(first, second) {
  const pointDifference = second.state.player.totalPoints - first.state.player.totalPoints;
  if (pointDifference) return pointDifference;
  const gameDifference = second.state.stats.gamesPlayed - first.state.stats.gamesPlayed;
  if (gameDifference) return gameDifference;
  return second.schemaVersion - first.schemaVersion;
}

function readSavedState(storage, now) {
  const keys = [STORAGE_KEY, ...LEGACY_STORAGE_KEYS];
  const candidates = keys.map((key) => parseStoredCandidate(storage, key)).filter(Boolean).sort(compareCandidates);
  if (!candidates.length) return { state: createInitialState(), migrated: false };

  const selected = candidates[0];
  const needsMigration = selected.key !== STORAGE_KEY || selected.schemaVersion < STATE_VERSION;
  const state = selected.state;
  if (needsMigration) {
    state.migration = {
      version: STATE_VERSION,
      migratedAt: new Date(now()).toISOString(),
      sourceKey: selected.key,
      legacyPointsPreserved: selected.state.player.totalPoints
    };
  }

  return { state, migrated: needsMigration, candidate: selected };
}

function getDefaultStorage() {
  try {
    return globalThis.localStorage;
  } catch {
    return null;
  }
}

function dayDifference(from, to) {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000);
}

export function createStore(options = {}) {
  const storage = options.storage === undefined ? getDefaultStorage() : options.storage;
  const now = options.now ?? (() => new Date());
  const restored = readSavedState(storage, now);
  let state = restored.state;
  const listeners = new Set();

  if (restored.migrated && restored.candidate) {
    try {
      if (!storage?.getItem(LEGACY_BACKUP_KEY)) {
        storage?.setItem(LEGACY_BACKUP_KEY, JSON.stringify({
          sourceKey: restored.candidate.key,
          backedUpAt: new Date(now()).toISOString(),
          raw: restored.candidate.raw
        }));
      }
      storage?.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Gra nadal korzysta z bezpiecznie odczytanego stanu w pamięci.
    }
  }

  function getState() {
    return structuredClone(state);
  }

  function persist() {
    try {
      storage?.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch {
      return false;
    }
  }

  function notify() {
    const snapshot = getState();
    listeners.forEach((listener) => listener(snapshot));
  }

  function commit(nextState, { allowProgressDecrease = false } = {}) {
    const sanitized = sanitizeState(nextState);
    if (!allowProgressDecrease && sanitized.player.totalPoints < state.player.totalPoints) {
      sanitized.player.totalPoints = state.player.totalPoints;
      const levelInfo = getLevelInfo(sanitized.player.totalPoints);
      sanitized.player.level = levelInfo.level;
      sanitized.player.rank = higherRank(state.player.rank, levelInfo.rank);
      sanitized.player.rankFloor = higherRank(state.player.rankFloor, sanitized.player.rankFloor);
    }
    state = sanitized;
    const saved = persist();
    notify();
    return { state: getState(), saved };
  }

  function replaceState(nextState) {
    return commit(nextState);
  }

  function setState(updater) {
    const nextState = typeof updater === "function" ? updater(getState()) : updater;
    return replaceState(nextState);
  }

  function updateProfile(displayName) {
    return replaceState({
      ...state,
      player: { ...state.player, displayName: safeName(displayName) }
    });
  }

  function updateSettings(changes) {
    return replaceState({
      ...state,
      settings: { ...state.settings, ...(changes ?? {}) }
    });
  }

  function recordResult(result) {
    const applied = applyGameResult(state, result, { now });
    const committed = commit(applied.state);
    return { ...committed, newlyUnlocked: applied.newlyUnlocked, alreadyRecorded: false };
  }

  function recordDailyResult(result, dateKey) {
    const safeKey = safeDateKey(dateKey);
    if (!safeKey) throw new TypeError("Daily Challenge ma nieprawidłową datę.");
    if (state.daily.completedDates.includes(safeKey)) {
      return { state: getState(), saved: true, newlyUnlocked: [], alreadyRecorded: true };
    }

    const completedAt = new Date(now()).toISOString();
    const applied = applyGameResult(state, result, { now });
    const previousDate = applied.state.daily.lastCompletedDate;
    const currentStreak = previousDate && dayDifference(previousDate, safeKey) === 1
      ? applied.state.daily.currentStreak + 1
      : 1;
    applied.state.daily = {
      ...applied.state.daily,
      completedDates: [...applied.state.daily.completedDates, safeKey],
      currentStreak,
      bestStreak: Math.max(applied.state.daily.bestStreak, currentStreak),
      lastCompletedDate: safeKey,
      results: [{
        date: safeKey,
        score: result.score,
        accuracy: result.accuracy,
        correctAnswers: result.correctAnswers,
        completedAt
      }, ...applied.state.daily.results].slice(0, 60)
    };

    const meta = applyAchievementUnlocks(applied.state, completedAt);
    const committed = commit(meta.state);
    return {
      ...committed,
      newlyUnlocked: [...new Set([...applied.newlyUnlocked, ...meta.newlyUnlocked])],
      alreadyRecorded: false
    };
  }

  function recordSoulmateResult(result) {
    if (!result?.topMatches?.length) throw new TypeError("Brakuje wyniku Bratniej Duszy.");
    const completedAt = new Date(now()).toISOString();
    const next = {
      ...state,
      soulmate: {
        completedCount: state.soulmate.completedCount + 1,
        lastCompletedAt: completedAt,
        lastResult: structuredClone(result)
      }
    };
    const meta = applyAchievementUnlocks(next, completedAt);
    const committed = commit(meta.state);
    return { ...committed, newlyUnlocked: meta.newlyUnlocked };
  }

  function getRecentQuestionIds(modeId) {
    return MODE_IDS.has(modeId) ? (state.questionHistory[modeId] ?? []).map(({ id }) => id) : [];
  }

  function getRecentQuestionHistory(modeId) {
    return MODE_IDS.has(modeId) ? structuredClone(state.questionHistory[modeId] ?? []) : [];
  }

  function exportBackup() {
    return JSON.stringify(
      {
        appId: "stay-quest",
        schemaVersion: STATE_VERSION,
        exportedAt: new Date(now()).toISOString(),
        state: getState()
      },
      null,
      2
    );
  }

  function importBackup(text) {
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new TypeError("Plik nie zawiera poprawnej kopii JSON.");
    }
    if (parsed?.appId && parsed.appId !== "stay-quest") throw new TypeError("To nie jest kopia STAY QUEST.");
    const importedState = parsed?.state ?? parsed;
    if (!importedState?.player || !importedState?.settings) throw new TypeError("Kopia nie zawiera wymaganego stanu gry.");
    return replaceState(importedState);
  }

  function reset() {
    return commit(createInitialState(), { allowProgressDecrease: true });
  }

  function subscribe(listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  return {
    getState,
    setState,
    updateProfile,
    updateSettings,
    recordResult,
    recordDailyResult,
    recordSoulmateResult,
    getRecentQuestionIds,
    getRecentQuestionHistory,
    exportBackup,
    importBackup,
    reset,
    subscribe
  };
}
