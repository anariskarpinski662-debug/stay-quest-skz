import { sampleWithoutReplacement } from "./random.js";
import { SOULMATE_DIMENSIONS } from "../data/soulmate-questions.js";

function clone(value) {
  return structuredClone(value);
}

export function validateSoulmateQuestions(questions) {
  const errors = [];
  if (!Array.isArray(questions) || questions.length < 25) {
    return { valid: false, errors: ["STAY Lab wymaga co najmniej 25 pytań."] };
  }
  const ids = new Set();
  questions.forEach((question, index) => {
    if (!question?.id || !question?.prompt || !SOULMATE_DIMENSIONS[question?.dimension]) {
      errors.push(`Pytanie ${index + 1} ma niepełne dane.`);
    }
    if (!Array.isArray(question?.options) || question.options.length !== 4) {
      errors.push(`Pytanie ${index + 1} musi mieć cztery odpowiedzi.`);
    } else if (question.options.some((option) => !option?.id || !option?.label || !Number.isFinite(option?.value) || option.value < 0 || option.value > 1)) {
      errors.push(`Pytanie ${index + 1} ma nieprawidłową odpowiedź.`);
    }
    if (ids.has(question?.id)) errors.push(`Powtórzone pytanie: ${question.id}.`);
    ids.add(question?.id);
  });
  return { valid: errors.length === 0, errors };
}

export function createSoulmateSession({ questions, members, questionCount = 25, random = Math.random }) {
  const validation = validateSoulmateQuestions(questions);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (!Array.isArray(members) || members.length !== 8) throw new TypeError("Dopasowanie wymaga całej ósemki.");
  if (!Number.isInteger(questionCount) || questionCount < 1 || questionCount > questions.length) {
    throw new RangeError("Nieprawidłowa liczba pytań STAY Lab.");
  }

  const selected = sampleWithoutReplacement(questions, questionCount, random);
  const answers = [];
  let index = 0;
  let status = "active";
  let result = null;

  function publicQuestion(question) {
    return { id: question.id, prompt: question.prompt, options: clone(question.options) };
  }

  function getSnapshot() {
    return {
      status,
      questionNumber: status === "complete" ? selected.length : index + 1,
      totalQuestions: selected.length,
      answeredQuestions: answers.length,
      currentQuestion: status === "active" ? publicQuestion(selected[index]) : null,
      result: result ? clone(result) : null
    };
  }

  function calculateResult() {
    const dimensionValues = {};
    for (const dimension of Object.keys(SOULMATE_DIMENSIONS)) {
      const matching = answers.filter((answer) => answer.dimension === dimension);
      if (matching.length) dimensionValues[dimension] = matching.reduce((sum, answer) => sum + answer.value, 0) / matching.length;
    }

    const matches = members.map((member) => {
      const distances = Object.entries(dimensionValues).map(([dimension, value]) => ({
        dimension,
        distance: Math.abs(value - member.profile[dimension])
      }));
      const averageDistance = distances.reduce((sum, item) => sum + item.distance, 0) / distances.length;
      const percentage = Math.max(52, Math.min(96, Math.round(96 - averageDistance * 48)));
      const closest = [...distances].sort((a, b) => a.distance - b.distance).slice(0, 3);
      return {
        id: member.id,
        name: member.name,
        emoji: member.emoji,
        percentage,
        reasons: closest.map(({ dimension }) => SOULMATE_DIMENSIONS[dimension].label)
      };
    }).sort((a, b) => b.percentage - a.percentage || a.name.localeCompare(b.name));

    return { topMatches: matches.slice(0, 3), allMatches: matches, dimensions: dimensionValues };
  }

  function answer(optionId) {
    if (status !== "active") throw new Error("Ta zabawa została już ukończona.");
    const question = selected[index];
    const option = question.options.find(({ id }) => id === optionId);
    if (!option) throw new TypeError("Wybierz jedną z dostępnych odpowiedzi.");

    answers.push({ questionId: question.id, dimension: question.dimension, value: option.value });
    if (index >= selected.length - 1) {
      status = "complete";
      result = calculateResult();
    } else {
      index += 1;
    }
    return getSnapshot();
  }

  function getResult() {
    if (status !== "complete") throw new Error("Najpierw odpowiedz na wszystkie pytania.");
    return clone(result);
  }

  return { getSnapshot, answer, getResult };
}
