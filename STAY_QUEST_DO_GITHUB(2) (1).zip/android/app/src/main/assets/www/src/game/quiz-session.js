import {
  QUESTION_TYPES,
  getCorrectAnswerLabel,
  getSubmittedAnswerLabel,
  isAnswerCorrect,
  validateQuestionBank
} from "./question-schema.js";
import { shuffle } from "./random.js";
import { calculateQuestionScore, getRepeatMultiplier } from "./scoring.js";

function clone(value) {
  return structuredClone(value);
}

function prepareQuestion(question, random) {
  const prepared = clone(question);
  prepared.topicId = prepared.topicId || prepared.factId || prepared.id;
  prepared.hints = Array.isArray(prepared.hints)
    ? prepared.hints
    : prepared.hint
      ? [{ text: prepared.hint, penaltyRate: 0.15 }]
      : [];
  if (prepared.type === QUESTION_TYPES.SINGLE_CHOICE) prepared.options = shuffle(prepared.options, random);
  return prepared;
}

const MIXED_DIFFICULTY_PATTERN = Object.freeze([1, 2, 2, 3, 3, 3, 4, 4, 5, 5]);

export function selectQuestionRound({
  questions,
  questionCount,
  difficulty = "mixed",
  recentQuestionIds = [],
  recentQuestionHistory = [],
  random = Math.random
}) {
  const count = Math.min(questionCount, questions.length);
  const normalizedHistory = recentQuestionHistory.length
    ? recentQuestionHistory
    : recentQuestionIds.map((id) => ({ id, topicId: id }));
  const recentIds = new Set([...recentQuestionIds, ...normalizedHistory.map(({ id }) => id)]);
  const recentTopics = new Set(normalizedHistory.slice(0, 100).map((entry) => entry?.topicId || entry?.id).filter(Boolean));
  const topicFresh = questions.filter((question) =>
    !recentIds.has(question.id)
    && !recentTopics.has(question.topicId || question.factId || question.id)
  );
  const idFresh = questions.filter((question) => !recentIds.has(question.id) && !topicFresh.includes(question));
  const seen = questions.filter((question) => !topicFresh.includes(question) && !idFresh.includes(question));
  const freshPool = [...shuffle(topicFresh, random), ...shuffle(idFresh, random)];
  const pool = freshPool.length >= count
    ? freshPool
    : [...freshPool, ...shuffle(seen, random)];

  if (difficulty === "mixed") {
    const selected = [];
    const available = [...pool];
    for (let index = 0; index < count; index += 1) {
      const target = MIXED_DIFFICULTY_PATTERN[index % MIXED_DIFFICULTY_PATTERN.length];
      const nearestDistance = Math.min(...available.map((question) => Math.abs(question.difficulty - target)));
      const nearestIndex = available.findIndex((question) => Math.abs(question.difficulty - target) === nearestDistance);
      selected.push(available.splice(nearestIndex, 1)[0]);
    }
    return selected;
  }

  const target = Number(difficulty);
  if (!Number.isInteger(target) || target < 1 || target > 5) throw new RangeError("Poziom gry musi wynosić od 1 do 5.");
  return pool
    .map((question, order) => ({ question, order, distance: Math.abs(question.difficulty - target) }))
    .sort((a, b) => a.distance - b.distance || a.order - b.order)
    .slice(0, count)
    .map(({ question }) => question);
}

function createPublicQuestion(question, revealedClueCount) {
  const allClues = question.clues ?? [];
  const visibleCount = Math.min(revealedClueCount, allClues.length);
  return {
    id: question.id,
    modeId: question.modeId,
    type: question.type,
    prompt: question.prompt,
    category: question.category,
    kind: question.kind,
    difficulty: question.difficulty,
    basePoints: question.basePoints,
    clues: clone(allClues.slice(0, visibleCount)),
    totalClues: allClues.length,
    canRevealClue: visibleCount < allClues.length,
    revealPenaltyPerClue: question.cluePolicy?.penaltyPerReveal ?? 0,
    options: clone(question.options ?? []),
    hintPenaltyRates: (question.hints ?? []).map(({ penaltyRate }) => penaltyRate),
    hintCount: question.hints?.length ?? 0,
    hasHint: Boolean(question.hints?.length)
  };
}

function validateSubmittedAnswer(question, answer) {
  if (question.type === QUESTION_TYPES.SINGLE_CHOICE) {
    if (!question.options.some(({ id }) => id === answer)) throw new TypeError("Wybierz jedną z dostępnych odpowiedzi.");
    return;
  }

  if (question.type === QUESTION_TYPES.TEXT && !String(answer ?? "").trim()) {
    throw new TypeError("Wpisz odpowiedź przed sprawdzeniem.");
  }
}

export function createQuizSession({
  modeId,
  questions,
  questionCount = questions?.length,
  difficulty = "mixed",
  recentQuestionIds = [],
  recentQuestionHistory = [],
  random = Math.random
}) {
  const validation = validateQuestionBank(questions);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (!modeId || typeof modeId !== "string") throw new TypeError("Sesja wymaga identyfikatora trybu.");
  if (questions.some((question) => question.modeId !== modeId)) {
    throw new TypeError("Bank sesji zawiera pytanie z innego trybu.");
  }
  if (!Number.isInteger(questionCount) || questionCount < 1) throw new RangeError("Sesja wymaga co najmniej jednego pytania.");

  const selectedQuestions = selectQuestionRound({ questions, questionCount, difficulty, recentQuestionIds, recentQuestionHistory, random }).map((question) =>
    prepareQuestion(question, random)
  );

  let index = 0;
  let status = "active";
  let score = 0;
  let currentStreak = 0;
  let longestStreak = 0;
  let revealedHints = [];
  let hintPenaltyRate = 0;
  let revealedClueCount = selectedQuestions[0].cluePolicy?.initialVisible ?? selectedQuestions[0].clues?.length ?? 0;
  let cluePenalty = 0;
  let lastResult = null;
  const history = [];

  function currentQuestion() {
    return selectedQuestions[index] ?? null;
  }

  function getSnapshot() {
    const question = status === "complete" ? null : currentQuestion();
    return {
      modeId,
      status,
      score,
      currentStreak,
      longestStreak,
      correctAnswers: history.filter(({ correct }) => correct).length,
      answeredQuestions: history.length,
      questionNumber: status === "complete" ? selectedQuestions.length : index + 1,
      totalQuestions: selectedQuestions.length,
      currentQuestion: question ? createPublicQuestion(question, revealedClueCount) : null,
      revealedHint: revealedHints.at(-1)?.text ?? null,
      revealedHints: clone(revealedHints),
      canUseHint: Boolean(question && revealedHints.length < (question.hints?.length ?? 0)),
      cluePenalty,
      lastResult: lastResult ? clone(lastResult) : null
    };
  }

  function useHint() {
    if (status !== "active") throw new Error("Podpowiedź można odsłonić tylko przed odpowiedzią.");
    const question = currentQuestion();
    const hint = question.hints?.[revealedHints.length];
    if (!hint) return null;

    revealedHints.push(clone(hint));
    hintPenaltyRate = Math.min(0.45, hintPenaltyRate + hint.penaltyRate);
    return hint.text;
  }

  function revealClue() {
    if (status !== "active") throw new Error("Trop można odsłonić tylko przed odpowiedzią.");
    const question = currentQuestion();
    const clues = question.clues ?? [];
    if (revealedClueCount >= clues.length) return null;

    const clueIndex = revealedClueCount;
    revealedClueCount += 1;
    const penalty = question.cluePolicy?.penaltyPerReveal ?? 0;
    cluePenalty += penalty;

    return {
      clue: clues[clueIndex],
      clueIndex,
      penalty,
      remaining: clues.length - revealedClueCount
    };
  }

  function finalizeAnswer(answer, skipped = false) {
    if (status !== "active") throw new Error("Na to pytanie została już udzielona odpowiedź.");
    const question = currentQuestion();
    if (!skipped) validateSubmittedAnswer(question, answer);

    const correct = skipped ? false : isAnswerCorrect(question, answer);
    const scoring = calculateQuestionScore({
      correct,
      basePoints: question.basePoints,
      difficulty: question.difficulty,
      currentStreak,
      hintPenaltyRate,
      extraPenalty: cluePenalty,
      repeatMultiplier: getRepeatMultiplier({
        questionId: question.id,
        topicId: question.topicId,
        recentHistory: recentQuestionHistory.length ? recentQuestionHistory : recentQuestionIds
      })
    });

    currentStreak = scoring.nextStreak;
    longestStreak = Math.max(longestStreak, currentStreak);
    score += scoring.total;

    lastResult = {
      questionId: question.id,
      questionNumber: index + 1,
      submittedAnswer: skipped ? null : answer,
      submittedAnswerLabel: skipped ? null : getSubmittedAnswerLabel(question, answer),
      correctAnswerId: question.type === QUESTION_TYPES.SINGLE_CHOICE ? question.correctOptionId : null,
      correctAnswer: getCorrectAnswerLabel(question),
      correct,
      skipped,
      earnedPoints: scoring.total,
      scoring,
      explanation: question.explanation,
      kind: question.kind,
      topicId: question.topicId,
      source: clone(question.source ?? null),
      hintsUsed: revealedHints.length,
      hintUsed: revealedHints.length > 0
    };

    history.push(clone(lastResult));
    status = "answered";
    return clone(lastResult);
  }

  function submitAnswer(answer) {
    return finalizeAnswer(answer, false);
  }

  function skip() {
    return finalizeAnswer(null, true);
  }

  function next() {
    if (status !== "answered") throw new Error("Najpierw odpowiedz na bieżące pytanie.");

    if (index >= selectedQuestions.length - 1) {
      status = "complete";
    } else {
      index += 1;
      status = "active";
      revealedHints = [];
      hintPenaltyRate = 0;
      revealedClueCount = selectedQuestions[index].cluePolicy?.initialVisible ?? selectedQuestions[index].clues?.length ?? 0;
      cluePenalty = 0;
      lastResult = null;
    }

    return getSnapshot();
  }

  function getSummary() {
    const answeredQuestions = history.length;
    const correctAnswers = history.filter(({ correct }) => correct).length;

    return {
      modeId,
      status,
      score,
      totalQuestions: selectedQuestions.length,
      answeredQuestions,
      correctAnswers,
      incorrectAnswers: answeredQuestions - correctAnswers,
      accuracy: answeredQuestions === 0 ? 0 : Math.round((correctAnswers / answeredQuestions) * 100),
      currentStreak,
      longestStreak,
      questionIds: selectedQuestions.map(({ id }) => id),
      questionHistory: history.map(({ questionId, topicId, correct }) => ({ id: questionId, topicId, correct })),
      topicIds: selectedQuestions.map(({ topicId }) => topicId),
      history: clone(history)
    };
  }

  return { getSnapshot, getSummary, useHint, revealClue, submitAnswer, skip, next };
}
