import { CONTENT_SOURCES } from "./question-bank.js";

export const TIMELINE_EVENTS = Object.freeze([
  { id: "mixtape-release", date: "2018-01-08", title: "Wydanie Mixtape", description: "Przeddebiutowe wydawnictwo trafia do oficjalnej dyskografii.", era: "Początki", source: CONTENT_SOURCES.earlyDiscography },
  { id: "i-am-not-release", date: "2018-03-26", title: "I am NOT i oficjalny debiut", description: "Rozpoczyna się albumowa trylogia „I am”.", era: "I am", source: CONTENT_SOURCES.earlyDiscography },
  { id: "i-am-who-release", date: "2018-08-06", title: "Wydanie I am WHO", description: "Druga część trylogii „I am”.", era: "I am", source: CONTENT_SOURCES.discography2019 },
  { id: "i-am-you-release", date: "2018-10-22", title: "Wydanie I am YOU", description: "Trzecia część trylogii „I am”.", era: "I am", source: CONTENT_SOURCES.discography2019 },
  { id: "miroh-release", date: "2019-03-25", title: "Wydanie Clé 1 : MIROH", description: "Start albumowej serii „Clé”.", era: "Clé", source: CONTENT_SOURCES.discography2019 },
  { id: "yellow-wood-release", date: "2019-06-19", title: "Wydanie Clé 2 : Yellow Wood", description: "Kolejny rozdział serii „Clé”.", era: "Clé", source: CONTENT_SOURCES.discography2019 },
  { id: "levanter-release", date: "2019-12-09", title: "Wydanie Clé : LEVANTER", description: "Zamknięcie głównej albumowej historii „Clé”.", era: "Clé", source: CONTENT_SOURCES.discography2019 },
  { id: "skz2020-release", date: "2020-03-18", title: "Wydanie SKZ2020", description: "Wydawnictwo pojawia się w oficjalnej dyskografii przed GO LIVE.", era: "2020", source: CONTENT_SOURCES.discography2020 },
  { id: "go-live-release", date: "2020-06-17", title: "Wydanie GO生 (GO LIVE)", description: "Pełny album otwiera okres z God's Menu.", era: "GO LIVE", source: CONTENT_SOURCES.discography2020 },
  { id: "in-life-release", date: "2020-09-14", title: "Wydanie IN生 (IN LIFE)", description: "Repackage rozwija okres GO LIVE.", era: "IN LIFE", source: CONTENT_SOURCES.discography2020 },
  { id: "kingdom-win", date: "2021-06-03", title: "Zwycięstwo w Kingdom: Legendary War", description: "Stray Kids zostają ogłoszeni końcowym zwycięzcą programu.", era: "Kingdom", source: CONTENT_SOURCES.kingdom },
  { id: "noeasy-release", date: "2021-08-23", title: "Wydanie NOEASY", description: "Album rozpoczyna okres Thunderous.", era: "NOEASY", source: CONTENT_SOURCES.discography2022 },
  { id: "christmas-evel-release", date: "2021-11-29", title: "Wydanie Christmas EveL", description: "Specjalne zimowe wydawnictwo trafia do dyskografii.", era: "Christmas EveL", source: CONTENT_SOURCES.discography2022 },
  { id: "oddinary-release", date: "2022-03-18", title: "Wydanie ODDINARY", description: "Rozpoczyna się okres MANIAC.", era: "ODDINARY", source: CONTENT_SOURCES.discography2022 },
  { id: "maxident-release", date: "2022-10-07", title: "Wydanie MAXIDENT", description: "Album otwiera okres CASE 143.", era: "MAXIDENT", source: CONTENT_SOURCES.discography2022 },
  { id: "five-star-release", date: "2023-06-02", title: "Wydanie ★★★★★ (5-STAR)", description: "Pełny album rozpoczyna okres S-Class.", era: "5-STAR", source: CONTENT_SOURCES.discography2024 },
  { id: "rock-star-release", date: "2023-11-10", title: "Wydanie 樂-STAR (ROCK-STAR)", description: "Minialbum rozpoczyna okres LALALALA.", era: "ROCK-STAR", source: CONTENT_SOURCES.discography2024 },
  { id: "ate-release", date: "2024-07-19", title: "Wydanie ATE", description: "Album otwiera okres Chk Chk Boom.", era: "ATE", source: CONTENT_SOURCES.discography2024 },
  { id: "ate-billboard", date: "2024-08-03", title: "ATE piątym kolejnym numerem 1", description: "Na datowanym w ten sposób zestawieniu Billboard 200 ATE kontynuuje rekordową serię.", era: "Osiągnięcia", source: CONTENT_SOURCES.billboard },
  { id: "giant-release", date: "2024-11-13", title: "Wydanie GIANT", description: "Japoński album trafia do oficjalnej dyskografii.", era: "GIANT", source: CONTENT_SOURCES.discography2025 },
  { id: "hop-release", date: "2024-12-13", title: "Wydanie 合 (HOP)", description: "SKZHOP HIPTAPE rozpoczyna okres Walkin On Water.", era: "HOP", source: CONTENT_SOURCES.discography2025 },
  { id: "mixtape-dominate-release", date: "2025-03-21", title: "Wydanie Mixtape : dominATE", description: "Projekt unitowy pojawia się w dyskografii.", era: "dominATE", source: CONTENT_SOURCES.discography2025 },
  { id: "hollow-release", date: "2025-06-18", title: "Wydanie Hollow", description: "Japoński minialbum zostaje udostępniony online.", era: "Hollow", source: CONTENT_SOURCES.discography2025 },
  { id: "karma-release", date: "2025-08-22", title: "Wydanie KARMA", description: "Kolejny album trafia do oficjalnej dyskografii.", era: "KARMA", source: CONTENT_SOURCES.discography2026 },
  { id: "do-it-release", date: "2025-11-21", title: "Wydanie DO IT", description: "SKZ IT TAPE kontynuuje serię albumowych numerów jeden.", era: "DO IT", source: CONTENT_SOURCES.discography2026 },
  { id: "endless-sun-release", date: "2026-03-13", title: "Wydanie Endless Sun", description: "Singiel pojawia się w oficjalnej dyskografii.", era: "2026", source: CONTENT_SOURCES.discography2026 },
  { id: "run-it-release", date: "2026-06-24", title: "Wydanie RUN IT", description: "Przedpremierowy utwór zapowiada późniejszy album i trasę.", era: "RUN IT", source: CONTENT_SOURCES.currentDiscography },
  { id: "run-it-tour-start", date: "2026-07-25", title: "Początek trasy RUN IT w Seulu", description: "Nowa światowa trasa rozpoczyna się koncertem w KSPO DOME.", era: "RUN IT", source: CONTENT_SOURCES.thisAndThat },
  { id: "skz-replay-2026-release", date: "2026-08-01", title: "Wydanie SKZ-REPLAY 2026 Pt.1", description: "Pierwsza część nowego SKZ-REPLAY trafia do dyskografii.", era: "2026", source: CONTENT_SOURCES.currentDiscography },
  { id: "this-and-that-release", date: "2026-08-07", title: "Wydanie THIS & THAT", description: "Ośmioutworowy album rozpoczyna okres This & That.", era: "THIS & THAT", source: CONTENT_SOURCES.thisAndThat }
]);

export const TIMELINE_EVENT_COUNT = TIMELINE_EVENTS.length;

function spacedIndexes(start, size, step) {
  return Array.from({ length: size }, (_, offset) => (start + offset * step) % TIMELINE_EVENTS.length)
    .sort((first, second) => first - second);
}

export const TIMELINE_SET_TEMPLATES = Object.freeze([
  ...Array.from({ length: 8 }, (_, index) => ({ difficulty: 1, eventIds: spacedIndexes(index, 4, 7) })),
  ...Array.from({ length: 8 }, (_, index) => ({ difficulty: 2, eventIds: spacedIndexes(index, index % 2 ? 6 : 4, 4) })),
  ...Array.from({ length: 8 }, (_, index) => ({ difficulty: 3, eventIds: spacedIndexes(index * 2, 6, 3) })),
  ...Array.from({ length: 8 }, (_, index) => ({ difficulty: 4, eventIds: Array.from({ length: index % 2 ? 8 : 6 }, (__, offset) => (index * 3 + offset) % TIMELINE_EVENTS.length).sort((a, b) => a - b) })),
  ...Array.from({ length: 8 }, (_, index) => ({ difficulty: 5, eventIds: Array.from({ length: 8 }, (__, offset) => index + offset) }))
].map((template, index) => Object.freeze({
  id: `timeline-set-${String(index + 1).padStart(2, "0")}`,
  difficulty: template.difficulty,
  eventIds: Object.freeze(template.eventIds.map((eventIndex) => TIMELINE_EVENTS[eventIndex].id))
})));
