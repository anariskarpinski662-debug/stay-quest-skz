const BASE_SCORE_RATE = 0.5;
const DIFFICULTY_STEP = 0.12;
const MAX_STREAK_BONUS = 24;
const STREAK_BONUS_STEP = 6;
const DEFAULT_HINT_PENALTY_RATE = 0.15;

export function getRepeatMultiplier({ questionId, topicId, recentHistory = [] }) {
  if (!Array.isArray(recentHistory) || recentHistory.length === 0) return 1;
  const normalizedTopic = topicId || questionId;
  const firstTopicIndex = recentHistory.findIndex((entry) => {
    if (typeof entry === "string") return entry === questionId;
    return (entry?.topicId || entry?.id) === normalizedTopic;
  });
  if (firstTopicIndex === -1 || firstTopicIndex >= 50) return 1;

  const occurrences = recentHistory.slice(0, 50).filter((entry) => {
    if (typeof entry === "string") return entry === questionId;
    return (entry?.topicId || entry?.id) === normalizedTopic;
  }).length;
  if (occurrences >= 3) return 0.35;
  if (occurrences === 2) return 0.5;
  return 0.75;
}

export function calculateQuestionScore({
  correct,
  basePoints,
  difficulty,
  currentStreak = 0,
  hintUsed = false,
  hintPenaltyRate = 0,
  extraPenalty = 0,
  repeatMultiplier = 1
}) {
  if (!Number.isInteger(basePoints) || basePoints <= 0) throw new RangeError("Nieprawidłowa liczba punktów bazowych.");
  if (!Number.isInteger(difficulty) || difficulty < 1 || difficulty > 5) throw new RangeError("Nieprawidłowa trudność.");
  if (!Number.isInteger(currentStreak) || currentStreak < 0) throw new RangeError("Nieprawidłowa seria odpowiedzi.");
  if (!Number.isInteger(extraPenalty) || extraPenalty < 0) throw new RangeError("Nieprawidłowa dodatkowa kara.");
  if (!Number.isFinite(hintPenaltyRate) || hintPenaltyRate < 0 || hintPenaltyRate > 0.8) throw new RangeError("Nieprawidłowa kara za podpowiedzi.");
  if (!Number.isFinite(repeatMultiplier) || repeatMultiplier <= 0 || repeatMultiplier > 1) throw new RangeError("Nieprawidłowy mnożnik powtórki.");

  if (!correct) {
    return {
      total: 0,
      basePoints: 0,
      difficultyBonus: 0,
      streakBonus: 0,
      hintPenalty: 0,
      revealPenalty: 0,
      repeatPenalty: 0,
      repeatMultiplier,
      nextStreak: 0
    };
  }

  const nextStreak = currentStreak + 1;
  const awardedBase = Math.max(1, Math.round(basePoints * BASE_SCORE_RATE));
  const adjustedBase = Math.round(awardedBase * (1 + (difficulty - 1) * DIFFICULTY_STEP));
  const difficultyBonus = adjustedBase - awardedBase;
  const streakBonus = Math.min(Math.max(nextStreak - 1, 0) * STREAK_BONUS_STEP, MAX_STREAK_BONUS);
  const subtotal = adjustedBase + streakBonus;
  const effectiveHintRate = hintPenaltyRate || (hintUsed ? 0.25 : 0);
  const hintPenalty = Math.round(subtotal * Math.min(effectiveHintRate, 0.45));
  const revealPenalty = Math.min(extraPenalty, subtotal - hintPenalty);
  const beforeRepeat = subtotal - hintPenalty - revealPenalty;
  const afterRepeat = Math.max(1, Math.round(beforeRepeat * repeatMultiplier));
  const repeatPenalty = beforeRepeat - afterRepeat;

  return {
    total: afterRepeat,
    basePoints: awardedBase,
    difficultyBonus,
    streakBonus,
    hintPenalty,
    revealPenalty,
    repeatPenalty,
    repeatMultiplier,
    nextStreak
  };
}
