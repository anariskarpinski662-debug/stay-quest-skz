import { getQuizQuestions } from "./question-bank.js";
import { TIMELINE_EVENTS } from "./timeline-events.js";
import { QUESTION_TYPES } from "../game/question-schema.js";
import { createSeededRandom, sampleWithoutReplacement } from "../game/random.js";

function hashText(text) {
  let hash = 2166136261;
  for (const character of String(text)) {
    hash ^= character.codePointAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function optionId(label) {
  return String(label)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function getLocalDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function cloneForDaily(question, dateKey, index) {
  return {
    ...structuredClone(question),
    id: `daily-${dateKey}-${index + 1}-${question.id}`,
    modeId: "daily-challenge",
    category: `${question.category} • Daily`
  };
}

function createTimelineQuestion(dateKey, random) {
  const choices = sampleWithoutReplacement(TIMELINE_EVENTS, 4, random).sort((a, b) => a.date.localeCompare(b.date));
  const answer = choices[0];
  return {
    id: `daily-${dateKey}-timeline`,
    modeId: "daily-challenge",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Które z tych wydarzeń nastąpiło najwcześniej?",
    category: "Oś czasu • Daily",
    kind: "official_fact",
    difficulty: 3,
    basePoints: 140,
    options: choices.map(({ title }) => ({ id: optionId(title), label: title })),
    correctOptionId: optionId(answer.title),
    explanation: `${answer.title} miało miejsce ${answer.date} i jest najwcześniejszym wydarzeniem w tym zestawie.`,
    source: answer.source
  };
}

export function createDailyQuestions(dateKey = getLocalDateKey()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) throw new TypeError("Nieprawidłowa data Daily Challenge.");
  const random = createSeededRandom(hashText(`stay-quest-daily-${dateKey}`));
  const selected = [
    ...sampleWithoutReplacement(getQuizQuestions("assoc-master"), 2, random),
    ...sampleWithoutReplacement(getQuizQuestions("emoji-guesser"), 2, random),
    ...sampleWithoutReplacement(getQuizQuestions("hardcore-lore"), 2, random),
    ...sampleWithoutReplacement(getQuizQuestions("who-is-who"), 1, random),
    ...sampleWithoutReplacement(getQuizQuestions("discography-builder"), 2, random)
  ].map((question, index) => cloneForDaily(question, dateKey, index));

  selected.splice(5, 0, createTimelineQuestion(dateKey, random));
  return selected;
}

export function createDailyRandom(dateKey = getLocalDateKey()) {
  return createSeededRandom(hashText(`stay-quest-daily-order-${dateKey}`));
}
