import { QUESTION_TYPES } from "../game/question-schema.js";
import { DISCOGRAPHY_QUESTIONS, WHO_IS_WHO_QUESTIONS } from "./extended-question-bank.js";
import { QUALITY_ASSOCIATION_QUESTIONS, QUALITY_LORE_QUESTIONS } from "./quality-question-bank.js";

const CHECKED_AT = "2026-08-19";

export const CONTENT_SOURCES = Object.freeze({
  profile: {
    title: "JYP Entertainment — oficjalny profil Stray Kids",
    url: "https://straykids.jype.com/Default/Profile?Idx=6",
    checkedAt: CHECKED_AT
  },
  earlyDiscography: {
    title: "JYP Entertainment — dyskografia Stray Kids (2018)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=10",
    checkedAt: CHECKED_AT
  },
  discography2019: {
    title: "JYP Entertainment — dyskografia Stray Kids (2018–2019)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=9",
    checkedAt: CHECKED_AT
  },
  discography2020: {
    title: "JYP Entertainment — dyskografia Stray Kids (2020–2021)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=7",
    checkedAt: CHECKED_AT
  },
  discography2022: {
    title: "JYP Entertainment — dyskografia Stray Kids (2021–2022)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=6",
    checkedAt: CHECKED_AT
  },
  discography2024: {
    title: "JYP Entertainment — dyskografia Stray Kids (2023–2024)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=5",
    checkedAt: CHECKED_AT
  },
  discography2025: {
    title: "JYP Entertainment — dyskografia Stray Kids (2024–2025)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=3",
    checkedAt: CHECKED_AT
  },
  discography2026: {
    title: "JYP Entertainment — dyskografia Stray Kids (2025–2026)",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=2",
    checkedAt: CHECKED_AT
  },
  currentDiscography: {
    title: "JYP Entertainment — bieżąca dyskografia Stray Kids",
    url: "https://straykids.jype.com/Default/DiscographyList?PgIndex=1",
    checkedAt: CHECKED_AT
  },
  thisAndThat: {
    title: "JYP Entertainment — oficjalny opis albumu THIS & THAT",
    url: "https://straykids.jype.com/Mobile/DiscographyView?AamSeq=282&AmSeq=0&PgIndex=1",
    checkedAt: CHECKED_AT
  },
  kingdom: {
    title: "Soompi — finał Kingdom: Legendary War",
    url: "https://www.soompi.com/article/1472842wpp/watch-kingdom-crowns-its-final-winner-after-thrilling-performances-of-groups-new-songs",
    checkedAt: CHECKED_AT
  },
  billboard: {
    title: "Billboard — ATE na Billboard 200",
    url: "https://ca.billboard.com/music/chart-beat/stray-kids-jimin-debut-billboard-200-chart-k-pop-top-two-albums-first-time-1235741972/",
    checkedAt: CHECKED_AT
  }
});

function optionId(label) {
  return String(label)
    .normalize("NFKD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function makeOptions(answer, alternatives) {
  return [answer, ...alternatives].map((label) => ({ id: optionId(label), label }));
}

const EMOJI_DISTRACTORS = Object.freeze({
  "God's Menu": ["Super Bowl", "CHEESE", "TASTE"],
  "Back Door": ["District 9", "Side Effects", "Levanter"],
  MIROH: ["District 9", "MOUNTAINS", "Social Path"],
  Thunderous: ["MEGAVERSE", "LALALALA", "Chk Chk Boom"],
  CHEESE: ["TASTE", "JJAM", "Super Bowl"],
  "Christmas EveL": ["Winter Falls", "24 to 25", "FREEZE"],
  VENOM: ["Red Lights", "Charmer", "MANIAC"],
  DOMINO: ["Collision", "Side Effects", "ITEM"],
  Charmer: ["VENOM", "Red Lights", "TASTE"],
  FREEZE: ["Winter Falls", "Christmas EveL", "Levanter"],
  "Red Lights": ["Collision", "VENOM", "Drive"],
  "CASE 143": ["Collision", "I Do", "Secret Secret"],
  "S-Class": ["Hall of Fame", "Super Bowl", "TOP"],
  "Chk Chk Boom": ["Thunderous", "DOMINO", "LALALALA"],
  LALALALA: ["Thunderous", "MEGAVERSE", "Hall of Fame"],
  MOUNTAINS: ["TOP", "MIROH", "Levanter"],
  MEGAVERSE: ["Hall of Fame", "TOP", "Social Path"],
  "Social Path": ["Lonely St.", "THE SOUND", "TOP"],
  "Hall of Fame": ["S-Class", "TOP", "MEGAVERSE"],
  "Super Bowl": ["God's Menu", "CHEESE", "TASTE"],
  TASTE: ["CHEESE", "Red Lights", "Drive"],
  Collision: ["CASE 143", "I Do", "Sorry, I Love You"],
  "This & That": ["I Do", "Any", "Another Day"],
  "RUN IT": ["MIROH", "TOP", "Boxer"],
  FARMING: ["DOMINO", "ITEM", "Charmer"],
  "After You": ["Cover Me", "Secret Secret", "Another Day"],
  MANIAC: ["Side Effects", "VENOM", "Charmer"],
  "Side Effects": ["MANIAC", "Levanter", "Collision"],
  "District 9": ["MIROH", "Back Door", "Social Path"],
  Levanter: ["Winter Falls", "Cover Me", "Secret Secret"],
  "Lonely St.": ["Social Path", "Way Out", "Streetlight"],
  "Cover Me": ["Secret Secret", "After You", "Levanter"],
  "Secret Secret": ["Cover Me", "Another Day", "Collision"],
  JJAM: ["CHEESE", "FARMING", "DOMINO"],
  "Walkin On Water": ["MOUNTAINS", "TOP", "Social Path"],
  CEREMONY: ["Hall of Fame", "S-Class", "LALALALA"],
  "I Do": ["CASE 143", "Collision", "After You"],
  "Way Out": ["Levanter", "Lonely St.", "Social Path"],
  "Back Than": ["After You", "Another Day", "Secret Secret"]
});

function association({ id, answer, alternatives, clues, difficulty, hint, explanation }) {
  return {
    id: `assoc-${id}`,
    modeId: "assoc-master",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Który utwór łączy wszystkie te tropy?",
    category: "Mistrz Skojarzeń",
    kind: "puzzle_interpretation",
    difficulty,
    basePoints: 150,
    clues,
    cluePolicy: { initialVisible: 2, penaltyPerReveal: 10 },
    options: makeOptions(answer, alternatives),
    correctOptionId: optionId(answer),
    hint,
    explanation
  };
}

function memberAssociation({ id, answer, alternatives, clues, difficulty, hint, explanation }) {
  return {
    id: `assoc-member-${id}`,
    modeId: "assoc-master",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Którego członka łączy ten zestaw tropów?",
    category: "Członkowie i SKZOO",
    kind: "puzzle_interpretation",
    difficulty,
    basePoints: 150,
    clues,
    cluePolicy: { initialVisible: 2, penaltyPerReveal: 10 },
    options: makeOptions(answer, alternatives),
    correctOptionId: optionId(answer),
    hint,
    explanation,
    source: CONTENT_SOURCES.profile
  };
}

function emoji({ id, answer, symbols, difficulty, hint, explanation, alternatives = EMOJI_DISTRACTORS[answer] }) {
  if (!Array.isArray(alternatives) || alternatives.length !== 3) {
    throw new TypeError(`Zagadka Emoji „${answer}” wymaga trzech prawdziwych tytułów jako odpowiedzi mylących.`);
  }
  return {
    id: `emoji-${id}`,
    topicId: `song-${optionId(answer)}`,
    modeId: "emoji-guesser",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Który utwór najlepiej pasuje do tego zestawu emoji?",
    category: "Emoji i symbole",
    kind: "puzzle_interpretation",
    difficulty,
    basePoints: 100,
    clues: symbols,
    options: makeOptions(answer, alternatives),
    correctOptionId: optionId(answer),
    hints: [
      { text: hint, penaltyRate: 0.12 },
      { text: `Zawęź wybór do tytułów, których oficjalny zapis i motyw pasują do całego zestawu emoji.`, penaltyRate: 0.2 }
    ],
    explanation
  };
}

function lore({ id, prompt, answer, alternatives, difficulty, explanation, source, kind = "official_fact" }) {
  return {
    id: `lore-${id}`,
    modeId: "hardcore-lore",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt,
    category: "Hardcore Lore",
    kind,
    difficulty: Math.max(3, difficulty),
    basePoints: 200,
    options: makeOptions(answer, alternatives),
    correctOptionId: optionId(answer),
    explanation,
    source
  };
}

const ASSOCIATION_QUESTIONS = [
  association({
    id: "gods-menu",
    answer: "God's Menu",
    alternatives: ["Back Door", "CHEESE", "Super Bowl"],
    clues: ["kuchnia", "szef", "pięć gwiazdek", "Michelin"],
    difficulty: 1,
    hint: "Tytuł brzmi jak pozycja przygotowana przez niezwykłego szefa kuchni.",
    explanation: "Kuchnia, szef i pięć gwiazdek prowadzą do God's Menu. To autorska zagadka skojarzeniowa."
  }),
  association({
    id: "back-door",
    answer: "Back Door",
    alternatives: ["District 9", "Side Effects", "Levanter"],
    clues: ["pukanie", "zaproszenie", "ukryte wejście", "za mną"],
    difficulty: 1,
    hint: "Nie chodzi o główne wejście.",
    explanation: "Pukanie, zaproszenie i ukryte wejście składają się na tytuł Back Door."
  }),
  association({
    id: "miroh",
    answer: "MIROH",
    alternatives: ["TOP", "MOUNTAINS", "Hall of Fame"],
    clues: ["miejski labirynt", "dżungla", "wspinanie", "zwycięski okrzyk"],
    difficulty: 2,
    hint: "Tytuł przypomina koreańskie słowo oznaczające labirynt.",
    explanation: "Labirynt i miejska dżungla są głównym skojarzeniem prowadzącym do MIROH."
  }),
  association({
    id: "thunderous",
    answer: "Thunderous",
    alternatives: ["DOMINO", "FREEZE", "Collision"],
    clues: ["huk", "głośna odpowiedź", "tradycyjne motywy", "burza"],
    difficulty: 2,
    hint: "Pomyśl o kimś, kto robi dużo hałasu i za to nie przeprasza.",
    explanation: "Huk, burza i głośna odpowiedź wskazują na Thunderous."
  }),
  association({
    id: "jjam",
    answer: "JJAM",
    alternatives: ["CHEESE", "TASTE", "Super Bowl"],
    clues: ["słoik", "lepkość", "czerwony kolor", "podwójna litera"],
    difficulty: 3,
    hint: "Zwykłe angielskie słowo dostało na początku dodatkową literę.",
    explanation: "Słoik, lepkość i podwójne J prowadzą do zapisu JJAM."
  }),
  association({
    id: "s-class",
    answer: "S-Class",
    alternatives: ["Hall of Fame", "TOP", "MEGAVERSE"],
    clues: ["wyjątkowa klasa", "gwiazda", "luksusowy poziom", "nietypowy bohater"],
    difficulty: 2,
    hint: "Pierwszy znak tytułu jest pojedynczą literą.",
    explanation: "Klasa premium i wyjątkowość tworzą autorski zestaw tropów do S-Class."
  }),
  association({
    id: "maniac",
    answer: "MANIAC",
    alternatives: ["VENOM", "Side Effects", "Charmer"],
    clues: ["poluzowana śruba", "dziwactwo", "maska normalności", "obrót głowy"],
    difficulty: 2,
    hint: "Tytuł opisuje osobę, która nie zamierza udawać idealnie normalnej.",
    explanation: "Śruba i odrzucenie maski normalności kojarzą się z MANIAC."
  }),
  association({
    id: "case-143",
    answer: "CASE 143",
    alternatives: ["Collision", "Sorry, I Love You", "Red Lights"],
    clues: ["akta sprawy", "kod liczbowy", "serce", "miłosne śledztwo"],
    difficulty: 2,
    hint: "Liczby w tytule są kodem kojarzonym z wyznaniem miłości.",
    explanation: "Sprawa, liczby 1-4-3 i motyw serca prowadzą do CASE 143."
  }),
  association({
    id: "chk-chk-boom",
    answer: "Chk Chk Boom",
    alternatives: ["TA", "DOMINO", "Boxer"],
    clues: ["dwa sprawdzenia", "eksplozja", "pewny cel", "latynoski żar"],
    difficulty: 2,
    hint: "Tytuł brzmi jak krótka sekwencja tuż przed wybuchem.",
    explanation: "Dwa rytmiczne „chk” i eksplozja dosłownie składają tytuł Chk Chk Boom."
  }),
  association({
    id: "christmas-evel",
    answer: "Christmas EveL",
    alternatives: ["Winter Falls", "24 to 25", "Christmas Love"],
    clues: ["śnieżna noc", "świąteczna dostawa", "złośliwy nastrój", "gra ostatnią literą"],
    difficulty: 2,
    hint: "To przewrotna wersja wyrażenia Christmas Eve.",
    explanation: "Świąteczna noc połączona ze słowem „evil” prowadzi do zapisu Christmas EveL."
  }),
  association({
    id: "venom",
    answer: "VENOM",
    alternatives: ["Charmer", "MANIAC", "Super Board"],
    clues: ["pajęczyna", "pułapka", "ukąszenie", "trucizna"],
    difficulty: 1,
    hint: "Szukanym słowem jest jad.",
    explanation: "Pajęczyna, ukąszenie i trucizna wskazują na VENOM."
  }),
  association({
    id: "cheese",
    answer: "CHEESE",
    alternatives: ["God's Menu", "Super Bowl", "TASTE"],
    clues: ["aparat", "uśmiech", "żółty przysmak", "prowokacyjna mina"],
    difficulty: 1,
    hint: "To słowo wypowiada się po angielsku przed zdjęciem.",
    explanation: "Aparat, uśmiech i ser prowadzą bezpośrednio do CHEESE."
  }),
  association({
    id: "domino",
    answer: "DOMINO",
    alternatives: ["TA", "Boxer", "ITEM"],
    clues: ["jeden ruch", "przewracające się płytki", "reakcja łańcuchowa", "nie do zatrzymania"],
    difficulty: 1,
    hint: "Wystarczy popchnąć pierwszy element.",
    explanation: "Przewracające się kolejno płytki i reakcja łańcuchowa oznaczają DOMINO."
  }),
  association({
    id: "charmer",
    answer: "Charmer",
    alternatives: ["VENOM", "TASTE", "Red Lights"],
    clues: ["flet", "wąż", "hipnoza", "nieodparty urok"],
    difficulty: 2,
    hint: "Tytuł opisuje kogoś, kto potrafi wszystkich oczarować.",
    explanation: "Flet, wąż i hipnotyczny urok kojarzą się z Charmer."
  }),
  association({
    id: "freeze",
    answer: "FREEZE",
    alternatives: ["Winter Falls", "CHILL", "Scars"],
    clues: ["lód", "zatrzymanie", "pękające ograniczenia", "zimny rozkaz"],
    difficulty: 2,
    hint: "Tytuł jest angielskim rozkazem, by znieruchomieć.",
    explanation: "Lód i komenda zatrzymania prowadzą do tytułu FREEZE."
  }),
  association({
    id: "red-lights",
    answer: "Red Lights",
    alternatives: ["TASTE", "Drive", "Collision"],
    clues: ["czerwony sygnał", "łańcuch", "zakaz ruchu", "niebezpieczne przyciąganie"],
    difficulty: 2,
    hint: "Pierwszy trop określa kolor, drugi element drogowej sygnalizacji.",
    explanation: "Czerwony sygnał i zatrzymanie składają się na Red Lights."
  }),
  association({
    id: "megaverse",
    answer: "MEGAVERSE",
    alternatives: ["S-Class", "Hall of Fame", "LALALALA"],
    clues: ["wielki wszechświat", "wiele wymiarów", "filmowy rozmach", "potężne wejście"],
    difficulty: 2,
    hint: "Tytuł łączy coś ogromnego ze słowem „verse”.",
    explanation: "Ogromny, wielowymiarowy świat jest autorskim skrótem do MEGAVERSE."
  }),
  association({
    id: "lalalala",
    answer: "LALALALA",
    alternatives: ["MEGAVERSE", "COMFLEX", "Blind Spot"],
    clues: ["śpiewna sylaba", "rockowa energia", "świętowanie", "muzyka mimo chaosu"],
    difficulty: 2,
    hint: "Tytuł jest zbudowany wyłącznie z powtarzanej sylaby.",
    explanation: "Powtarzane „la” i rockowa energia prowadzą do LALALALA."
  }),
  association({
    id: "mountains",
    answer: "MOUNTAINS",
    alternatives: ["TOP", "Hall of Fame", "Victory Song"],
    clues: ["szczyty", "wspinaczka", "wysokość", "pokonywanie przeszkód"],
    difficulty: 1,
    hint: "Tytuł jest liczbą mnogą od angielskiego słowa „góra”.",
    explanation: "Szczyty i wspinaczka bezpośrednio wskazują na MOUNTAINS."
  }),
  association({
    id: "this-and-that",
    answer: "This & That",
    alternatives: ["I Do", "Way Out", "Back Then"],
    clues: ["dwa wybory", "paczka", "ciężarówka", "to i tamto"],
    difficulty: 1,
    hint: "Tytuł zestawia dwa angielskie zaimki wskazujące.",
    explanation: "Dwa wybory, paczka i dosłowne „to i tamto” prowadzą do This & That."
  }),
  association({
    id: "run-it",
    answer: "RUN IT",
    alternatives: ["TOP", "Super Board", "TA"],
    clues: ["linia startu", "pęd", "mosiężne brzmienie", "hymniczna energia"],
    difficulty: 2,
    hint: "Tytuł zaczyna się od angielskiego czasownika „biec”.",
    explanation: "Start, pęd i hymniczna energia tworzą tropy prowadzące do RUN IT."
  }),
  association({
    id: "farming",
    answer: "FARMING",
    alternatives: ["ITEM", "DLC", "DOMINO"],
    clues: ["gra", "zbieranie zasobów", "rozwój postaci", "żniwa"],
    difficulty: 2,
    hint: "Nie chodzi tylko o prawdziwe pole — także o powtarzanie zadań w grze.",
    explanation: "Zasoby, rozwój i żniwa odnoszą się do gamingowego pojęcia FARMING."
  }),
  association({
    id: "after-you",
    answer: "After You",
    alternatives: ["I Do", "Way Out", "Sorry, I Love You"],
    clues: ["miłość od pierwszego spojrzenia", "nostalgiczna gitara", "narastające emocje", "energetyczny drop"],
    difficulty: 3,
    hint: "Tytuł opisuje wszystko, co wydarzyło się „po Tobie”.",
    explanation: "Pierwsze zauroczenie, nostalgiczna gitara i energetyczny drop wskazują na After You."
  }),
  association({
    id: "way-out",
    answer: "Way Out",
    alternatives: ["Levanter", "Ex", "Leave"],
    clues: ["wyjście", "spokojne rozstanie", "akustyczny klimat", "droga na zewnątrz"],
    difficulty: 3,
    hint: "Szukasz angielskiego określenia drogi wyjścia.",
    explanation: "Droga wyjścia i spokojna emocja rozstania prowadzą do Way Out."
  }),
  association({
    id: "after-you-master",
    answer: "After You",
    alternatives: ["Cover Me", "Secret Secret", "Another Day"],
    clues: ["nostalgiczny riff", "energetyczny drop", "jedno spojrzenie", "to, co nastąpiło później"],
    difficulty: 4,
    hint: "Tytuł łączy następstwo czasu z drugą osobą.",
    explanation: "Dopiero połączenie nostalgicznego riffu, dropu i następstwa prowadzi do After You."
  }),
  association({
    id: "way-out-master",
    answer: "Way Out",
    alternatives: ["Leave", "Levanter", "Lonely St."],
    clues: ["powściągliwa emocja", "akustyczny hip-hop", "koniec relacji", "kierunek poza obecne miejsce"],
    difficulty: 4,
    hint: "Nie szukaj tylko emocji — ważny jest też kierunek.",
    explanation: "Gatunek, rozstanie i kierunek wyjścia składają się na Way Out."
  }),
  association({
    id: "farming-master",
    answer: "FARMING",
    alternatives: ["ITEM", "DLC", "Super Board"],
    clues: ["powtarzalny grind", "rosnące zasoby", "zbiór", "gamingowy żart"],
    difficulty: 4,
    hint: "To słowo działa zarówno na polu, jak i w grze.",
    explanation: "Grind, zasoby i podwójne znaczenie zbioru prowadzą do FARMING."
  }),
  association({
    id: "this-and-that-master",
    answer: "This & That",
    alternatives: ["Any", "Give Me Your TMI", "Question"],
    clues: ["dwa przeciwne wskazania", "ładunek w drodze", "tytułowy duet słów", "osobna wersja festiwalowa"],
    difficulty: 5,
    hint: "Dwa krótkie angielskie słowa łączy znak &.",
    explanation: "Wskazania, motyw dostawy i wersja festiwalowa razem identyfikują This & That."
  }),
  association({
    id: "back-than-master",
    answer: "Back Than",
    alternatives: ["Another Day", "After You", "Way Out"],
    clues: ["retrospekcja", "dawny moment", "cofnięcie myśli", "czas zamiast miejsca"],
    difficulty: 5,
    hint: "Pierwsze słowo kieruje wstecz, drugie dotyczy dawnego czasu.",
    explanation: "Retrospekcja i cofnięcie do dawnego momentu prowadzą do Back Than."
  }),
  association({
    id: "i-do-master",
    answer: "I Do",
    alternatives: ["CASE 143", "Collision", "Sorry, I Love You"],
    clues: ["krótka deklaracja", "zgoda bez tłumaczenia", "ważna obietnica", "dwa słowa"],
    difficulty: 4,
    hint: "To odpowiedź, którą można złożyć podczas ważnej obietnicy.",
    explanation: "Deklaracja zgody i obietnica prowadzą do dwuwyrazowego I Do."
  }),
  association({
    id: "run-it-master",
    answer: "RUN IT",
    alternatives: ["TOP", "TA", "Victory Song"],
    clues: ["blaszane brzmienie", "hymniczny rozmach", "ruch bez postoju", "krótki imperatyw"],
    difficulty: 5,
    hint: "Tytuł jest dwuwyrazowym poleceniem związanym z ruchem.",
    explanation: "Brassowe brzmienie, pęd i forma polecenia prowadzą do RUN IT."
  }),
  association({
    id: "secret-secret-insane",
    answer: "Secret Secret",
    alternatives: ["Cover Me", "Silent Cry", "Another Day"],
    clues: ["to, czego nie wypowiadasz", "deszczowy ciężar", "zamknięcie w sobie", "powtórzone słowo"],
    difficulty: 5,
    hint: "Tytuł powtarza jedno angielskie słowo.",
    explanation: "Niewypowiedziane emocje, deszcz i powtórzenie słowa prowadzą do Secret Secret."
  })
];

const MEMBER_ASSOCIATION_QUESTIONS = [
  memberAssociation({ id: "bang-chan", answer: "Bang Chan", alternatives: ["Lee Know", "Changbin", "I.N"], clues: ["🐺", "3 października", "1997", "Wolf Chan"], difficulty: 1, hint: "Najstarszy członek i wilczy SKZOO.", explanation: "Wilk, data 3 października 1997 i Wolf Chan prowadzą do Bang Chana." }),
  memberAssociation({ id: "lee-know", answer: "Lee Know", alternatives: ["Bang Chan", "Hyunjin", "Seungmin"], clues: ["🐰", "25 października", "1998", "Leebit"], difficulty: 1, hint: "Jego SKZOO jest królikiem.", explanation: "Królik, data 25 października 1998 i Leebit prowadzą do Lee Know." }),
  memberAssociation({ id: "changbin", answer: "Changbin", alternatives: ["Bang Chan", "Han", "Felix"], clues: ["🐷 + 🐰", "11 sierpnia", "1999", "DWAEKKI"], difficulty: 1, hint: "Nazwa SKZOO łączy świnkę i królika.", explanation: "Połączenie świnki z królikiem, data 11 sierpnia 1999 i DWAEKKI prowadzą do Changbina." }),
  memberAssociation({ id: "hyunjin", answer: "Hyunjin", alternatives: ["Lee Know", "Han", "I.N"], clues: ["🦙", "20 marca", "2000", "Jiniret"], difficulty: 1, hint: "Szukaj alpakowego SKZOO.", explanation: "Alpaka, data 20 marca 2000 i Jiniret prowadzą do Hyunjina." }),
  memberAssociation({ id: "han", answer: "Han", alternatives: ["Changbin", "Felix", "Seungmin"], clues: ["🐿️", "14 września", "2000", "HAN QUOKKA"], difficulty: 1, hint: "Nazwa SKZOO zawiera jego pseudonim bez zmian.", explanation: "Quokka, data 14 września 2000 i HAN QUOKKA prowadzą do Hana." }),
  memberAssociation({ id: "felix", answer: "Felix", alternatives: ["Hyunjin", "Han", "Seungmin"], clues: ["🐥", "15 września", "2000", "BbokAri"], difficulty: 1, hint: "Żółty kurczaczek i urodziny dzień po Hanie.", explanation: "Kurczaczek, data 15 września 2000 i BbokAri prowadzą do Felixa." }),
  memberAssociation({ id: "seungmin", answer: "Seungmin", alternatives: ["Lee Know", "Felix", "I.N"], clues: ["🐶", "22 września", "2000", "PuppyM"], difficulty: 1, hint: "Jego SKZOO jest pieskiem.", explanation: "Piesek, data 22 września 2000 i PuppyM prowadzą do Seungmina." }),
  memberAssociation({ id: "i-n", answer: "I.N", alternatives: ["Bang Chan", "Hyunjin", "Seungmin"], clues: ["🦊", "8 lutego", "2001", "FoxI.Ny"], difficulty: 1, hint: "Najmłodsza data na oficjalnym profilu i lisie SKZOO.", explanation: "Lis, data 8 lutego 2001 i FoxI.Ny prowadzą do I.N." })
];

const EMOJI_QUESTIONS = [
  emoji({ id: "gods-menu", answer: "God's Menu", acceptedAnswers: ["God's Menu", "Gods Menu"], symbols: ["🍳", "👨‍🍳", "⭐⭐⭐⭐⭐"], difficulty: 1, hint: "Kucharz podaje niezwykłe menu.", explanation: "Patelnia, kucharz i pięć gwiazdek tworzą autorski zapis God's Menu." }),
  emoji({ id: "back-door", answer: "Back Door", symbols: ["↩️", "🚪"], difficulty: 1, hint: "Pierwszy znak oznacza tył lub powrót.", explanation: "Strzałka wstecz i drzwi składają się na Back Door." }),
  emoji({ id: "miroh", answer: "MIROH", symbols: ["🏙️", "🌀", "🌿"], difficulty: 2, hint: "Miejska dżungla przypomina labirynt.", explanation: "Miasto, wir-labirynt i dżungla prowadzą do MIROH." }),
  emoji({ id: "thunderous", answer: "Thunderous", symbols: ["⚡", "📣", "🌩️"], difficulty: 1, hint: "Wszystkie symbole kojarzą się z hałasem.", explanation: "Błyskawica, głośnik i burza oznaczają Thunderous." }),
  emoji({ id: "cheese", answer: "CHEESE", acceptedAnswers: ["CHEESE", "Cheese"], symbols: ["🧀", "📸", "😁"], difficulty: 1, hint: "Co mówi się po angielsku przed zdjęciem?", explanation: "Ser, aparat i uśmiech prowadzą do CHEESE." }),
  emoji({ id: "christmas-evel", answer: "Christmas EveL", acceptedAnswers: ["Christmas EveL", "Christmas Evel", "Christmas Eve L"], symbols: ["🎄", "🌙", "😈"], difficulty: 2, hint: "Świąteczna noc spotyka słowo „evil”.", explanation: "Choinka, noc i diabeł oddają grę słów Christmas EveL." }),
  emoji({ id: "venom", answer: "VENOM", acceptedAnswers: ["VENOM", "Venom"], symbols: ["🕷️", "🕸️", "☠️"], difficulty: 1, hint: "Pomyśl o jadzie po ukąszeniu.", explanation: "Pająk, sieć i zagrożenie wskazują na VENOM." }),
  emoji({ id: "domino", answer: "DOMINO", acceptedAnswers: ["DOMINO", "Domino"], symbols: ["🁣", "➡️", "🁣", "🁣"], difficulty: 1, hint: "Jeden element przewraca następne.", explanation: "Łańcuch przewracających się płytek to DOMINO." }),
  emoji({ id: "charmer", answer: "Charmer", symbols: ["🐍", "🪈", "✨"], difficulty: 2, hint: "Flet może oczarować węża.", explanation: "Wąż, flet i czar oznaczają Charmer." }),
  emoji({ id: "freeze", answer: "FREEZE", acceptedAnswers: ["FREEZE", "Freeze"], symbols: ["🧊", "✋", "⏸️"], difficulty: 1, hint: "Zatrzymaj się i zamarznij.", explanation: "Lód, zatrzymanie i pauza tworzą FREEZE." }),
  emoji({ id: "red-lights", answer: "Red Lights", symbols: ["🔴", "🚦", "⛓️"], difficulty: 2, hint: "Kolor i sygnalizacja są dosłowne.", explanation: "Czerwony sygnał świetlny prowadzi do Red Lights." }),
  emoji({ id: "case-143", answer: "CASE 143", acceptedAnswers: ["CASE 143", "Case 143", "Case143"], symbols: ["🗂️", "1️⃣", "4️⃣", "3️⃣", "❤️"], difficulty: 2, hint: "To sprawa o kodzie 1-4-3.", explanation: "Akta, liczby i serce składają się na CASE 143." }),
  emoji({ id: "s-class", answer: "S-Class", acceptedAnswers: ["S-Class", "S Class", "Sclass"], symbols: ["🇸", "🎓", "⭐"], difficulty: 2, hint: "Pierwszy znak jest literą, drugi sugeruje klasę.", explanation: "Litera S, klasa i gwiazda tworzą S-Class." }),
  emoji({ id: "chk-chk-boom", answer: "Chk Chk Boom", acceptedAnswers: ["Chk Chk Boom", "CHK CHK BOOM", "ChkChkBoom"], symbols: ["✅", "✅", "💥"], difficulty: 1, hint: "Przeczytaj symbole rytmicznie po angielsku.", explanation: "Dwa „check” i wybuch odtwarzają Chk Chk Boom." }),
  emoji({ id: "lalalala", answer: "LALALALA", acceptedAnswers: ["LALALALA", "Lalalala"], symbols: ["🎵", "🎤", "🎸", "🔥"], difficulty: 2, hint: "Tytuł jest śpiewaną sylabą powtórzoną kilka razy.", explanation: "Muzyka, wokal i rockowa energia prowadzą do LALALALA." }),
  emoji({ id: "mountains", answer: "MOUNTAINS", acceptedAnswers: ["MOUNTAINS", "Mountains"], symbols: ["⛰️", "🧗", "⬆️"], difficulty: 1, hint: "Angielska liczba mnoga od „góra”.", explanation: "Góry, wspinaczka i ruch w górę oznaczają MOUNTAINS." }),
  emoji({ id: "megaverse", answer: "MEGAVERSE", acceptedAnswers: ["MEGAVERSE", "Megaverse"], symbols: ["🌌", "♾️", "🔊"], difficulty: 2, hint: "Ogromny świat lub wszechświat.", explanation: "Kosmos, nieskończoność i potężny dźwięk oznaczają MEGAVERSE." }),
  emoji({ id: "social-path", answer: "Social Path", symbols: ["👥", "🛣️", "🚶"], difficulty: 2, hint: "Grupa ludzi plus droga.", explanation: "Ludzie i ścieżka tworzą dosłowny zapis Social Path." }),
  emoji({ id: "hall-of-fame", answer: "Hall of Fame", symbols: ["🏛️", "🏆", "⭐"], difficulty: 1, hint: "Miejsce dla najbardziej zasłużonych.", explanation: "Uroczysta sala, trofeum i gwiazda prowadzą do Hall of Fame." }),
  emoji({ id: "super-bowl", answer: "Super Bowl", symbols: ["🦸", "🥣", "🏆"], difficulty: 2, hint: "Pierwsze dwa symbole przeczytaj dosłownie.", explanation: "Superbohater i miska tworzą grę słowną Super Bowl." }),
  emoji({ id: "taste", answer: "TASTE", acceptedAnswers: ["TASTE", "Taste"], symbols: ["👅", "🍽️", "✨"], difficulty: 1, hint: "Zmysł związany z językiem.", explanation: "Język i posiłek oznaczają TASTE." }),
  emoji({ id: "collision", answer: "Collision", symbols: ["🚗", "💥", "❤️"], difficulty: 2, hint: "Dwa obiekty zderzają się.", explanation: "Zderzenie i emocjonalne serce prowadzą do Collision." }),
  emoji({ id: "this-and-that", answer: "This & That", acceptedAnswers: ["This & That", "This and That", "This That"], symbols: ["👈", "📦", "👉"], difficulty: 1, hint: "To po jednej stronie i tamto po drugiej.", explanation: "Dwa wskazania i paczka odtwarzają ideę This & That." }),
  emoji({ id: "run-it", answer: "RUN IT", acceptedAnswers: ["RUN IT", "Run It"], symbols: ["🏃", "🏁", "🔥"], difficulty: 1, hint: "Bieg do mety.", explanation: "Biegacz, meta i ogień prowadzą do RUN IT." }),
  emoji({ id: "farming", answer: "FARMING", acceptedAnswers: ["FARMING", "Farming"], symbols: ["🎮", "🌾", "📈"], difficulty: 2, hint: "W grach oznacza powtarzalne zdobywanie zasobów.", explanation: "Gra, plony i rozwój postaci symbolizują FARMING." }),
  emoji({ id: "after-you", answer: "After You", symbols: ["👤", "➡️", "❤️", "🌅"], difficulty: 3, hint: "Wszystko zmieniło się po spotkaniu drugiej osoby.", explanation: "Osoba, następstwo i uczucie prowadzą do After You." }),
  emoji({ id: "maniac", answer: "MANIAC", symbols: ["🧠", "🔩", "😵‍💫"], difficulty: 3, hint: "Kontrolowany chaos w głowie.", explanation: "Mózg, poluzowana śruba i zawrót głowy prowadzą do MANIAC." }),
  emoji({ id: "side-effects", answer: "Side Effects", symbols: ["💊", "⚠️", "🌀"], difficulty: 3, hint: "Ostrzeżenie znane z ulotki leku.", explanation: "Lek, ostrzeżenie i niepokój obrazują Side Effects." }),
  emoji({ id: "district-9", answer: "District 9", symbols: ["🏙️", "9️⃣", "🚧"], difficulty: 2, hint: "Wydzielona część miasta oznaczona numerem.", explanation: "Miasto, dziewiątka i granica prowadzą do District 9." }),
  emoji({ id: "levanter", answer: "Levanter", symbols: ["🍃", "🕊️", "➡️"], difficulty: 4, hint: "Wiatr i uwolnienie się od tego, co było.", explanation: "Liść niesiony wiatrem, wolność i odejście tworzą skojarzenie z Levanter." }),
  emoji({ id: "lonely-st", answer: "Lonely St.", symbols: ["🛣️", "🌙", "🚶"], difficulty: 3, hint: "Samotna droga nocą.", explanation: "Pusta ulica, noc i samotny spacer prowadzą do Lonely St." }),
  emoji({ id: "cover-me", answer: "Cover Me", symbols: ["🫂", "🌧️", "🛡️"], difficulty: 4, hint: "Ktoś chroni Cię przed tym, co spada z góry.", explanation: "Objęcie, deszcz i osłona tworzą prośbę Cover Me." }),
  emoji({ id: "secret-secret", answer: "Secret Secret", symbols: ["🤫", "🔒", "🌧️"], difficulty: 5, hint: "To, czego nie wypowiadasz na głos.", explanation: "Cisza i zamknięcie oznaczają sekret, a deszcz podkreśla emocjonalny klimat Secret Secret." }),
  emoji({ id: "jjam", answer: "JJAM", symbols: ["🍓", "🥄", "🎸"], difficulty: 3, hint: "Słodka rzecz do pieczywa, ale podana z muzyczną energią.", explanation: "Owoce, łyżka i muzyczny riff prowadzą do JJAM." }),
  emoji({ id: "walkin-on-water", answer: "Walkin On Water", symbols: ["🚶", "🌊", "✨"], difficulty: 2, hint: "Spacer w miejscu, w którym zwykle trzeba pływać.", explanation: "Postać idąca po falach dosłownie obrazuje Walkin On Water." }),
  emoji({ id: "ceremony", answer: "CEREMONY", symbols: ["🏛️", "👑", "🎉"], difficulty: 3, hint: "Uroczyste wydarzenie z celebracją.", explanation: "Oficjalna oprawa, korona i świętowanie prowadzą do CEREMONY." }),
  emoji({ id: "i-do", answer: "I Do", symbols: ["💍", "🤝", "❤️"], difficulty: 2, hint: "Krótka odpowiedź podczas ważnej obietnicy.", explanation: "Pierścionek, zgoda i uczucie wskazują na I Do." }),
  emoji({ id: "way-out", answer: "Way Out", symbols: ["🚪", "🛣️", "👋"], difficulty: 5, hint: "Droga prowadząca poza obecne miejsce.", explanation: "Wyjście, droga i pożegnanie składają się na Way Out." }),
  emoji({ id: "back-than", answer: "Back Than", symbols: ["↩️", "🕰️", "💭"], difficulty: 5, hint: "Powrót myślami do wcześniejszego czasu.", explanation: "Cofnięcie, zegar i wspomnienie prowadzą do Back Than." }),
  emoji({ id: "gods-menu-variant", answer: "God's Menu", symbols: ["🍽️", "⭐", "🔥"], difficulty: 2, hint: "Posiłek oceniony na najwyższym poziomie.", explanation: "Talerz, gwiazda i ogień są drugim wariantem skojarzenia z God's Menu." })
];

const LORE_QUESTIONS = [
  lore({ id: "bang-chan-birthday", prompt: "Którą datę urodzin podaje oficjalny profil Bang Chana?", answer: "3 października 1997", alternatives: ["25 października 1998", "11 sierpnia 1999", "20 marca 2000"], difficulty: 2, explanation: "Oficjalny profil JYP podaje datę Bang Chana jako 1997.10.03.", source: CONTENT_SOURCES.profile }),
  lore({ id: "lee-know-birthday", prompt: "Którą datę urodzin podaje oficjalny profil Lee Know?", answer: "25 października 1998", alternatives: ["3 października 1997", "11 sierpnia 1999", "22 września 2000"], difficulty: 2, explanation: "Oficjalny profil JYP podaje datę Lee Know jako 1998.10.25.", source: CONTENT_SOURCES.profile }),
  lore({ id: "changbin-birthday", prompt: "Który członek ma na oficjalnym profilu datę urodzin 11 sierpnia 1999?", answer: "Changbin", alternatives: ["Bang Chan", "Lee Know", "Hyunjin"], difficulty: 1, explanation: "Data 1999.08.11 należy do Changbina.", source: CONTENT_SOURCES.profile }),
  lore({ id: "hyunjin-birthday", prompt: "Który członek ma na oficjalnym profilu datę urodzin 20 marca 2000?", answer: "Hyunjin", alternatives: ["Han", "Felix", "Seungmin"], difficulty: 1, explanation: "Data 2000.03.20 należy do Hyunjina.", source: CONTENT_SOURCES.profile }),
  lore({ id: "han-felix-days", prompt: "Która para ma urodziny dzień po dniu — 14 i 15 września 2000?", answer: "Han i Felix", alternatives: ["Hyunjin i Han", "Felix i Seungmin", "Lee Know i Changbin"], difficulty: 2, explanation: "Profil podaje 14 września dla Hana i 15 września dla Felixa.", source: CONTENT_SOURCES.profile }),
  lore({ id: "seungmin-birthday", prompt: "Który członek ma na oficjalnym profilu datę urodzin 22 września 2000?", answer: "Seungmin", alternatives: ["Han", "Felix", "I.N"], difficulty: 1, explanation: "Data 2000.09.22 należy do Seungmina.", source: CONTENT_SOURCES.profile }),
  lore({ id: "youngest-profile", prompt: "Kto jest najmłodszy według dat na oficjalnym profilu ośmiu członków?", answer: "I.N", alternatives: ["Seungmin", "Felix", "Han"], difficulty: 1, explanation: "I.N ma datę 2001.02.08, najpóźniejszą spośród ośmiu profili.", source: CONTENT_SOURCES.profile }),
  lore({ id: "september-trio", prompt: "Która trójka ma urodziny we wrześniu 2000 roku?", answer: "Han, Felix i Seungmin", alternatives: ["Hyunjin, Han i Felix", "Felix, Seungmin i I.N", "Changbin, Han i Seungmin"], difficulty: 2, explanation: "Profil podaje wrześniowe daty 14, 15 i 22 dla Hana, Felixa i Seungmina.", source: CONTENT_SOURCES.profile }),
  lore({ id: "i-am-not-date", prompt: "Kiedy wydano album I am NOT?", answer: "26 marca 2018", alternatives: ["8 stycznia 2018", "6 sierpnia 2018", "22 października 2018"], difficulty: 3, explanation: "Dyskografia JYP datuje I am NOT na 2018-03-26.", source: CONTENT_SOURCES.earlyDiscography }),
  lore({ id: "miroh-date", prompt: "Która data wydania należy do Clé 1 : MIROH?", answer: "25 marca 2019", alternatives: ["19 czerwca 2019", "9 października 2019", "9 grudnia 2019"], difficulty: 3, explanation: "Clé 1 : MIROH ukazało się 25 marca 2019.", source: CONTENT_SOURCES.discography2019 }),
  lore({ id: "go-live-date", prompt: "Kiedy ukazało się GO生 (GO LIVE)?", answer: "17 czerwca 2020", alternatives: ["18 marca 2020", "14 września 2020", "26 listopada 2020"], difficulty: 3, explanation: "Oficjalna dyskografia podaje 17 czerwca 2020.", source: CONTENT_SOURCES.discography2020 }),
  lore({ id: "noeasy-date", prompt: "Która data wydania należy do NOEASY?", answer: "23 sierpnia 2021", alternatives: ["26 czerwca 2021", "29 listopada 2021", "18 marca 2022"], difficulty: 2, explanation: "NOEASY ukazało się 23 sierpnia 2021.", source: CONTENT_SOURCES.discography2022 }),
  lore({ id: "oddinary-date", prompt: "Kiedy wydano ODDINARY?", answer: "18 marca 2022", alternatives: ["29 listopada 2021", "1 sierpnia 2022", "7 października 2022"], difficulty: 2, explanation: "ODDINARY ma oficjalną datę 18 marca 2022.", source: CONTENT_SOURCES.discography2022 }),
  lore({ id: "maxident-date", prompt: "Która data wydania należy do MAXIDENT?", answer: "7 października 2022", alternatives: ["18 marca 2022", "21 grudnia 2022", "2 czerwca 2023"], difficulty: 2, explanation: "MAXIDENT ukazało się 7 października 2022.", source: CONTENT_SOURCES.discography2022 }),
  lore({ id: "five-star-date", prompt: "Kiedy wydano ★★★★★ (5-STAR)?", answer: "2 czerwca 2023", alternatives: ["10 listopada 2023", "10 maja 2024", "19 lipca 2024"], difficulty: 2, explanation: "5-STAR ma oficjalną datę 2 czerwca 2023.", source: CONTENT_SOURCES.discography2024 }),
  lore({ id: "rock-star-date", prompt: "Która data wydania należy do 樂-STAR (ROCK-STAR)?", answer: "10 listopada 2023", alternatives: ["2 czerwca 2023", "10 maja 2024", "19 lipca 2024"], difficulty: 2, explanation: "ROCK-STAR ukazało się 10 listopada 2023.", source: CONTENT_SOURCES.discography2024 }),
  lore({ id: "ate-date", prompt: "Kiedy wydano ATE?", answer: "19 lipca 2024", alternatives: ["10 maja 2024", "22 lipca 2024", "13 grudnia 2024"], difficulty: 1, explanation: "ATE ma oficjalną datę 19 lipca 2024.", source: CONTENT_SOURCES.discography2024 }),
  lore({ id: "hop-date", prompt: "Która data wydania należy do 合 (HOP)?", answer: "13 grudnia 2024", alternatives: ["13 listopada 2024", "16 grudnia 2024", "21 marca 2025"], difficulty: 2, explanation: "合 (HOP) ukazało się 13 grudnia 2024.", source: CONTENT_SOURCES.discography2025 }),
  lore({ id: "do-it-date", prompt: "Kiedy oficjalna dyskografia datuje DO IT?", answer: "21 listopada 2025", alternatives: ["22 sierpnia 2025", "26 grudnia 2025", "13 marca 2026"], difficulty: 3, explanation: "DO IT ma w dyskografii datę 21 listopada 2025.", source: CONTENT_SOURCES.discography2026 }),
  lore({ id: "this-that-date", prompt: "Kiedy wydano album THIS & THAT?", answer: "7 sierpnia 2026", alternatives: ["24 czerwca 2026", "1 sierpnia 2026", "10 sierpnia 2026"], difficulty: 1, explanation: "Oficjalna dyskografia podaje 7 sierpnia 2026.", source: CONTENT_SOURCES.currentDiscography }),
  lore({ id: "kingdom-winner", prompt: "Kto wygrał finał Kingdom: Legendary War 3 czerwca 2021?", answer: "Stray Kids", alternatives: ["THE BOYZ", "ATEEZ", "BTOB"], difficulty: 1, explanation: "Po zsumowaniu wyników finałowym zwycięzcą ogłoszono Stray Kids.", source: CONTENT_SOURCES.kingdom }),
  lore({ id: "kingdom-final-song", prompt: "Jaki utwór Stray Kids wykonali jako własny numer finałowy w Kingdom: Legendary War?", answer: "WOLFGANG", alternatives: ["The Real", "KINGDOM COME", "Believer"], difficulty: 2, explanation: "W finale Stray Kids zaprezentowali WOLFGANG.", source: CONTENT_SOURCES.kingdom }),
  lore({ id: "billboard-first-five", prompt: "Który album rozpoczął serię pierwszych pięciu debiutów Stray Kids na 1. miejscu Billboard 200?", answer: "ODDINARY", alternatives: ["NOEASY", "MAXIDENT", "5-STAR"], difficulty: 3, explanation: "Billboard wymienia ODDINARY jako pierwszy z pięciu kolejnych albumów debiutujących na szczycie przed i wraz z ATE.", source: CONTENT_SOURCES.billboard }),
  lore({ id: "ate-fifth-number-one", prompt: "Którym kolejnym albumem Stray Kids debiutującym na 1. miejscu Billboard 200 było ATE?", answer: "Piątym", alternatives: ["Czwartym", "Szóstym", "Ósmym"], difficulty: 3, explanation: "ATE było piątym kolejnym albumem Stray Kids debiutującym na 1. miejscu zestawienia.", source: CONTENT_SOURCES.billboard }),
  lore({ id: "eight-number-ones", prompt: "Ile kolejnych albumów od ODDINARY do DO IT miało według oficjalnego opisu THIS & THAT wejść na 1. miejsce Billboard 200?", answer: "8", alternatives: ["5", "6", "7"], difficulty: 4, explanation: "Oficjalny opis THIS & THAT wskazuje serię ośmiu kolejnych wejść na szczyt do DO IT włącznie.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "this-that-track-count", prompt: "Ile utworów zawiera album THIS & THAT według oficjalnego opisu?", answer: "8", alternatives: ["7", "9", "10"], difficulty: 2, explanation: "Opis albumu wymienia osiem utworów, w tym wersję Festival tytułowego singla.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "farming-concept", prompt: "Z jakiego obszaru pochodzi pojęcie wykorzystane w koncepcie utworu FARMING?", answer: "Z gier", alternatives: ["Z gotowania", "Z wyścigów", "Z fotografii"], difficulty: 2, explanation: "Oficjalny opis nazywa FARMING hip-hopowym utworem żartobliwie wykorzystującym gamingowe pojęcie farmienia.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "after-you-genre", prompt: "Jaki gatunek przypisuje oficjalny opis utworowi After You?", answer: "Progressive house", alternatives: ["Acoustic hip-hop", "Rock", "Drum and bass"], difficulty: 4, explanation: "After You zostało opisane jako progressive house z nostalgicznym gitarowym riffem i energetycznym dropem.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "way-out-genre", prompt: "Jaki gatunek przypisuje oficjalny opis utworowi Way Out?", answer: "Acoustic hip-hop", alternatives: ["Progressive house", "World beat", "Pop-punk"], difficulty: 4, explanation: "Way Out zostało przedstawione jako akustyczny hip-hop z powściągliwą emocją rozstania.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "i-am-trilogy-middle", prompt: "Które wydawnictwo znajduje się chronologicznie między I am NOT a I am YOU?", answer: "I am WHO", alternatives: ["Clé 1 : MIROH", "IN生 (IN LIFE)", "ODDINARY"], difficulty: 3, explanation: "Trylogia z 2018 roku układa się: I am NOT, I am WHO, I am YOU.", source: CONTENT_SOURCES.earlyDiscography }),
  lore({ id: "cle-2019-last", prompt: "Które z tych wydań zamyka chronologicznie serię trzech wydań Clé z 2019 roku?", answer: "Clé : LEVANTER", alternatives: ["Clé 1 : MIROH", "Clé 2 : Yellow Wood", "I am YOU"], difficulty: 4, explanation: "W 2019 roku kolejność prowadzi od MIROH przez Yellow Wood do Clé : LEVANTER z 9 grudnia.", source: CONTENT_SOURCES.discography2019 }),
  lore({ id: "go-live-in-life-order", prompt: "Która para poprawnie pokazuje kolejność wydań z 2020 roku?", answer: "GO生 (GO LIVE) → IN生 (IN LIFE)", alternatives: ["IN生 (IN LIFE) → GO生 (GO LIVE)", "NOEASY → GO生 (GO LIVE)", "IN生 (IN LIFE) → ODDINARY"], difficulty: 4, explanation: "GO LIVE ukazało się 17 czerwca 2020, a IN LIFE 14 września 2020.", source: CONTENT_SOURCES.discography2020 }),
  lore({ id: "oddinary-maxident-order", prompt: "Która para poprawnie pokazuje kolejność dwóch koreańskich wydań z 2022 roku?", answer: "ODDINARY → MAXIDENT", alternatives: ["MAXIDENT → ODDINARY", "NOEASY → Christmas EveL", "5-STAR → MAXIDENT"], difficulty: 4, explanation: "ODDINARY wydano 18 marca, a MAXIDENT 7 października 2022.", source: CONTENT_SOURCES.discography2022 }),
  lore({ id: "five-star-rock-star-order", prompt: "Które wydawnictwo z 2023 roku ukazało się później?", answer: "樂-STAR (ROCK-STAR)", alternatives: ["★★★★★ (5-STAR)", "MAXIDENT", "ATE"], difficulty: 3, explanation: "5-STAR ukazało się 2 czerwca, a ROCK-STAR 10 listopada 2023.", source: CONTENT_SOURCES.discography2024 }),
  lore({ id: "ate-hop-order", prompt: "Które wydawnictwo ukazało się później: ATE czy 合 (HOP)?", answer: "合 (HOP)", alternatives: ["ATE", "Ukazały się tego samego dnia", "ODDINARY"], difficulty: 3, explanation: "ATE wydano 19 lipca 2024, a HOP 13 grudnia 2024.", source: CONTENT_SOURCES.discography2025 }),
  lore({ id: "september-birthday-order", prompt: "Która kolejność wrześniowych urodzin jest poprawna?", answer: "Han → Felix → Seungmin", alternatives: ["Felix → Han → Seungmin", "Seungmin → Felix → Han", "Han → Seungmin → Felix"], difficulty: 4, explanation: "Oficjalne daty to kolejno 14, 15 i 22 września 2000.", source: CONTENT_SOURCES.profile }),
  lore({ id: "this-that-closing-track", prompt: "Który utwór zamyka ośmioutworową listę THIS & THAT?", answer: "This & That (Festival Ver.)", alternatives: ["Back Than", "Way Out", "FARMING"], difficulty: 5, explanation: "Ósmą pozycją oficjalnej listy jest festiwalowa wersja utworu tytułowego.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "this-that-genre-match", prompt: "Które zestawienie gatunków dwóch utworów z THIS & THAT jest zgodne z oficjalnym opisem?", answer: "After You — progressive house; Way Out — acoustic hip-hop", alternatives: ["After You — acoustic hip-hop; Way Out — progressive house", "After You — pop-punk; Way Out — drum and bass", "After You — rock; Way Out — world beat"], difficulty: 5, explanation: "Opis przypisuje After You progressive house, a Way Out akustyczny hip-hop.", source: CONTENT_SOURCES.thisAndThat, kind: "official_media_detail" }),
  lore({ id: "billboard-before-ate", prompt: "Który album bezpośrednio poprzedzał ATE w serii kolejnych debiutów Stray Kids na 1. miejscu Billboard 200?", answer: "樂-STAR (ROCK-STAR)", alternatives: ["★★★★★ (5-STAR)", "MAXIDENT", "合 (HOP)"], difficulty: 5, explanation: "W opisywanej serii po ROCK-STAR nastąpiło ATE, piąty kolejny debiut na szczycie.", source: CONTENT_SOURCES.billboard }),
  lore({ id: "profile-birth-years", prompt: "Ile różnych roczników urodzenia obejmuje oficjalny profil ośmiu członków?", answer: "5", alternatives: ["3", "4", "6"], difficulty: 5, explanation: "Na profilu występują roczniki 1997, 1998, 1999, 2000 i 2001 — łącznie pięć.", source: CONTENT_SOURCES.profile })
];

const QUESTION_BANK = [
  ...QUALITY_ASSOCIATION_QUESTIONS,
  ...EMOJI_QUESTIONS,
  ...QUALITY_LORE_QUESTIONS,
  ...WHO_IS_WHO_QUESTIONS,
  ...DISCOGRAPHY_QUESTIONS
];

export function getQuizQuestions(modeId) {
  return QUESTION_BANK.filter((question) => question.modeId === modeId);
}

export function hasQuizRound(modeId) {
  return QUESTION_BANK.some((question) => question.modeId === modeId);
}

export function getQuizQuestionCount(modeId) {
  return getQuizQuestions(modeId).length;
}

export const QUIZ_QUESTION_COUNT = QUESTION_BANK.length;
