const KNOWLEDGE = "knowledge";

export const GAME_MODES = Object.freeze([
  {
    id: "assoc-master",
    name: "Mistrz Skojarzeń",
    shortName: "Skojarzenia",
    eyebrow: "Symbole • rekwizyty • cytaty",
    description: "Rozpoznaj utwór albo członka po zestawie celnych tropów.",
    icon: "✦",
    accent: "lime",
    reward: 75,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    plannedContent: "40 sprawdzonych zagadek • runda 10",
    implementation: [
      "dwie kategorie: utwory oraz członkowie i SKZOO",
      "pięć poziomów gry oraz runda mieszana",
      "tropy odsłaniane pojedynczo i premia za szybsze skojarzenie"
    ]
  },
  {
    id: "emoji-guesser",
    name: "Zgadnij Utwór po Emoji",
    shortName: "Emoji",
    eyebrow: "Tytuł • motyw • klimat",
    description: "Wybierz spośród A–D oficjalny tytuł ukryty w zestawie emoji.",
    icon: "🧩",
    accent: "cyan",
    reward: 60,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    plannedContent: "40 utworów • zawsze A–D",
    implementation: [
      "bez wpisywania angielskich tytułów",
      "cztery prawdziwe tytuły Stray Kids w każdej zagadce",
      "trudność zależna od symboli i podobieństwa odpowiedzi"
    ]
  },
  {
    id: "timeline",
    name: "SKZ Timeline Architect",
    shortName: "Oś czasu",
    eyebrow: "Historia • ery • osiągnięcia",
    description: "Ułóż wydarzenia w poprawnej kolejności i zbuduj historię zespołu.",
    icon: "⌛",
    accent: "violet",
    reward: 90,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    plannedContent: "40 układów • 30 wydarzeń • 5 poziomów",
    implementation: [
      "rozmiar osi i trudność chronologii są liczone osobno",
      "przeciąganie kart palcem lub przyciski",
      "daty i źródła ujawniane po sprawdzeniu"
    ]
  },
  {
    id: "hardcore-lore",
    name: "Hardcore Lore Quiz",
    shortName: "Lore",
    eyebrow: "Veteran • Master • Insane",
    description: "Trudne pytania o dyskografię, historię, unity i oficjalne materiały.",
    icon: "⚡",
    accent: "coral",
    reward: 100,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    minimumDifficulty: 3,
    plannedContent: "147 zagadnień • po 49 na Veteran, Master i Insane",
    implementation: [
      "tryb zaczyna się od poziomu Veteran",
      "serie bezbłędnych odpowiedzi",
      "źródło i wyjaśnienie przy każdym rozwiązaniu"
    ]
  },
  {
    id: "who-is-who",
    name: "Who Is Who?",
    shortName: "Who Is Who",
    eyebrow: "Fakty • daty • SKZOO",
    description: "Połącz kilka tropów i rozpoznaj jednego członka całej ósemki.",
    icon: "👤",
    accent: "amber",
    reward: 75,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    plannedContent: "200 zestawów • 40 na każdy poziom",
    implementation: [
      "odpowiedź wynika z przecięcia kilku faktów",
      "żadnych pytań zdradzających rozwiązanie",
      "odpowiedzi A–D i stopniowo odsłaniane tropy"
    ]
  },
  {
    id: "discography-builder",
    name: "Discography Builder",
    shortName: "Dyskografia",
    eyebrow: "Albumy • utwory • chronologia",
    description: "Łącz utwory z albumami, rozpoznawaj title tracki i buduj dyskografię.",
    icon: "💿",
    accent: "terracotta",
    reward: 80,
    section: KNOWLEDGE,
    supportsDifficulty: true,
    plannedContent: "123 konfiguracje • runda 10",
    implementation: [
      "utwór → album i album → title track",
      "chronologia wydań oraz wybór intruza",
      "wiarygodne odpowiedzi z oficjalnej dyskografii"
    ]
  },
  {
    id: "skzoo-memory",
    name: "SKZOO Memory Game",
    shortName: "Memory",
    eyebrow: "Refleks • pamięć • SKZOO",
    description: "Odkrywaj karty i łącz symbole, SKZOO, członków oraz fakty w jak najmniejszej liczbie ruchów.",
    icon: "◆",
    accent: "pink",
    reward: 50,
    section: "memory",
    supportsDifficulty: true,
    plannedContent: "8 postaci • 5 poziomów",
    implementation: [
      "plansze od 4 do 8 par oraz różne typy dopasowania",
      "aktywny czas zatrzymuje się po wyjściu z rundy",
      "liczba ruchów jest ważniejsza od szybkości"
    ]
  },
  {
    id: "daily-challenge",
    name: "Daily Challenge",
    shortName: "Daily",
    eyebrow: "Dzisiejszy zestaw • seria dni",
    description: "Dziesięć mieszanych zadań, jeden punktowany wynik i nowy zestaw każdego dnia.",
    icon: "🎯",
    accent: "gold",
    reward: 100,
    section: "today",
    supportsDifficulty: false,
    plannedContent: "10 zadań • raz dziennie",
    implementation: [
      "ten sam zestaw przez cały dzień",
      "wynik do profilu zapisuje się tylko przy pierwszym ukończeniu",
      "osobna seria kolejnych dni"
    ]
  }
].map((mode) => Object.freeze(mode)));

export const STAY_LAB_MODES = Object.freeze([
  Object.freeze({
    id: "soulmate-lab",
    name: "Kto jest Twoją bratnią duszą?",
    shortName: "Bratnia Dusza",
    eyebrow: "STAY Lab • zabawa fandomowa",
    description: "Sytuacyjne wybory tworzą trzy fandomowe dopasowania — bez dobrych i złych odpowiedzi.",
    icon: "💞",
    accent: "rose",
    reward: 0,
    section: "lab",
    supportsDifficulty: false,
    plannedContent: "25 z 40 pytań • bez punktów",
    implementation: [
      "zabawa fandomowa, nie test psychologiczny",
      "ukryte dopasowanie do całej ósemki",
      "odznaka Soul Connection za pierwsze ukończenie"
    ]
  })
]);

export const ALL_MODES = Object.freeze([...GAME_MODES, ...STAY_LAB_MODES]);

export function findGameMode(modeId) {
  return ALL_MODES.find(({ id }) => id === modeId);
}

export function getModesBySection(section) {
  return GAME_MODES.filter((mode) => mode.section === section);
}
