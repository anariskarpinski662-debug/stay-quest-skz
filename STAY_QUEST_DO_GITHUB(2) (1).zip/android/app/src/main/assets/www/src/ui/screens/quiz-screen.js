import { createQuizSession } from "../../game/quiz-session.js";
import { QUESTION_TYPES } from "../../game/question-schema.js";
import { escapeHtml } from "../html.js";

const KIND_LABELS = {
  official_fact: "Fakt oficjalny",
  official_media_detail: "Oficjalny materiał",
  puzzle_interpretation: "Autorska zagadka",
  fandom_lore: "Fandomowe lore",
  fan_theory: "Teoria fanowska"
};

function renderDifficulty(level) {
  return `<span class="difficulty" aria-label="Trudność ${level} z 5">${"●".repeat(level)}${"○".repeat(5 - level)}</span>`;
}

function renderClues(question) {
  if (!question.totalClues) return "";
  const slots = [];

  for (let index = 0; index < question.totalClues; index += 1) {
    const clue = question.clues[index];
    slots.push(
      clue
        ? `<span data-clue-index="${index}"><small>${String(index + 1).padStart(2, "0")}</small>${escapeHtml(clue)}</span>`
        : `<span class="is-locked" data-clue-index="${index}"><small>${String(index + 1).padStart(2, "0")}</small><em>Ukryty trop</em></span>`
    );
  }

  return `<div class="clue-grid" aria-label="Tropy">${slots.join("")}</div>`;
}

function getOptionClass(optionId, result) {
  if (!result) return "";
  if (optionId === result.correctAnswerId) return " is-correct";
  if (optionId === result.submittedAnswer && !result.correct) return " is-wrong";
  return " is-muted";
}

function renderChoiceAnswers(question, result) {
  const disabled = result ? " disabled" : "";

  return `
    <fieldset class="answer-options"${disabled}>
      <legend class="sr-only">Wybierz jedną odpowiedź</legend>
      ${question.options
        .map((option, index) => {
          const selected = result?.submittedAnswer === option.id ? " checked" : "";
          return `
            <label class="answer-option${getOptionClass(option.id, result)}">
              <input type="radio" name="answer" value="${escapeHtml(option.id)}"${selected}${disabled} />
              <span class="answer-option__key" aria-hidden="true">${String.fromCharCode(65 + index)}</span>
              <span class="answer-option__label">${escapeHtml(option.label)}</span>
              <span class="answer-option__status" aria-hidden="true"></span>
            </label>
          `;
        })
        .join("")}
    </fieldset>
  `;
}

function renderTextAnswer(question, result) {
  const answer = result?.submittedAnswer ?? "";
  const stateClass = result ? (result.correct ? " is-correct" : " is-wrong") : "";

  return `
    <label class="text-answer${stateClass}">
      <span>Twój tytuł</span>
      <input
        type="text"
        name="answer"
        value="${escapeHtml(answer)}"
        placeholder="Wpisz odpowiedź…"
        autocomplete="off"
        autocapitalize="words"
        spellcheck="false"
        ${result ? "disabled" : ""}
      />
    </label>
  `;
}

function renderActiveActions(question, revealedHints, canUseHint) {
  const usedCount = revealedHints.length;
  const nextPenalty = Math.round((question.hintPenaltyRates?.[usedCount] ?? 0) * 100);
  const hintButton = question.hasHint
    ? canUseHint
      ? `<button class="button button--quiet" type="button" data-action="quiz-hint">Podpowiedź ${usedCount + 1} −${nextPenalty}%</button>`
      : `<span class="hint-used"><span aria-hidden="true">✓</span> Wykorzystano ${usedCount} podpowiedzi</span>`
    : "";
  const clueButton = question.canRevealClue
    ? `<button class="button button--quiet" type="button" data-action="quiz-clue">Odsłoń trop −${question.revealPenaltyPerClue} pkt</button>`
    : "";

  return `
    <div class="quiz-support-actions">
      ${clueButton}
      ${hintButton}
      <button class="button button--quiet" type="button" data-action="quiz-skip">Pomiń</button>
    </div>
    <p class="answer-error" id="answer-error" role="alert" hidden></p>
    <button class="button button--primary button--wide quiz-submit" type="submit" disabled>Sprawdź odpowiedź</button>
  `;
}

function renderScoring(result) {
  if (!result.correct) return `<span class="score-chip score-chip--zero">+0 pkt</span>`;

  const parts = [
    `<span>Baza <strong>+${result.scoring.basePoints}</strong></span>`,
    result.scoring.difficultyBonus
      ? `<span>Trudność <strong>+${result.scoring.difficultyBonus}</strong></span>`
      : "",
    result.scoring.streakBonus ? `<span>Seria <strong>+${result.scoring.streakBonus}</strong></span>` : "",
    result.scoring.hintPenalty ? `<span>Podpowiedź <strong>−${result.scoring.hintPenalty}</strong></span>` : "",
    result.scoring.revealPenalty ? `<span>Dodatkowe tropy <strong>−${result.scoring.revealPenalty}</strong></span>` : "",
    result.scoring.repeatPenalty ? `<span>Anty-powtórka <strong>−${result.scoring.repeatPenalty}</strong></span>` : ""
  ].filter(Boolean);

  return `<div class="score-breakdown">${parts.join("")}</div>`;
}

function renderFeedback(result, isLastQuestion) {
  const heading = result.correct ? "DOBRY TROP!" : result.skipped ? "Pytanie pominięte" : "Jeszcze nie tym razem";
  const icon = result.correct ? "✓" : "×";
  const kindLabel = KIND_LABELS[result.kind] ?? "Wyjaśnienie";
  const source = result.source
    ? `
      <p class="answer-source">
        <span>Źródło weryfikacji</span>
        <a href="${escapeHtml(result.source.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(result.source.title)}</a>
        <small>Sprawdzone: ${escapeHtml(result.source.checkedAt)}</small>
      </p>
    `
    : "";

  return `
    <section class="answer-feedback answer-feedback--${result.correct ? "correct" : "wrong"}" tabindex="-1" aria-live="polite">
      <div class="answer-feedback__header">
        <span class="answer-feedback__icon" aria-hidden="true">${icon}</span>
        <div><p class="eyebrow">${kindLabel}</p><h2>${heading}</h2></div>
        <strong class="answer-feedback__points">+${result.earnedPoints}</strong>
      </div>
      ${!result.correct && !result.skipped ? `<p class="submitted-answer"><span>Twoja odpowiedź</span><strong>${escapeHtml(result.submittedAnswerLabel)}</strong></p>` : ""}
      <p class="correct-answer"><span>Poprawna odpowiedź</span><strong>${escapeHtml(result.correctAnswer)}</strong></p>
      <p class="answer-feedback__explanation"><strong>${result.correct ? "Warto wiedzieć:" : "Dlaczego:"}</strong> ${escapeHtml(result.explanation)}</p>
      ${source}
      ${renderScoring(result)}
      <button class="button button--primary button--wide" type="button" data-action="quiz-next">
        ${isLastQuestion ? "Zobacz podsumowanie" : "Następne pytanie"} <span aria-hidden="true">→</span>
      </button>
    </section>
  `;
}

function renderQuestionScreen(mode, snapshot) {
  const question = snapshot.currentQuestion;
  const answered = snapshot.status === "answered";
  const progress = Math.round((snapshot.answeredQuestions / snapshot.totalQuestions) * 100);
  const answerControl = question.type === QUESTION_TYPES.SINGLE_CHOICE
    ? renderChoiceAnswers(question, snapshot.lastResult)
    : renderTextAnswer(question, snapshot.lastResult);

  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Zakończ rundę</a>
    <section class="quiz-status" aria-label="Stan rundy">
      <div class="quiz-status__row">
        <span>Pytanie <strong>${snapshot.questionNumber}/${snapshot.totalQuestions}</strong></span>
        <span class="quiz-score"><strong>${snapshot.score}</strong> pkt</span>
        <span>Seria <strong>${snapshot.currentStreak}</strong></span>
      </div>
      <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}">
        <span style="width: ${progress}%"></span>
      </div>
    </section>

    <article class="question-card question-card--${escapeHtml(mode.accent)}">
      <header class="question-card__meta">
        <span>${escapeHtml(question.category)}</span>
        ${renderDifficulty(question.difficulty)}
      </header>
      <p class="eyebrow">${escapeHtml(mode.shortName)} • ${KIND_LABELS[question.kind] ?? "Zagadka"}</p>
      <h1 tabindex="-1">${escapeHtml(question.prompt)}</h1>
      ${renderClues(question)}
      ${snapshot.revealedHints.map((hint, index) => `<aside class="hint-card" tabindex="-1"><strong>Podpowiedź ${index + 1}</strong><p>${escapeHtml(hint.text)}</p></aside>`).join("")}

      <form class="quiz-form" novalidate>
        ${answerControl}
        ${answered ? "" : renderActiveActions(question, snapshot.revealedHints, snapshot.canUseHint)}
      </form>
    </article>

    ${answered ? renderFeedback(snapshot.lastResult, snapshot.questionNumber === snapshot.totalQuestions) : ""}
  `;
}

function summaryTitle(accuracy) {
  if (accuracy >= 90) return "Master STAY energy";
  if (accuracy >= 70) return "Bardzo mocna runda";
  if (accuracy >= 50) return "Dobry kierunek";
  return "Rozgrzewka zaliczona";
}

function renderSummary(mode, summary, completionOutcome) {
  const savedNotice = mode.id === "daily-challenge" && completionOutcome?.alreadyRecorded
    ? "Dzisiejszy punktowany wynik był już zapisany. Ta powtórka została potraktowana jako trening i nie dodała kolejnych punktów."
    : "Wynik został dodany do profilu. System zapamiętał też pokazane pytania, aby ograniczyć szybkie powtórki.";
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="quiz-summary">
      <div class="summary-orbit" style="--accuracy: ${summary.accuracy}" aria-label="Skuteczność ${summary.accuracy} procent">
        <div><strong>${summary.accuracy}%</strong><span>skuteczności</span></div>
      </div>
      <p class="eyebrow">Runda ukończona</p>
      <h1 tabindex="-1">${summaryTitle(summary.accuracy)}</h1>
      <p class="quiz-summary__copy">Silnik policzył odpowiedzi, premie za trudność, serię oraz użyte podpowiedzi.</p>

      <div class="summary-score"><span>Twój wynik</span><strong>${summary.score} pkt</strong></div>
      <div class="summary-grid">
        <article><span>Poprawne</span><strong>${summary.correctAnswers}/${summary.totalQuestions}</strong></article>
        <article><span>Najdłuższa seria</span><strong>${summary.longestStreak}</strong></article>
        <article><span>Błędne</span><strong>${summary.incorrectAnswers}</strong></article>
      </div>

      <p class="demo-notice">${savedNotice}</p>
      <div class="summary-actions">
        <button class="button button--primary button--wide" type="button" data-action="quiz-restart">Zagraj ponownie</button>
        <a class="button button--secondary button--wide" href="#/mode/${escapeHtml(mode.id)}">Wróć do trybu</a>
      </div>
    </section>
  `;
}

export function createQuizScreen({
  mode,
  questions,
  difficulty = "mixed",
  recentQuestionIds = [],
  recentQuestionHistory = [],
  randomFactory = () => Math.random,
  onComplete = () => {},
  onFeedback = () => {}
}) {
  const screen = document.createElement("div");
  screen.className = "screen quiz-screen";
  let completionOutcome = null;
  let activeRecentQuestionIds = [...recentQuestionIds];
  let activeRecentQuestionHistory = [...recentQuestionHistory];

  function createSession() {
    return createQuizSession({
      modeId: mode.id,
      questions,
      questionCount: Math.min(10, questions.length),
      difficulty,
      recentQuestionIds: activeRecentQuestionIds,
      recentQuestionHistory: activeRecentQuestionHistory,
      random: randomFactory()
    });
  }

  let session = createSession();

  function render(focusSelector = "h1") {
    const snapshot = session.getSnapshot();
    screen.innerHTML = snapshot.status === "complete"
      ? renderSummary(mode, session.getSummary(), completionOutcome)
      : renderQuestionScreen(mode, snapshot);

    requestAnimationFrame(() => screen.querySelector(focusSelector)?.focus({ preventScroll: true }));
  }

  function updateSubmitButton(form) {
    if (!form) return;
    const submit = form.querySelector(".quiz-submit");
    if (!submit) return;
    const answer = new FormData(form).get("answer");
    submit.disabled = !String(answer ?? "").trim();
    const error = form.querySelector("#answer-error");
    if (error) error.hidden = true;
  }

  screen.addEventListener("input", (event) => updateSubmitButton(event.target.closest("form")));
  screen.addEventListener("change", (event) => updateSubmitButton(event.target.closest("form")));

  screen.addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.target;
    const answer = new FormData(form).get("answer");

    try {
      const result = session.submitAnswer(answer);
      onFeedback(result.correct ? "correct" : "wrong");
      render(".answer-feedback");
    } catch (error) {
      const output = form.querySelector("#answer-error");
      output.textContent = error.message;
      output.hidden = false;
    }
  });

  screen.addEventListener("click", (event) => {
    const action = event.target.closest("[data-action]")?.dataset.action;
    if (!action) return;

    if (action === "quiz-hint") {
      onFeedback("tap");
      session.useHint();
      render(".hint-card:last-of-type");
    }
    if (action === "quiz-clue") {
      const reveal = session.revealClue();
      if (!reveal) return;
      onFeedback("tap");
      const slot = screen.querySelector(`[data-clue-index="${reveal.clueIndex}"]`);
      slot.classList.remove("is-locked");
      slot.tabIndex = -1;
      slot.innerHTML = `<small>${String(reveal.clueIndex + 1).padStart(2, "0")}</small>${escapeHtml(reveal.clue)}`;

      const button = event.target.closest("[data-action]");
      if (reveal.remaining === 0) button.remove();
      else button.textContent = `Odsłoń trop −${reveal.penalty} pkt`;
      slot.focus({ preventScroll: true });
    }
    if (action === "quiz-skip") {
      session.skip();
      onFeedback("wrong");
      render(".answer-feedback");
    }
    if (action === "quiz-next") {
      const snapshot = session.next();
      if (snapshot.status === "complete") {
        const summary = session.getSummary();
        completionOutcome = onComplete({
          ...summary,
          kind: "quiz",
          details: {
            questionIds: summary.questionIds,
            questionHistory: summary.questionHistory,
            topicIds: summary.topicIds,
            difficulty
          }
        });
        if (mode.id !== "daily-challenge") {
          activeRecentQuestionIds = [...new Set([...summary.questionIds, ...activeRecentQuestionIds])].slice(0, 100);
          activeRecentQuestionHistory = [
            ...summary.questionHistory.map((entry) => ({ ...entry, seenAt: new Date().toISOString() })),
            ...activeRecentQuestionHistory
          ].filter((entry, index, entries) => entries.findIndex((candidate) => candidate.id === entry.id) === index).slice(0, 100);
        }
      } else {
        onFeedback("tap");
      }
      render(snapshot.status === "complete" ? ".quiz-summary h1" : ".question-card h1");
    }
    if (action === "quiz-restart") {
      onFeedback("tap");
      completionOutcome = null;
      session = createSession();
      render(".question-card h1");
    }
  });

  render();
  return screen;
}
