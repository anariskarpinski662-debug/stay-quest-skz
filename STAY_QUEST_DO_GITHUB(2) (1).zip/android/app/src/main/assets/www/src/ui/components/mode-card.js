export function createModeCard(mode) {
  const article = document.createElement("article");
  article.className = `mode-card mode-card--${mode.accent}`;

  const link = document.createElement("a");
  link.className = "mode-card__link";
  link.href = `#/mode/${mode.id}`;
  link.setAttribute("aria-label", `${mode.name}. ${mode.description}`);

  const header = document.createElement("div");
  header.className = "mode-card__header";

  const icon = document.createElement("span");
  icon.className = "mode-card__icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = mode.icon;

  const arrow = document.createElement("span");
  arrow.className = "mode-card__arrow";
  arrow.setAttribute("aria-hidden", "true");
  arrow.textContent = "↗";

  const eyebrow = document.createElement("p");
  eyebrow.className = "eyebrow";
  eyebrow.textContent = mode.eyebrow;

  const title = document.createElement("h3");
  title.textContent = mode.name;

  const description = document.createElement("p");
  description.className = "mode-card__description";
  description.textContent = mode.description;

  const meta = document.createElement("div");
  meta.className = "mode-card__meta";
  meta.innerHTML = `<span>${mode.reward > 0 ? `~${mode.reward} pkt` : "bez punktów"}</span><span>${mode.plannedContent}</span>`;

  header.append(icon, arrow);
  link.append(header, eyebrow, title, description, meta);
  article.append(link);
  return article;
}
