const HOME_ROUTE = Object.freeze({ name: "home", path: "/home", params: {} });

function parseHash() {
  const path = window.location.hash.replace(/^#/, "") || "/home";
  const segments = path.split("/").filter(Boolean);

  if (segments.length === 1 && segments[0] === "home") return HOME_ROUTE;
  if (segments.length === 2 && segments[0] === "mode") {
    return { name: "mode", path, params: { modeId: segments[1] } };
  }
  if ([2, 3].includes(segments.length) && segments[0] === "play") {
    return { name: "play", path, params: { modeId: segments[1], difficulty: segments[2] ?? "mixed" } };
  }
  if (segments.length === 1 && segments[0] === "achievements") {
    return { name: "achievements", path, params: {} };
  }
  if (segments.length === 1 && segments[0] === "settings") {
    return { name: "settings", path, params: {} };
  }

  return { name: "not-found", path, params: {} };
}

export function createRouter(onRouteChange) {
  const route = () => onRouteChange(parseHash());

  window.addEventListener("hashchange", route);
  if (!window.location.hash) window.history.replaceState(null, "", "#/home");
  route();

  return {
    current: parseHash,
    destroy: () => window.removeEventListener("hashchange", route)
  };
}
