import { createTimelineSession } from "../../game/timeline-session.js";
import { escapeHtml } from "../html.js";

const ROUND_OPTIONS = [
  { level: "mixed", size: 6, name: "Mieszana", detail: "6 wydarzeń • różne ery", icon: "AUTO" },
  { level: "1", size: 4, name: "Start", detail: "4 wydarzenia • odległe daty", icon: "01" },
  { level: "2", size: 6, name: "Standard", detail: "6 wydarzeń • pełna runda", icon: "02" },
  { level: "3", size: 8, name: "Veteran", detail: "8 wydarzeń • więcej szczegółów", icon: "03" },
  { level: "4", size: 8, name: "Master", detail: "8 wydarzeń • zbliżone okresy", icon: "04" },
  { level: "5", size: 8, name: "Insane", detail: "8 kolejnych wydarzeń w czasie", icon: "05" }
];

function getRoundOption(level) {
  return ROUND_OPTIONS.find((option) => option.level === String(level)) ?? ROUND_OPTIONS[0];
}

const dateFormatter = new Intl.DateTimeFormat("pl-PL", {
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: "UTC"
});

function formatDate(date) {
  return dateFormatter.format(new Date(`${date}T00:00:00Z`));
}

export function reorderForTouch(ids, eventId, deltaY) {
  const reordered = [...ids];
  const from = reordered.indexOf(eventId);
  if (from === -1 || Math.abs(deltaY) < 36) return reordered;

  const requestedSteps = Math.max(1, Math.round(Math.abs(deltaY) / 72));
  const direction = deltaY > 0 ? 1 : -1;
  const to = Math.max(0, Math.min(reordered.length - 1, from + requestedSteps * direction));
  if (from === to) return reordered;
  reordered.splice(to, 0, reordered.splice(from, 1)[0]);
  return reordered;
}

function renderSetup(mode, eventCount) {
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="special-setup special-setup--violet">
      <span class="special-setup__icon" aria-hidden="true">⌛</span>
      <p class="eyebrow">SKZ Timeline Architect</p>
      <h1 tabindex="-1">Jak długa ma być oś?</h1>
      <p>Ułóż wydarzenia od najstarszego do najnowszego. Zakres pomocy datami zależy od poziomu, a nie tylko od liczby kart.</p>
      <div class="round-picker">
        ${ROUND_OPTIONS.map(
          (option) => `
            <button type="button" data-action="timeline-start" data-level="${option.level}">
              <span>${option.icon}</span>
              <strong>${option.name}</strong>
              <small>${option.detail}</small>
            </button>
          `
        ).join("")}
      </div>
      <p class="content-count">Bank zawiera ${eventCount} wydarzeń ze źródłami. Brak limitu czasu.</p>
    </section>
  `;
}

function renderTimelineCard(event, index, total) {
  return `
    <article class="timeline-card" data-event-id="${escapeHtml(event.id)}" draggable="true">
      <div
        class="timeline-card__position"
        data-timeline-grab
        data-id="${escapeHtml(event.id)}"
        aria-hidden="true"
        title="Przeciągnij w górę lub w dół"
      ><span>${String(index + 1).padStart(2, "0")}</span><small>↕</small></div>
      <div class="timeline-card__copy">
        <p class="eyebrow">${escapeHtml(event.era)}</p>
        <h2>${escapeHtml(event.title)}</h2>
        <p>${escapeHtml(event.description)}</p>
        ${event.dateHint ? `<time class="timeline-date-hint">Pomoc: ${escapeHtml(event.dateHint)}</time>` : ""}
      </div>
      <div class="timeline-card__controls" aria-label="Zmień pozycję wydarzenia">
        <button type="button" data-action="timeline-move" data-direction="-1" data-id="${escapeHtml(event.id)}" aria-label="Przesuń ${escapeHtml(event.title)} wyżej" ${index === 0 ? "disabled" : ""}>↑</button>
        <button type="button" data-action="timeline-move" data-direction="1" data-id="${escapeHtml(event.id)}" aria-label="Przesuń ${escapeHtml(event.title)} niżej" ${index === total - 1 ? "disabled" : ""}>↓</button>
      </div>
    </article>
  `;
}

function renderGame(mode, snapshot) {
  const option = getRoundOption(snapshot.difficulty);
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Zakończ rundę</a>
    <section class="timeline-status">
      <div><p class="eyebrow">${option.name} • ${snapshot.roundSize} kart</p><h1>Od najstarszego do najnowszego</h1></div>
      <span>${snapshot.roundSize} wydarzeń</span>
    </section>
    <p class="timeline-instruction">Użyj strzałek albo przeciągnij numer karty w górę lub w dół.</p>
    <section class="timeline-list" aria-label="Twoja kolejność wydarzeń">
      ${snapshot.events.map((event, index) => renderTimelineCard(event, index, snapshot.events.length)).join("")}
    </section>
    <button class="button button--primary button--wide timeline-check" type="button" data-action="timeline-check">Sprawdź kolejność</button>
  `;
}

function renderResultCard(event) {
  const correct = event.correctPosition === event.userPosition;
  return `
    <article class="timeline-result-card${correct ? " is-correct" : ""}">
      <span class="timeline-result-card__position">${String(event.correctPosition).padStart(2, "0")}</span>
      <div>
        <p class="eyebrow">${escapeHtml(event.era)} • ${correct ? "dobra pozycja" : `Twoja pozycja: ${event.userPosition}`}</p>
        <h3>${escapeHtml(event.title)}</h3>
        <time datetime="${escapeHtml(event.date)}">${escapeHtml(formatDate(event.date))}</time>
        <p>${escapeHtml(event.description)}</p>
        <a href="${escapeHtml(event.source.url)}" target="_blank" rel="noopener noreferrer">Sprawdź źródło ↗</a>
      </div>
    </article>
  `;
}

function renderResult(mode, result) {
  return `
    <a class="back-link" href="#/mode/${escapeHtml(mode.id)}">← Wróć do trybu</a>
    <section class="timeline-summary">
      <span class="timeline-summary__badge" aria-hidden="true">${result.perfect ? "★" : "⌛"}</span>
      <p class="eyebrow">Oś sprawdzona</p>
      <h1 tabindex="-1">${result.perfect ? "Chronologia perfekcyjna!" : "Zobacz poprawną kolejność"}</h1>
      <p>${result.correctPositions} z ${result.total} wydarzeń znalazło się dokładnie na swojej pozycji.</p>
      <div class="timeline-summary__stats">
        <span>Wynik <strong>${result.score} pkt</strong></span>
        <span>Dokładność <strong>${result.accuracy}%</strong></span>
      </div>
    </section>
    <section class="timeline-answer" aria-label="Poprawna kolejność">
      ${result.correctOrder.map(renderResultCard).join("")}
    </section>
    <div class="summary-actions">
      <button class="button button--primary button--wide" type="button" data-action="timeline-restart">Nowe wydarzenia</button>
      <button class="button button--secondary button--wide" type="button" data-action="timeline-change-size">Zmień długość rundy</button>
    </div>
  `;
}

export function createTimelineScreen({ mode, events, setTemplates = [], difficulty = "mixed", recentTaskHistory = [], onComplete = () => {}, onFeedback = () => {} }) {
  const screen = document.createElement("div");
  screen.className = "screen timeline-screen";
  let session = null;
  let selectedDifficulty = String(difficulty);
  let draggedId = null;
  let touchDrag = null;
  let recentFingerprints = recentTaskHistory.map((entry) => typeof entry === "string" ? entry : entry.id);

  function renderSetupScreen() {
    session = null;
    screen.innerHTML = renderSetup(mode, events.length);
    requestAnimationFrame(() => screen.querySelector("h1")?.focus({ preventScroll: true }));
  }

  function renderActive(focusId = null) {
    screen.innerHTML = renderGame(mode, session.getSnapshot());
    const focusTarget = focusId
      ? screen.querySelector(`[data-event-id="${focusId}"] [data-action="timeline-move"]`)
      : screen.querySelector(".timeline-status h1");
    if (!focusId) focusTarget?.setAttribute("tabindex", "-1");
    requestAnimationFrame(() => focusTarget?.focus({ preventScroll: true }));
  }

  function start(level) {
    const option = getRoundOption(level);
    selectedDifficulty = option.level;
    session = createTimelineSession({
      events,
      setTemplates,
      roundSize: option.size,
      difficulty: option.level,
      recentSetFingerprints: recentFingerprints
    });
    renderActive();
  }

  function clearTouchDrag() {
    if (!touchDrag) return;
    touchDrag.card.classList.remove("is-touch-dragging");
    touchDrag.card.style.removeProperty("--touch-drag-y");
    touchDrag = null;
  }

  screen.addEventListener("click", (event) => {
    const actionTarget = event.target.closest("[data-action]");
    const action = actionTarget?.dataset.action;
    if (!action) return;

    if (action === "timeline-start") {
      onFeedback("tap");
      start(actionTarget.dataset.level);
    }
    if (action === "timeline-move") {
      const id = actionTarget.dataset.id;
      session.move(id, Number(actionTarget.dataset.direction));
      onFeedback("tap");
      renderActive(id);
    }
    if (action === "timeline-check") {
      const result = session.check();
      onComplete({
        modeId: mode.id,
        kind: "timeline",
        score: result.score,
        accuracy: result.accuracy,
        details: {
          perfect: result.perfect,
          roundSize: result.total,
          difficulty: result.difficulty,
          fingerprint: result.fingerprint,
          topicId: result.correctOrder.map(({ id }) => id).sort().join("|")
        }
      });
      recentFingerprints = [result.fingerprint, ...recentFingerprints].slice(0, 100);
      screen.innerHTML = renderResult(mode, result);
      requestAnimationFrame(() => screen.querySelector(".timeline-summary h1")?.focus({ preventScroll: true }));
    }
    if (action === "timeline-restart") {
      onFeedback("tap");
      start(selectedDifficulty);
    }
    if (action === "timeline-change-size") {
      onFeedback("tap");
      renderSetupScreen();
    }
  });

  screen.addEventListener("pointerdown", (event) => {
    const handle = event.target.closest("[data-timeline-grab]");
    if (!handle || !session || event.pointerType === "mouse" || event.isPrimary === false) return;
    const card = handle.closest("[data-event-id]");
    touchDrag = {
      pointerId: event.pointerId,
      id: handle.dataset.id,
      startY: event.clientY,
      deltaY: 0,
      card,
      handle
    };
    handle.setPointerCapture?.(event.pointerId);
    card.classList.add("is-touch-dragging");
  });

  screen.addEventListener("pointermove", (event) => {
    if (!touchDrag || event.pointerId !== touchDrag.pointerId) return;
    touchDrag.deltaY = event.clientY - touchDrag.startY;
    const visualOffset = Math.max(-96, Math.min(96, touchDrag.deltaY));
    touchDrag.card.style.setProperty("--touch-drag-y", `${visualOffset}px`);
    event.preventDefault();
  });

  screen.addEventListener("pointerup", (event) => {
    if (!touchDrag || event.pointerId !== touchDrag.pointerId) return;
    const { id, deltaY, handle } = touchDrag;
    handle.releasePointerCapture?.(event.pointerId);
    clearTouchDrag();
    if (Math.abs(deltaY) < 36) return;

    const currentIds = session.getSnapshot().events.map(({ id: eventId }) => eventId);
    const reorderedIds = reorderForTouch(currentIds, id, deltaY);
    if (reorderedIds.every((eventId, index) => eventId === currentIds[index])) return;
    session.setOrder(reorderedIds);
    onFeedback("tap");
    renderActive(id);
  });

  screen.addEventListener("pointercancel", clearTouchDrag);

  screen.addEventListener("dragstart", (event) => {
    const card = event.target.closest("[data-event-id]");
    if (!card || !session) return;
    draggedId = card.dataset.eventId;
    card.classList.add("is-dragging");
    event.dataTransfer.effectAllowed = "move";
  });

  screen.addEventListener("dragend", (event) => {
    event.target.closest("[data-event-id]")?.classList.remove("is-dragging");
    draggedId = null;
  });

  screen.addEventListener("dragover", (event) => {
    if (draggedId && event.target.closest("[data-event-id]")) event.preventDefault();
  });

  screen.addEventListener("drop", (event) => {
    const targetCard = event.target.closest("[data-event-id]");
    if (!draggedId || !targetCard || draggedId === targetCard.dataset.eventId) return;
    event.preventDefault();
    const ids = session.getSnapshot().events.map(({ id }) => id);
    const from = ids.indexOf(draggedId);
    const to = ids.indexOf(targetCard.dataset.eventId);
    ids.splice(to, 0, ids.splice(from, 1)[0]);
    session.setOrder(ids);
    const movedId = draggedId;
    draggedId = null;
    onFeedback("tap");
    renderActive(movedId);
  });

  start(selectedDifficulty);
  return screen;
}
