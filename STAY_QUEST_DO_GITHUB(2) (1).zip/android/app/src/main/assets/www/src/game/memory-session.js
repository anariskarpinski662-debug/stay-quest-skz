import { sampleWithoutReplacement, shuffle } from "./random.js";

const PAIR_BUILDERS = Object.freeze({
  "symbol-skzoo": (item) => [
    { faceType: "symbol", value: item.emoji },
    { faceType: "skzoo", value: item.skzoo }
  ],
  "skzoo-member": (item) => [
    { faceType: "skzoo", value: item.skzoo },
    { faceType: "member", value: item.name }
  ],
  "member-birth": (item) => [
    { faceType: "member", value: item.name },
    { faceType: "detail", value: item.birthDate }
  ],
  "skzoo-birth": (item) => [
    { faceType: "skzoo", value: item.skzoo },
    { faceType: "detail", value: item.birthDate }
  ],
  "member-order": (item) => [
    { faceType: "member", value: item.name },
    { faceType: "detail", value: item.birthOrder }
  ]
});

function clone(value) {
  return structuredClone(value);
}

export function validateMemoryItems(items) {
  const errors = [];
  if (!Array.isArray(items) || items.length < 4) return { valid: false, errors: ["Memory wymaga co najmniej czterech par."] };

  const ids = new Set();
  items.forEach((item, index) => {
    if (!item?.id || !item?.name || !item?.skzoo || !item?.emoji || !item?.birthDate || !item?.birthOrder) {
      errors.push(`Para ${index + 1} ma niepełne dane.`);
    }
    if (ids.has(item?.id)) errors.push(`Powtórzony identyfikator pary: ${item.id}.`);
    ids.add(item?.id);
  });
  return { valid: errors.length === 0, errors };
}

export function createMemorySession({
  items,
  pairCount = 8,
  pairType = "symbol-skzoo",
  difficulty = 1,
  moveTarget = null,
  recentFingerprints = [],
  repeatMultiplier = 1,
  random = Math.random,
  now = Date.now
}) {
  const validation = validateMemoryItems(items);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (![4, 6, 8].includes(pairCount)) throw new RangeError("Plansza może zawierać 4, 6 albo 8 par.");
  if (!PAIR_BUILDERS[pairType]) throw new RangeError("Nieznany rodzaj par Memory.");
  if (!Number.isInteger(Number(difficulty)) || Number(difficulty) < 1 || Number(difficulty) > 5) throw new RangeError("Poziom Memory musi wynosić od 1 do 5.");
  if (pairCount > items.length) throw new RangeError("Brakuje postaci do utworzenia planszy.");
  if (moveTarget !== null && (!Number.isInteger(moveTarget) || moveTarget < pairCount)) {
    throw new RangeError("Cel ruchów nie może być mniejszy od liczby par.");
  }
  if (!Number.isFinite(repeatMultiplier) || repeatMultiplier <= 0 || repeatMultiplier > 1) throw new RangeError("Nieprawidłowy mnożnik powtórki.");

  let selected = sampleWithoutReplacement(items, pairCount, random);
  let fingerprint = `${pairType}:${selected.map(({ id }) => id).sort().join("|")}`;
  for (let attempt = 0; recentFingerprints.includes(fingerprint) && attempt < 8; attempt += 1) {
    selected = sampleWithoutReplacement(items, pairCount, random);
    fingerprint = `${pairType}:${selected.map(({ id }) => id).sort().join("|")}`;
  }
  const previousOccurrences = recentFingerprints.filter((entry) => entry === fingerprint).length;
  const effectiveRepeatMultiplier = repeatMultiplier < 1
    ? repeatMultiplier
    : previousOccurrences >= 3
      ? 0.35
      : previousOccurrences === 2
        ? 0.5
        : previousOccurrences === 1
          ? 0.75
          : 1;

  const cards = shuffle(
    selected.flatMap((item) => PAIR_BUILDERS[pairType](item).map((face, index) => ({
      id: `${item.id}-${pairType}-${index}`,
      pairId: item.id,
      ...face,
      matched: false,
      faceUp: false
    }))),
    random
  );

  let activeStartedAt = now();
  let accumulatedActiveMs = 0;
  let paused = false;
  let status = "active";
  let locked = false;
  let pendingMismatch = [];
  let moves = 0;
  let wrongAttempts = 0;
  let pairsFound = 0;

  function pause() {
    if (status !== "active" || paused) return getSnapshot();
    accumulatedActiveMs += Math.max(0, now() - activeStartedAt);
    paused = true;
    return getSnapshot();
  }

  function resume() {
    if (status !== "active" || !paused) return getSnapshot();
    activeStartedAt = now();
    paused = false;
    return getSnapshot();
  }

  function activeMilliseconds() {
    return accumulatedActiveMs + (status === "active" && !paused ? Math.max(0, now() - activeStartedAt) : 0);
  }

  function elapsedSeconds() {
    return Math.max(0, Math.round(activeMilliseconds() / 1000));
  }

  function visibleCard(card) {
    const visible = card.faceUp || card.matched;
    return {
      id: card.id,
      matched: card.matched,
      faceUp: card.faceUp,
      faceType: visible ? card.faceType : null,
      value: visible ? card.value : null
    };
  }

  function calculateScore() {
    const numericDifficulty = Number(difficulty);
    const base = [0, 100, 140, 200, 260, 320][numericDifficulty];
    const extraMoves = Math.max(0, moves - pairCount);
    const efficiencyBonus = Math.max(0, pairCount * 10 - extraMoves * 10);
    const challengeBonus = moveTarget !== null && moves <= moveTarget ? 30 : 0;
    const smallTimeBonus = Math.max(0, 20 - Math.floor(elapsedSeconds() / 15));
    return Math.max(40, Math.round((base + efficiencyBonus + challengeBonus + smallTimeBonus) * effectiveRepeatMultiplier));
  }

  function getSnapshot() {
    return {
      status,
      paused,
      locked,
      pairCount,
      pairType,
      difficulty: Number(difficulty),
      moveTarget,
      moves,
      wrongAttempts,
      pairsFound,
      fingerprint,
      elapsedSeconds: elapsedSeconds(),
      score: status === "complete" ? calculateScore() : 0,
      cards: cards.map(visibleCard)
    };
  }

  function flip(cardId) {
    if (status === "complete") return { type: "complete", snapshot: getSnapshot() };
    if (paused) resume();
    if (locked) return { type: "locked", snapshot: getSnapshot() };
    const card = cards.find(({ id }) => id === cardId);
    if (!card) throw new TypeError("Nie znaleziono karty.");
    if (card.matched || card.faceUp) return { type: "ignored", snapshot: getSnapshot() };

    card.faceUp = true;
    const openCards = cards.filter((candidate) => candidate.faceUp && !candidate.matched);
    if (openCards.length === 1) return { type: "first", cardId, snapshot: getSnapshot() };

    moves += 1;
    const [first, second] = openCards;
    if (first.pairId === second.pairId) {
      first.matched = true;
      second.matched = true;
      pairsFound += 1;

      if (pairsFound === pairCount) {
        accumulatedActiveMs = activeMilliseconds();
        paused = true;
        status = "complete";
      }
      return { type: "match", cardIds: [first.id, second.id], snapshot: getSnapshot() };
    }

    wrongAttempts += 1;
    locked = true;
    pendingMismatch = [first.id, second.id];
    return { type: "mismatch", cardIds: clone(pendingMismatch), snapshot: getSnapshot() };
  }

  function concealMismatch() {
    if (!locked) return getSnapshot();
    cards.forEach((card) => {
      if (pendingMismatch.includes(card.id)) card.faceUp = false;
    });
    pendingMismatch = [];
    locked = false;
    return getSnapshot();
  }

  function getSummary() {
    return {
      status,
      pairCount,
      pairType,
      difficulty: Number(difficulty),
      moveTarget,
      moves,
      wrongAttempts,
      pairsFound,
      fingerprint,
      repeatMultiplier: effectiveRepeatMultiplier,
      elapsedSeconds: elapsedSeconds(),
      score: status === "complete" ? calculateScore() : 0
    };
  }

  return { getSnapshot, getSummary, flip, concealMismatch, pause, resume };
}
