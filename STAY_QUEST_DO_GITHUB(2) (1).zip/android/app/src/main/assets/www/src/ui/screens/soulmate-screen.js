import { createSoulmateSession } from "../../game/soulmate-session.js";
import { escapeHtml } from "../html.js";

function renderSetup(mode, previousResult) {
  const previous = previousResult?.topMatches?.[0]
    ? `<p class="lab-previous">Poprzednie dopasowanie: <strong>${escapeHtml(previousResult.topMatches[0].emoji)} ${escapeHtml(previousResult.topMatches[0].name)} — ${previousResult.topMatches[0].percentage}%</strong></p>`
    : "";
  return `
    <a class="back-link" href="#/home">← Wróć do ekranu głównego</a>
    <section class="lab-hero">
      <span class="lab-hero__icon" aria-hidden="true">💞</span>
      <p class="eyebrow">STAY Lab • dla zabawy</p>
      <h1 tabindex="-1">Kto jest Twoją bratnią duszą?</h1>
      <p>Odpowiedz na 25 sytuacyjnych pytań. Nie ma dobrych ani złych odpowiedzi, a podczas zabawy nie zobaczysz, do kogo prowadzą wybory.</p>
      <aside class="lab-disclaimer"><strong>Ważne:</strong> to zabawa fandomowa, nie prawdziwy test psychologiczny ani ocena charakteru członków.</aside>
      ${previous}
      <button class="button button--primary button--wide" type="button" data-action="soul-start">Rozpocznij zabawę</button>
    </section>
  `;
}

function renderQuestion(snapshot) {
  const question = snapshot.currentQuestion;
  const progress = Math.round((snapshot.answeredQuestions / snapshot.totalQuestions) * 100);
  return `
    <a class="back-link" href="#/mode/soulmate-lab">← Zakończ zabawę</a>
    <section class="lab-progress">
      <div><span>Pytanie <strong>${snapshot.questionNumber}/${snapshot.totalQuestions}</strong></span><span>Bez punktów • bez błędów</span></div>
      <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}"><span style="width:${progress}%"></span></div>
    </section>
    <article class="lab-question">
      <p class="eyebrow">Wybierz odpowiedź najbliższą Tobie</p>
      <h1 tabindex="-1">${escapeHtml(question.prompt)}</h1>
      <div class="lab-options" role="group" aria-label="Odpowiedzi">
        ${question.options.map((option, index) => `
          <button type="button" data-action="soul-answer" data-option-id="${escapeHtml(option.id)}">
            <span aria-hidden="true">${String.fromCharCode(65 + index)}</span>
            <strong>${escapeHtml(option.label)}</strong>
          </button>
        `).join("")}
      </div>
    </article>
  `;
}

function renderMatch(match, position) {
  return `
    <article class="soul-match${position === 1 ? " is-first" : ""}">
      <span class="soul-match__position">${String(position).padStart(2, "0")}</span>
      <span class="soul-match__emoji" aria-hidden="true">${escapeHtml(match.emoji)}</span>
      <div class="soul-match__copy">
        <h2>${escapeHtml(match.name)}</h2>
        <p>Najbardziej zbliżyły Was: ${escapeHtml(match.reasons.join(", "))}.</p>
      </div>
      <strong class="soul-match__percentage">${match.percentage}%</strong>
    </article>
  `;
}

function renderResult(result) {
  const winner = result.topMatches[0];
  return `
    <a class="back-link" href="#/home">← Wróć do ekranu głównego</a>
    <section class="soul-summary">
      <span class="soul-summary__emoji" aria-hidden="true">${escapeHtml(winner.emoji)}</span>
      <p class="eyebrow">Fandomowe dopasowanie ukończone</p>
      <h1 tabindex="-1">Twoja bratnia dusza: ${escapeHtml(winner.name)}</h1>
      <p>Algorytm porównał Twoje odpowiedzi z zabawowymi profilami całej ósemki. Oto trzy najbliższe wyniki.</p>
      <div class="soul-matches">${result.topMatches.map((match, index) => renderMatch(match, index + 1)).join("")}</div>
      <aside class="lab-disclaimer">Wynik służy wyłącznie fandomowej zabawie. Powtórka losuje inny zestaw z pełnej puli.</aside>
      <button class="button button--primary button--wide" type="button" data-action="soul-restart">Wylosuj nową sesję</button>
      <a class="button button--secondary button--wide" href="#/home">Wróć do gry</a>
    </section>
  `;
}

export function createSoulmateScreen({ mode, questions, members, previousResult = null, onComplete = () => {}, onFeedback = () => {} }) {
  const screen = document.createElement("div");
  screen.className = "screen soulmate-screen";
  let session = null;

  function setup() {
    session = null;
    screen.innerHTML = renderSetup(mode, previousResult);
    requestAnimationFrame(() => screen.querySelector("h1")?.focus({ preventScroll: true }));
  }

  function start() {
    session = createSoulmateSession({ questions, members, questionCount: 25 });
    screen.innerHTML = renderQuestion(session.getSnapshot());
    requestAnimationFrame(() => screen.querySelector(".lab-question h1")?.focus({ preventScroll: true }));
  }

  screen.addEventListener("click", (event) => {
    const target = event.target.closest("[data-action]");
    const action = target?.dataset.action;
    if (!action) return;
    if (action === "soul-start" || action === "soul-restart") {
      onFeedback("tap");
      start();
    }
    if (action === "soul-answer" && session) {
      onFeedback("tap");
      const snapshot = session.answer(target.dataset.optionId);
      if (snapshot.status === "complete") {
        const result = session.getResult();
        onComplete(result);
        screen.innerHTML = renderResult(result);
        requestAnimationFrame(() => screen.querySelector(".soul-summary h1")?.focus({ preventScroll: true }));
      } else {
        screen.innerHTML = renderQuestion(snapshot);
        requestAnimationFrame(() => screen.querySelector(".lab-question h1")?.focus({ preventScroll: true }));
      }
    }
  });

  setup();
  return screen;
}
