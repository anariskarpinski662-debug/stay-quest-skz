import { sampleWithoutReplacement, shuffle } from "./random.js";

function clone(value) {
  return structuredClone(value);
}

function isValidDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

export function validateTimelineEvents(events) {
  const errors = [];
  if (!Array.isArray(events) || events.length < 2) return { valid: false, errors: ["Oś czasu wymaga co najmniej dwóch wydarzeń."] };

  const ids = new Set();
  for (const [index, event] of events.entries()) {
    if (!event?.id || !event?.title || !event?.description || !event?.era) errors.push(`Wydarzenie ${index + 1} ma niepełne dane.`);
    if (!isValidDate(event?.date)) errors.push(`Wydarzenie ${index + 1} ma nieprawidłową datę.`);
    if (ids.has(event?.id)) errors.push(`Powtórzony identyfikator wydarzenia: ${event.id}.`);
    ids.add(event?.id);
    if (!event?.source?.title || !/^https?:\/\//.test(event?.source?.url) || !isValidDate(event?.source?.checkedAt)) {
      errors.push(`Wydarzenie ${index + 1} nie ma poprawnego źródła.`);
    }
  }

  return { valid: errors.length === 0, errors };
}

function formatDateHint(event, difficulty, index) {
  if (difficulty === 1) return event.date;
  if (difficulty === 2) return event.date.slice(0, 7);
  if (difficulty === 3) return event.date.slice(0, 4);
  if (difficulty === 4 && index % 2 === 0) return event.date.slice(0, 4);
  return null;
}

function selectEvents(events, roundSize, difficulty, random) {
  const ordered = [...events].sort((a, b) => a.date.localeCompare(b.date));
  if (difficulty === 1) {
    const step = (ordered.length - 1) / Math.max(1, roundSize - 1);
    return Array.from({ length: roundSize }, (_, index) => ordered[Math.round(index * step)]);
  }
  if (difficulty === 2) {
    const broadWindow = sampleWithoutReplacement(ordered, Math.min(ordered.length, roundSize * 2), random)
      .sort((a, b) => a.date.localeCompare(b.date));
    const step = (broadWindow.length - 1) / Math.max(1, roundSize - 1);
    return Array.from({ length: roundSize }, (_, index) => broadWindow[Math.round(index * step)]);
  }
  if (difficulty === 3) return sampleWithoutReplacement(events, roundSize, random);

  const extra = difficulty === 4 ? 5 : 0;
  const windowSize = Math.min(ordered.length, roundSize + extra);
  const maxStart = ordered.length - windowSize;
  const start = maxStart > 0 ? Math.floor(random() * (maxStart + 1)) : 0;
  const window = ordered.slice(start, start + windowSize);
  return difficulty === 5 ? window.slice(0, roundSize) : sampleWithoutReplacement(window, roundSize, random);
}

export function createTimelineSession({ events, setTemplates = [], roundSize = 6, difficulty = "mixed", recentSetFingerprints = [], random = Math.random }) {
  const validation = validateTimelineEvents(events);
  if (!validation.valid) throw new TypeError(validation.errors.join(" "));
  if (![4, 6, 8].includes(roundSize)) throw new RangeError("Dozwolone rundy mają 4, 6 albo 8 wydarzeń.");
  if (roundSize > events.length) throw new RangeError("Bank nie zawiera wystarczającej liczby wydarzeń.");

  if (difficulty !== "mixed" && (!Number.isInteger(Number(difficulty)) || Number(difficulty) < 1 || Number(difficulty) > 5)) {
    throw new RangeError("Poziom Timeline musi wynosić od 1 do 5.");
  }
  const numericDifficulty = difficulty === "mixed" ? 3 : Number(difficulty);
  const byId = new Map(events.map((event) => [event.id, event]));
  const matchingTemplates = setTemplates.filter((template) =>
    template.difficulty === numericDifficulty
    && template.eventIds.length === roundSize
    && template.eventIds.every((id) => byId.has(id))
  );
  const templatePool = shuffle(matchingTemplates, random);
  const freshTemplate = templatePool.find((template) => !recentSetFingerprints.includes(template.eventIds.slice().sort().join("|")));
  let selected = (freshTemplate ?? templatePool[0])?.eventIds.map((id) => byId.get(id))
    ?? selectEvents(events, roundSize, numericDifficulty, random);
  let fingerprint = selected.map(({ id }) => id).sort().join("|");
  for (let attempt = 0; recentSetFingerprints.includes(fingerprint) && attempt < 8; attempt += 1) {
    selected = selectEvents(events, roundSize, numericDifficulty, random);
    fingerprint = selected.map(({ id }) => id).sort().join("|");
  }
  const correctOrder = [...selected].sort((a, b) => a.date.localeCompare(b.date));
  let userOrder = shuffle(selected, random);
  if (userOrder.every((event, index) => event.id === correctOrder[index].id)) {
    userOrder = [...userOrder.slice(1), userOrder[0]];
  }
  let status = "active";
  let result = null;

  function getSnapshot() {
    return {
      status,
      roundSize,
      difficulty: numericDifficulty,
      fingerprint,
      events: userOrder.map((event) => ({
        id: event.id,
        title: event.title,
        description: event.description,
        era: event.era,
        dateHint: formatDateHint(event, numericDifficulty, correctOrder.findIndex(({ id }) => id === event.id))
      })),
      result: result ? clone(result) : null
    };
  }

  function setOrder(ids) {
    if (status !== "active") throw new Error("Ta runda została już sprawdzona.");
    if (!Array.isArray(ids) || ids.length !== userOrder.length || new Set(ids).size !== ids.length) {
      throw new TypeError("Nowa kolejność musi zawierać wszystkie wydarzenia dokładnie raz.");
    }
    const byId = new Map(userOrder.map((event) => [event.id, event]));
    if (ids.some((id) => !byId.has(id))) throw new TypeError("Nowa kolejność zawiera nieznane wydarzenie.");
    userOrder = ids.map((id) => byId.get(id));
    return getSnapshot();
  }

  function move(eventId, direction) {
    if (![-1, 1].includes(direction)) throw new RangeError("Kierunek przesunięcia musi wynosić -1 albo 1.");
    const currentIndex = userOrder.findIndex(({ id }) => id === eventId);
    if (currentIndex === -1) throw new TypeError("Nie znaleziono wydarzenia.");
    const targetIndex = currentIndex + direction;
    if (targetIndex < 0 || targetIndex >= userOrder.length) return getSnapshot();
    const ids = userOrder.map(({ id }) => id);
    [ids[currentIndex], ids[targetIndex]] = [ids[targetIndex], ids[currentIndex]];
    return setOrder(ids);
  }

  function check() {
    if (status !== "active") throw new Error("Ta runda została już sprawdzona.");
    const correctPositions = userOrder.filter((event, index) => event.id === correctOrder[index].id).length;
    const perfect = correctPositions === roundSize;
    const perPosition = [0, 25, 30, 35, 45, 55][numericDifficulty];
    const perfectBonus = [0, 40, 60, 90, 130, 180][numericDifficulty];
    const score = correctPositions * perPosition + (perfect ? perfectBonus : 0);

    result = {
      perfect,
      score,
      correctPositions,
      total: roundSize,
      accuracy: Math.round((correctPositions / roundSize) * 100),
      difficulty: numericDifficulty,
      fingerprint,
      correctOrder: correctOrder.map((event, index) => ({
        ...clone(event),
        correctPosition: index + 1,
        userPosition: userOrder.findIndex(({ id }) => id === event.id) + 1
      }))
    };
    status = "complete";
    return clone(result);
  }

  return { getSnapshot, setOrder, move, check };
}
