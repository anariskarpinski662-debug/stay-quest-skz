import test from "node:test";
import assert from "node:assert/strict";
import { GAME_MODES, findGameMode } from "../src/data/game-modes.js";
import { MEMBER_SYMBOLS } from "../src/data/member-symbols.js";

test("aplikacja udostępnia osiem unikalnych trybów", () => {
  assert.equal(GAME_MODES.length, 8);
  assert.equal(new Set(GAME_MODES.map(({ id }) => id)).size, GAME_MODES.length);
});

test("każdy tryb ma dane potrzebne ekranowi głównemu", () => {
  for (const mode of GAME_MODES) {
    assert.ok(mode.id);
    assert.ok(mode.name);
    assert.ok(mode.description);
    assert.ok(mode.reward > 0);
    assert.ok(mode.implementation.length >= 3);
    assert.equal(findGameMode(mode.id), mode);
  }
});

test("linia członków zawiera osiem unikalnych wpisów", () => {
  assert.equal(MEMBER_SYMBOLS.length, 8);
  assert.equal(new Set(MEMBER_SYMBOLS.map(({ id }) => id)).size, 8);
  assert.ok(MEMBER_SYMBOLS.every(({ name, skzoo, emoji }) => name && skzoo && emoji));
});
