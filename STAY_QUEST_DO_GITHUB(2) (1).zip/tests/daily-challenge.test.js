import test from "node:test";
import assert from "node:assert/strict";
import { createDailyQuestions } from "../src/data/daily-challenge.js";
import { validateQuestionBank } from "../src/game/question-schema.js";

test("Daily Challenge tworzy dziesięć poprawnych zadań", () => {
  const questions = createDailyQuestions("2026-08-19");

  assert.equal(questions.length, 10);
  assert.equal(new Set(questions.map(({ id }) => id)).size, 10);
  assert.ok(questions.every(({ modeId }) => modeId === "daily-challenge"));
  assert.deepEqual(validateQuestionBank(questions), { valid: true, errors: [] });
});

test("zestaw Daily jest identyczny dla tej samej daty", () => {
  const first = createDailyQuestions("2026-08-19");
  const second = createDailyQuestions("2026-08-19");
  const nextDay = createDailyQuestions("2026-08-20");

  assert.deepEqual(second, first);
  assert.notDeepEqual(nextDay.map(({ id }) => id), first.map(({ id }) => id));
});
