import test from "node:test";
import assert from "node:assert/strict";
import { TIMELINE_EVENTS, TIMELINE_SET_TEMPLATES } from "../src/data/timeline-events.js";
import { createTimelineSession, validateTimelineEvents } from "../src/game/timeline-session.js";
import { createSeededRandom } from "../src/game/random.js";

test("pełny bank osi czasu ma unikalne wydarzenia i poprawne źródła", () => {
  const validation = validateTimelineEvents(TIMELINE_EVENTS);
  assert.deepEqual(validation, { valid: true, errors: [] });
  assert.ok(TIMELINE_EVENTS.length >= 30);
  assert.equal(TIMELINE_SET_TEMPLATES.length, 40);
});

test("aktywna runda nie ujawnia dat przed sprawdzeniem", () => {
  const session = createTimelineSession({
    events: TIMELINE_EVENTS,
    roundSize: 4,
    random: createSeededRandom(7)
  });
  const event = session.getSnapshot().events[0];

  assert.equal("date" in event, false);
  assert.equal("source" in event, false);
});

test("ustawienie prawidłowej kolejności daje komplet punktów", () => {
  const session = createTimelineSession({
    events: TIMELINE_EVENTS,
    roundSize: 6,
    random: createSeededRandom(11)
  });
  const dateById = new Map(TIMELINE_EVENTS.map((event) => [event.id, event.date]));
  const correctIds = session
    .getSnapshot()
    .events.map(({ id }) => id)
    .sort((a, b) => dateById.get(a).localeCompare(dateById.get(b)));

  session.setOrder(correctIds);
  const result = session.check();

  assert.equal(result.perfect, true);
  assert.equal(result.correctPositions, 6);
  assert.equal(result.score, 300);
  assert.ok(result.correctOrder.every(({ date, source }) => date && source));
});

test("przyciski przesuwają wydarzenie tylko o jedną pozycję", () => {
  const session = createTimelineSession({
    events: TIMELINE_EVENTS,
    roundSize: 4,
    random: createSeededRandom(15)
  });
  const before = session.getSnapshot().events.map(({ id }) => id);
  session.move(before[1], -1);
  const after = session.getSnapshot().events.map(({ id }) => id);

  assert.equal(after[0], before[1]);
  assert.equal(after[1], before[0]);
});
