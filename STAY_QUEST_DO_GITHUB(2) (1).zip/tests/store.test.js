import test from "node:test";
import assert from "node:assert/strict";
import { createStore, LEGACY_BACKUP_KEY, LEGACY_STORAGE_KEYS, STATE_VERSION, STORAGE_KEY } from "../src/app/store.js";

class MemoryStorage {
  constructor(entries = {}) {
    this.values = new Map(Object.entries(entries));
  }

  getItem(key) {
    return this.values.get(key) ?? null;
  }

  setItem(key, value) {
    this.values.set(key, String(value));
  }
}

const fixedDate = () => new Date("2026-08-19T12:00:00.000Z");

function result() {
  return {
    modeId: "emoji-guesser",
    kind: "quiz",
    score: 750,
    accuracy: 80,
    longestStreak: 4,
    currentStreak: 2,
    correctAnswers: 8,
    totalQuestions: 10,
    details: {}
  };
}

test("stary zapis v1 jest bezpiecznie migrowany do pełnego stanu", () => {
  const storage = new MemoryStorage({
    [STORAGE_KEY]: JSON.stringify({
      player: { displayName: "Anaris", totalPoints: 600, level: 99, currentStreak: 3 },
      settings: { soundEnabled: false, reducedMotion: true }
    })
  });
  const state = createStore({ storage, now: fixedDate }).getState();

  assert.equal(state.schemaVersion, STATE_VERSION);
  assert.equal(state.player.displayName, "Anaris");
  assert.equal(state.player.level, 1);
  assert.equal(state.player.bestStreak, 3);
  assert.equal(state.settings.soundEnabled, false);
  assert.equal(state.settings.hapticsEnabled, true);
  assert.equal(state.settings.highContrast, false);
  assert.equal(Object.keys(state.records).length, 8);
});

test("obecny profil Master STAY zachowuje 11076 punktów po aktualizacji", () => {
  const storage = new MemoryStorage({
    [STORAGE_KEY]: JSON.stringify({
      schemaVersion: 3,
      player: { displayName: "Anaris", totalPoints: 11076, level: 5, rank: "Master STAY", bestStreak: 10 },
      stats: { gamesPlayed: 15, correctAnswers: 27, totalAnswers: 40, completedModes: ["assoc-master", "emoji-guesser", "timeline", "hardcore-lore", "skzoo-memory"] },
      records: {},
      achievements: { unlocked: [] },
      history: [],
      settings: { soundEnabled: true, hapticsEnabled: true, reducedMotion: false, highContrast: false, textScale: "standard" }
    })
  });
  const state = createStore({ storage, now: fixedDate }).getState();

  assert.equal(state.player.displayName, "Anaris");
  assert.equal(state.player.totalPoints, 11076);
  assert.equal(state.player.level, 5);
  assert.equal(state.player.rank, "Master STAY");
  assert.equal(state.stats.gamesPlayed, 15);
});

test("uszkodzony bieżący zapis nie zasłania poprawnego starszego progresu", () => {
  const legacyKey = LEGACY_STORAGE_KEYS[0];
  const storage = new MemoryStorage({
    [STORAGE_KEY]: "{uszkodzony-json",
    [legacyKey]: JSON.stringify({ displayName: "Anaris", points: 11076, stats: { gamesPlayed: 15 } })
  });
  const store = createStore({ storage, now: fixedDate });
  const state = store.getState();

  assert.equal(state.player.displayName, "Anaris");
  assert.equal(state.player.totalPoints, 11076);
  assert.equal(state.migration.sourceKey, legacyKey);
  assert.ok(storage.getItem(LEGACY_BACKUP_KEY));
  assert.equal(JSON.parse(storage.getItem(STORAGE_KEY)).player.totalPoints, 11076);
});

test("migracja wybiera zapis z największym progresem i nie usuwa starych kluczy", () => {
  const [firstKey, secondKey] = LEGACY_STORAGE_KEYS;
  const storage = new MemoryStorage({
    [STORAGE_KEY]: JSON.stringify({ player: { totalPoints: 3200 } }),
    [firstKey]: JSON.stringify({ player: { totalPoints: 11076 } }),
    [secondKey]: JSON.stringify({ player: { totalPoints: 4579 } })
  });
  const state = createStore({ storage, now: fixedDate }).getState();

  assert.equal(state.player.totalPoints, 11076);
  assert.ok(storage.getItem(firstKey));
  assert.ok(storage.getItem(secondKey));
});

test("ukończona runda jest zapisana i wraca po ponownym utworzeniu sklepu", () => {
  const storage = new MemoryStorage();
  const store = createStore({ storage, now: fixedDate });
  const saved = store.recordResult(result());
  const restored = createStore({ storage, now: fixedDate }).getState();

  assert.equal(saved.saved, true);
  assert.equal(restored.player.totalPoints, 750);
  assert.equal(restored.records["emoji-guesser"].plays, 1);
  assert.equal(restored.history.length, 1);
});

test("profil i ustawienia są normalizowane przed zapisem", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.updateProfile("  Anaris\nSTAY  ");
  store.updateSettings({ textScale: "gigantic", highContrast: true });
  const state = store.getState();

  assert.equal(state.player.displayName, "Anaris STAY");
  assert.equal(state.settings.textScale, "standard");
  assert.equal(state.settings.highContrast, true);
});

test("eksport i import odtwarzają kopię postępu", () => {
  const original = createStore({ storage: new MemoryStorage(), now: fixedDate });
  original.updateProfile("Anaris");
  original.recordResult(result());
  const backup = original.exportBackup();

  const restored = createStore({ storage: new MemoryStorage(), now: fixedDate });
  restored.importBackup(backup);
  assert.equal(restored.getState().player.displayName, "Anaris");
  assert.equal(restored.getState().player.totalPoints, 750);
  assert.throws(() => restored.importBackup("nie-json"), /poprawnej kopii/);
});

test("zwykły import starszej kopii nie obniża automatycznie liczby punktów", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.recordResult(result());
  store.importBackup(JSON.stringify({
    appId: "stay-quest",
    state: { ...store.getState(), player: { ...store.getState().player, totalPoints: 10 } }
  }));

  assert.equal(store.getState().player.totalPoints, 750);
});

test("reset usuwa postęp, ale pozostawia poprawny schemat", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.recordResult(result());
  store.reset();

  assert.equal(store.getState().player.totalPoints, 0);
  assert.equal(store.getState().stats.gamesPlayed, 0);
  assert.equal(store.getState().schemaVersion, STATE_VERSION);
});

test("Daily nalicza punkty tylko raz danego dnia", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  const dailyResult = {
    ...result(),
    modeId: "daily-challenge",
    score: 500,
    correctAnswers: 7,
    totalQuestions: 10,
    details: { questionIds: ["daily-a", "daily-b"] }
  };

  const first = store.recordDailyResult(dailyResult, "2026-08-19");
  const second = store.recordDailyResult(dailyResult, "2026-08-19");

  assert.equal(first.alreadyRecorded, false);
  assert.equal(second.alreadyRecorded, true);
  assert.equal(store.getState().player.totalPoints, 500);
  assert.equal(store.getState().daily.completedDates.length, 1);
  assert.equal(store.getState().records["daily-challenge"].plays, 1);
});

test("Bratnia Dusza daje odznakę, ale nie daje zwykłych punktów", () => {
  const store = createStore({ storage: new MemoryStorage(), now: fixedDate });
  store.recordSoulmateResult({ topMatches: [{ id: "felix", name: "Felix", percentage: 82 }] });
  const state = store.getState();

  assert.equal(state.player.totalPoints, 0);
  assert.equal(state.soulmate.completedCount, 1);
  assert.ok(state.achievements.unlocked.some(({ id }) => id === "soul-connection"));
});
