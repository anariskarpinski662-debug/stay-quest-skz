import test from "node:test";
import assert from "node:assert/strict";
import { createQuizSession } from "../src/game/quiz-session.js";
import { QUESTION_TYPES } from "../src/game/question-schema.js";
import { createSeededRandom } from "../src/game/random.js";
import { getQuizQuestions } from "../src/data/question-bank.js";

const questions = [
  {
    id: "q1",
    modeId: "demo",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Wybierz A.",
    category: "Test",
    kind: "puzzle_interpretation",
    difficulty: 1,
    basePoints: 100,
    options: [
      { id: "a", label: "A" },
      { id: "b", label: "B" }
    ],
    correctOptionId: "a",
    hint: "Pierwsza litera alfabetu.",
    explanation: "A jest poprawną odpowiedzią."
  },
  {
    id: "q2",
    modeId: "demo",
    type: QUESTION_TYPES.SINGLE_CHOICE,
    prompt: "Wybierz B.",
    category: "Test",
    kind: "puzzle_interpretation",
    difficulty: 2,
    basePoints: 100,
    options: [
      { id: "a", label: "A" },
      { id: "b", label: "B" }
    ],
    correctOptionId: "b",
    explanation: "B jest poprawną odpowiedzią."
  },
  {
    id: "q3",
    modeId: "demo",
    type: QUESTION_TYPES.TEXT,
    prompt: "Wpisz God's Menu.",
    category: "Test",
    kind: "puzzle_interpretation",
    difficulty: 1,
    basePoints: 100,
    acceptedAnswers: ["God's Menu", "Gods Menu"],
    displayAnswer: "God's Menu",
    explanation: "To oczekiwana odpowiedź."
  }
];

const correctAnswers = { q1: "a", q2: "b", q3: "gods menu" };

test("sesja nie ujawnia rozwiązania przed odpowiedzią", () => {
  const session = createQuizSession({ modeId: "demo", questions: [questions[0]] });
  const publicQuestion = session.getSnapshot().currentQuestion;

  assert.equal("correctOptionId" in publicQuestion, false);
  assert.equal("acceptedAnswers" in publicQuestion, false);
  assert.equal("explanation" in publicQuestion, false);
  assert.equal(publicQuestion.hasHint, true);
});

test("losowanie całej rundy nie powtarza pytań", () => {
  const session = createQuizSession({
    modeId: "demo",
    questions,
    questionCount: 3,
    random: createSeededRandom(42)
  });
  const seen = [];

  while (session.getSnapshot().status !== "complete") {
    const snapshot = session.getSnapshot();
    seen.push(snapshot.currentQuestion.id);
    session.submitAnswer(correctAnswers[snapshot.currentQuestion.id]);
    session.next();
  }

  assert.equal(seen.length, 3);
  assert.equal(new Set(seen).size, 3);
});

test("poprawna odpowiedź aktualizuje punkty i serię", () => {
  const session = createQuizSession({ modeId: "demo", questions: [questions[0]] });
  const result = session.submitAnswer("a");
  const snapshot = session.getSnapshot();

  assert.equal(result.correct, true);
  assert.equal(result.earnedPoints, 50);
  assert.equal(snapshot.score, 50);
  assert.equal(snapshot.currentStreak, 1);
});

test("użycie podpowiedzi jest widoczne i obniża wynik", () => {
  const session = createQuizSession({ modeId: "demo", questions: [questions[0]] });

  assert.equal(session.useHint(), "Pierwsza litera alfabetu.");
  assert.equal(session.getSnapshot().revealedHint, "Pierwsza litera alfabetu.");
  assert.equal(session.submitAnswer("a").earnedPoints, 42);
});

test("dwa poziomy podpowiedzi mają osobne koszty", () => {
  const twoHintQuestion = {
    ...questions[0],
    hint: undefined,
    hints: [
      { text: "Subtelny trop.", penaltyRate: 0.1 },
      { text: "Mocniejsze zawężenie.", penaltyRate: 0.2 }
    ]
  };
  const session = createQuizSession({ modeId: "demo", questions: [twoHintQuestion] });

  assert.equal(session.useHint(), "Subtelny trop.");
  assert.equal(session.useHint(), "Mocniejsze zawężenie.");
  assert.equal(session.useHint(), null);
  const result = session.submitAnswer("b");
  assert.equal(result.submittedAnswerLabel, "B");
  assert.equal(result.hintsUsed, 2);
});

test("nie można odpowiedzieć dwa razy na to samo pytanie", () => {
  const session = createQuizSession({ modeId: "demo", questions: [questions[0]] });
  session.submitAnswer("a");
  assert.throws(() => session.submitAnswer("a"), /już udzielona/);
});

test("po ostatnim pytaniu sesja tworzy kompletne podsumowanie", () => {
  const session = createQuizSession({ modeId: "demo", questions: [questions[2]] });
  session.submitAnswer("GODS MENU");
  session.next();

  const summary = session.getSummary();
  assert.equal(summary.status, "complete");
  assert.equal(summary.correctAnswers, 1);
  assert.equal(summary.accuracy, 100);
  assert.equal(summary.history.length, 1);
  assert.equal(session.getSnapshot().currentQuestion, null);
});

test("sesja odrzuca pytanie należące do innego trybu", () => {
  assert.throws(
    () => createQuizSession({ modeId: "inny-tryb", questions: [questions[0]] }),
    /innego trybu/
  );
});

test("pełne banki quizowe można ukończyć z wynikiem 100 procent", () => {
  for (const modeId of ["assoc-master", "emoji-guesser", "hardcore-lore", "who-is-who", "discography-builder"]) {
    const bank = getQuizQuestions(modeId);
    const session = createQuizSession({
      modeId,
      questions: bank,
      questionCount: bank.length,
      random: createSeededRandom(2026)
    });

    while (session.getSnapshot().status !== "complete") {
      const questionId = session.getSnapshot().currentQuestion.id;
      const sourceQuestion = bank.find(({ id }) => id === questionId);
      const answer = sourceQuestion.type === QUESTION_TYPES.SINGLE_CHOICE
        ? sourceQuestion.correctOptionId
        : sourceQuestion.acceptedAnswers[0];
      session.submitAnswer(answer);
      session.next();
    }

    assert.equal(session.getSummary().accuracy, 100);
  }
});

test("sesja odsłania tropy pojedynczo i nalicza ich koszt", () => {
  const clueQuestion = {
    ...questions[0],
    id: "clue-question",
    basePoints: 150,
    clues: ["pierwszy", "drugi", "trzeci", "czwarty"],
    cluePolicy: { initialVisible: 2, penaltyPerReveal: 10 }
  };
  const session = createQuizSession({ modeId: "demo", questions: [clueQuestion] });

  assert.deepEqual(session.getSnapshot().currentQuestion.clues, ["pierwszy", "drugi"]);
  assert.equal(session.getSnapshot().currentQuestion.canRevealClue, true);
  assert.deepEqual(session.revealClue(), {
    clue: "trzeci",
    clueIndex: 2,
    penalty: 10,
    remaining: 1
  });
  assert.equal(session.submitAnswer("a").earnedPoints, 65);
});
