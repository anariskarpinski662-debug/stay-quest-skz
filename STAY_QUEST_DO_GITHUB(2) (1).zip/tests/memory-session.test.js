import test from "node:test";
import assert from "node:assert/strict";
import { MEMBER_SYMBOLS } from "../src/data/member-symbols.js";
import { createMemorySession, validateMemoryItems } from "../src/game/memory-session.js";
import { createSeededRandom } from "../src/game/random.js";

test("osiem postaci może utworzyć pełną planszę Memory", () => {
  assert.deepEqual(validateMemoryItems(MEMBER_SYMBOLS), { valid: true, errors: [] });
  const session = createMemorySession({ items: MEMBER_SYMBOLS, pairCount: 8, random: createSeededRandom(3) });
  assert.equal(session.getSnapshot().cards.length, 16);
  assert.ok(session.getSnapshot().cards.every(({ value }) => value === null));
});

test("dwie strony tej samej relacji tworzą parę", () => {
  const session = createMemorySession({ items: MEMBER_SYMBOLS, pairCount: 4, random: createSeededRandom(9) });
  const firstId = session.getSnapshot().cards.find(({ id }) => id.endsWith("-symbol-skzoo-0")).id;
  const secondId = firstId.replace(/-0$/, "-1");

  assert.equal(session.flip(firstId).type, "first");
  assert.equal(session.flip(secondId).type, "match");
  assert.equal(session.getSnapshot().pairsFound, 1);
  assert.equal(session.getSnapshot().moves, 1);
});

test("błędna para blokuje planszę do chwili ponownego zakrycia", () => {
  const session = createMemorySession({ items: MEMBER_SYMBOLS, pairCount: 4, random: createSeededRandom(12) });
  const symbolIds = session.getSnapshot().cards.filter(({ id }) => id.endsWith("-symbol-skzoo-0")).map(({ id }) => id);

  session.flip(symbolIds[0]);
  const mismatch = session.flip(symbolIds[1]);
  assert.equal(mismatch.type, "mismatch");
  assert.equal(session.getSnapshot().locked, true);
  assert.ok(mismatch.snapshot.cards.filter(({ faceUp }) => faceUp).length === 2);

  session.concealMismatch();
  assert.equal(session.getSnapshot().locked, false);
  assert.ok(session.getSnapshot().cards.every(({ faceUp }) => faceUp === false));
});

test("dopasowanie wszystkich par kończy grę i wylicza wynik", () => {
  let time = 0;
  const session = createMemorySession({
    items: MEMBER_SYMBOLS,
    pairCount: 4,
    random: createSeededRandom(22),
    now: () => time
  });
  const symbolIds = session.getSnapshot().cards.filter(({ id }) => id.endsWith("-symbol-skzoo-0")).map(({ id }) => id);

  for (const symbolId of symbolIds) {
    session.flip(symbolId);
    session.flip(symbolId.replace(/-0$/, "-1"));
    time += 1000;
  }

  const summary = session.getSummary();
  assert.equal(summary.status, "complete");
  assert.equal(summary.moves, 4);
  assert.ok(summary.score >= 100 && summary.score < 500);
});

test("licznik Memory mierzy wyłącznie aktywny czas", () => {
  let time = 0;
  const session = createMemorySession({ items: MEMBER_SYMBOLS, pairCount: 4, now: () => time, random: createSeededRandom(5) });

  time = 5000;
  session.pause();
  time = 365000;
  assert.equal(session.getSnapshot().elapsedSeconds, 5);

  session.resume();
  time = 368000;
  assert.equal(session.getSnapshot().elapsedSeconds, 8);
});

test("trudniejsze Memory zmienia rodzaj dopasowania, a nie tylko liczbę kart", () => {
  const session = createMemorySession({
    items: MEMBER_SYMBOLS,
    pairCount: 8,
    pairType: "skzoo-birth",
    difficulty: 5,
    random: createSeededRandom(8)
  });
  const ids = session.getSnapshot().cards.map(({ id }) => id);

  assert.ok(ids.some((id) => id.includes("skzoo-birth")));
  assert.equal(session.getSnapshot().pairType, "skzoo-birth");
});
