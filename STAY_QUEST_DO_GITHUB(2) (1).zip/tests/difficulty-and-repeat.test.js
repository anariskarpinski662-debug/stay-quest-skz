import test from "node:test";
import assert from "node:assert/strict";
import { getQuizQuestions } from "../src/data/question-bank.js";
import { QUESTION_TYPES, normalizeAnswer } from "../src/game/question-schema.js";
import { createSeededRandom } from "../src/game/random.js";
import { selectQuestionRound } from "../src/game/quiz-session.js";

test("wybrany poziom trudności jest niezależny od rangi profilu", () => {
  const bank = getQuizQuestions("who-is-who");
  const selected = selectQuestionRound({
    questions: bank,
    questionCount: 8,
    difficulty: 5,
    random: createSeededRandom(7)
  });

  assert.equal(selected.length, 8);
  assert.ok(selected.every(({ difficulty }) => difficulty === 5));
});

test("świeże pytania mają pierwszeństwo przed ostatnio pokazanymi", () => {
  const bank = getQuizQuestions("discography-builder");
  const recent = bank.slice(0, 30).map(({ id }) => id);
  const selected = selectQuestionRound({
    questions: bank,
    questionCount: 10,
    recentQuestionIds: recent,
    random: createSeededRandom(11)
  });

  assert.ok(selected.every(({ id }) => !recent.includes(id)));
});

test("każda zagadka Emoji ma cztery klikalne odpowiedzi A–D", () => {
  const bank = getQuizQuestions("emoji-guesser");

  assert.ok(bank.length >= 40);
  assert.ok(bank.every(({ type, options }) =>
    type === QUESTION_TYPES.SINGLE_CHOICE
    && options.length === 4
    && new Set(options.map(({ id }) => id)).size === 4
    && options.every(({ label }) => typeof label === "string" && label.length > 0)
  ));
});

test("anty-powtórki omijają także świeżo sprawdzony temat pod innym ID", () => {
  const bank = getQuizQuestions("discography-builder");
  const topic = bank[0].topicId;
  const selected = selectQuestionRound({
    questions: bank,
    questionCount: 10,
    recentQuestionHistory: [{ id: bank[0].id, topicId: topic }],
    random: createSeededRandom(14)
  });

  assert.ok(selected.every((question) => question.topicId !== topic));
});

test("banki osiągają realne minima bez liczenia tasowania A–D", () => {
  const lore = getQuizQuestions("hardcore-lore");
  const who = getQuizQuestions("who-is-who");
  const discography = getQuizQuestions("discography-builder");

  assert.ok(lore.length >= 120);
  assert.ok([3, 4, 5].every((difficulty) => lore.filter((question) => question.difficulty === difficulty).length >= 40));
  assert.ok([1, 2, 3, 4, 5].every((difficulty) => who.filter((question) => question.difficulty === difficulty).length >= 40));
  assert.ok(discography.length >= 100);
});

test("tropy Skojarzeń i Who Is Who nie zawierają wprost etykiety odpowiedzi", () => {
  for (const modeId of ["assoc-master", "who-is-who"]) {
    for (const question of getQuizQuestions(modeId)) {
      const answer = normalizeAnswer(question.options.find(({ id }) => id === question.correctOptionId).label);
      assert.ok(question.clues.every((clue) => {
        const normalizedClue = normalizeAnswer(clue);
        const words = normalizedClue.split(/\s+/);
        return answer.includes(" ") ? !normalizedClue.includes(answer) : !words.includes(answer);
      }), `${question.id} zdradza odpowiedź`);
    }
  }
});
