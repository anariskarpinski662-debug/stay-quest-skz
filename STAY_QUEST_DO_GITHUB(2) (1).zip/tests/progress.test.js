import test from "node:test";
import assert from "node:assert/strict";
import { createInitialState } from "../src/app/store.js";
import { applyGameResult, getLevelInfo } from "../src/game/progress.js";

const fixedDate = () => new Date("2026-08-19T12:00:00.000Z");

function quizResult(overrides = {}) {
  return {
    modeId: "assoc-master",
    kind: "quiz",
    score: 1000,
    accuracy: 100,
    longestStreak: 10,
    currentStreak: 10,
    correctAnswers: 10,
    totalQuestions: 10,
    details: {},
    ...overrides
  };
}

test("progi poziomów są skalibrowane do nowej ekonomii", () => {
  assert.equal(getLevelInfo(0).level, 1);
  assert.equal(getLevelInfo(1499).level, 1);
  assert.equal(getLevelInfo(1500).level, 2);
  assert.equal(getLevelInfo(4000).rank, "Core STAY");
  assert.equal(getLevelInfo(11076).rank, "Master STAY");
});

test("wynik rundy aktualizuje profil, rekord, historię i osiągnięcia", () => {
  const { state, newlyUnlocked } = applyGameResult(createInitialState(), quizResult(), { now: fixedDate });

  assert.equal(state.player.totalPoints, 1000);
  assert.equal(state.player.bestStreak, 10);
  assert.equal(state.records["assoc-master"].plays, 1);
  assert.equal(state.records["assoc-master"].bestScore, 1000);
  assert.equal(state.stats.correctAnswers, 10);
  assert.equal(state.history.length, 1);
  assert.ok(newlyUnlocked.includes("first-round"));
  assert.ok(newlyUnlocked.includes("points-1000"));
  assert.ok(newlyUnlocked.includes("streak-ten"));
  assert.ok(newlyUnlocked.includes("perfect-quiz"));
});

test("osiągnięcie całej piątki wpada dopiero po ukończeniu pięciu trybów", () => {
  const results = [
    quizResult({ modeId: "assoc-master" }),
    quizResult({ modeId: "emoji-guesser", score: 800 }),
    quizResult({ modeId: "hardcore-lore", score: 1200 }),
    {
      modeId: "timeline",
      kind: "timeline",
      score: 900,
      accuracy: 100,
      details: { perfect: true, roundSize: 6 }
    },
    {
      modeId: "skzoo-memory",
      kind: "memory",
      score: 1200,
      accuracy: 100,
      details: { pairCount: 4, moves: 4, elapsedSeconds: 12 }
    }
  ];

  let state = createInitialState();
  let finalUnlocks = [];
  for (const result of results) {
    const applied = applyGameResult(state, result, { now: fixedDate });
    state = applied.state;
    finalUnlocks = applied.newlyUnlocked;
  }

  assert.equal(state.stats.completedModes.length, 5);
  assert.ok(finalUnlocks.includes("all-modes"));
  assert.equal(state.stats.perfectTimelineRounds, 1);
  assert.equal(state.stats.perfectMemoryRounds, 1);
});

test("Memory przechowuje najlepszą liczbę ruchów osobno dla rozmiaru planszy", () => {
  const first = applyGameResult(
    createInitialState(),
    {
      modeId: "skzoo-memory",
      kind: "memory",
      score: 900,
      accuracy: 50,
      details: { pairCount: 4, moves: 8, elapsedSeconds: 40 }
    },
    { now: fixedDate }
  ).state;
  const second = applyGameResult(
    first,
    {
      modeId: "skzoo-memory",
      kind: "memory",
      score: 1050,
      accuracy: 67,
      details: { pairCount: 4, moves: 6, elapsedSeconds: 31 }
    },
    { now: fixedDate }
  ).state;

  assert.equal(second.records["skzoo-memory"].bestMovesBySize["4"], 6);
  assert.equal(second.records["skzoo-memory"].bestTimeBySize["4"], 31);
});

test("nieprawidłowy wynik nie trafia do postępu", () => {
  assert.throws(
    () => applyGameResult(createInitialState(), quizResult({ score: -1 }), { now: fixedDate }),
    /nieujemną/
  );
  assert.throws(
    () => applyGameResult(createInitialState(), quizResult({ modeId: "unknown" }), { now: fixedDate }),
    /nieznanego trybu/
  );
  assert.throws(
    () => applyGameResult(createInitialState(), {
      modeId: "skzoo-memory",
      kind: "memory",
      score: 100,
      accuracy: 100,
      details: { pairCount: 8, moves: 4, elapsedSeconds: 10 }
    }, { now: fixedDate }),
    /mniejsza od liczby par/
  );
});
