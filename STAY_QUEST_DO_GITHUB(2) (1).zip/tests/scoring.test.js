import test from "node:test";
import assert from "node:assert/strict";
import { calculateQuestionScore, getRepeatMultiplier } from "../src/game/scoring.js";

test("błędna odpowiedź daje zero i zeruje serię", () => {
  const score = calculateQuestionScore({
    correct: false,
    basePoints: 100,
    difficulty: 5,
    currentStreak: 4
  });

  assert.equal(score.total, 0);
  assert.equal(score.nextStreak, 0);
});

test("trudność i seria zwiększają wynik poprawnej odpowiedzi", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 3,
    currentStreak: 2
  });

  assert.equal(score.basePoints, 50);
  assert.equal(score.difficultyBonus, 12);
  assert.equal(score.streakBonus, 12);
  assert.equal(score.total, 74);
  assert.equal(score.nextStreak, 3);
});

test("podpowiedź odejmuje 25 procent od zdobytej puli", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 1,
    currentStreak: 0,
    hintUsed: true
  });

  assert.equal(score.hintPenalty, 13);
  assert.equal(score.total, 37);
});

test("premia za serię nie przekracza 24 punktów", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 1,
    currentStreak: 20
  });

  assert.equal(score.streakBonus, 24);
});

test("dodatkowo odsłonięte tropy odejmują stałą liczbę punktów", () => {
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 150,
    difficulty: 1,
    extraPenalty: 20
  });

  assert.equal(score.revealPenalty, 20);
  assert.equal(score.total, 55);
});

test("szybki powrót identycznego faktu ogranicza farming punktów", () => {
  const recentHistory = [
    { id: "wariant-c", topicId: "ten-sam-fakt" },
    { id: "wariant-b", topicId: "ten-sam-fakt" },
    { id: "wariant-a", topicId: "ten-sam-fakt" }
  ];
  const multiplier = getRepeatMultiplier({ questionId: "wariant-d", topicId: "ten-sam-fakt", recentHistory });
  const score = calculateQuestionScore({
    correct: true,
    basePoints: 100,
    difficulty: 3,
    repeatMultiplier: multiplier
  });

  assert.equal(multiplier, 0.35);
  assert.ok(score.repeatPenalty > 0);
  assert.ok(score.total < score.basePoints + score.difficultyBonus);
});
