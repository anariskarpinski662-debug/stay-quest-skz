import test from "node:test";
import assert from "node:assert/strict";
import { SOULMATE_MEMBERS, SOULMATE_QUESTIONS } from "../src/data/soulmate-questions.js";
import { createSeededRandom } from "../src/game/random.js";
import { createSoulmateSession, validateSoulmateQuestions } from "../src/game/soulmate-session.js";

test("STAY Lab ma 40 poprawnych pytań sytuacyjnych", () => {
  assert.equal(SOULMATE_QUESTIONS.length, 40);
  assert.equal(SOULMATE_MEMBERS.length, 8);
  assert.deepEqual(validateSoulmateQuestions(SOULMATE_QUESTIONS), { valid: true, errors: [] });
});

test("Bratnia Dusza losuje 25 pytań i pokazuje trzy dopasowania", () => {
  const session = createSoulmateSession({
    questions: SOULMATE_QUESTIONS,
    members: SOULMATE_MEMBERS,
    random: createSeededRandom(2026)
  });
  const seen = [];

  while (session.getSnapshot().status === "active") {
    const question = session.getSnapshot().currentQuestion;
    seen.push(question.id);
    session.answer(question.options[0].id);
  }

  const result = session.getResult();
  assert.equal(seen.length, 25);
  assert.equal(new Set(seen).size, 25);
  assert.equal(result.topMatches.length, 3);
  assert.equal(result.allMatches.length, 8);
  assert.ok(result.topMatches.every(({ percentage, reasons }) => percentage >= 52 && percentage <= 96 && reasons.length === 3));
});
