import assert from "node:assert/strict";
import { once } from "node:events";
import { createStaticServer } from "./dev-server.mjs";

const server = createStaticServer();
server.listen(0, "127.0.0.1");
await once(server, "listening");

const { port } = server.address();
const origin = `http://127.0.0.1:${port}`;

try {
  const paths = [
    "/",
    "/manifest.webmanifest",
    "/service-worker.js",
    "/src/main.js",
    "/src/app/feedback.js",
    "/src/data/question-bank.js",
    "/src/data/extended-question-bank.js",
    "/src/data/daily-challenge.js",
    "/src/data/soulmate-questions.js",
    "/src/data/achievements.js",
    "/src/game/quiz-session.js",
    "/src/game/soulmate-session.js",
    "/src/game/progress.js",
    "/src/game/timeline-session.js",
    "/src/game/memory-session.js",
    "/src/ui/screens/quiz-screen.js",
    "/src/ui/screens/achievements-screen.js",
    "/src/ui/screens/settings-screen.js",
    "/src/ui/screens/timeline-screen.js",
    "/src/ui/screens/memory-screen.js",
    "/src/ui/screens/soulmate-screen.js",
    "/src/styles/warm-theme.css"
  ];

  for (const path of paths) {
    const response = await fetch(`${origin}${path}`);
    assert.equal(response.status, 200, `${path} powinien zwrócić status 200`);
    assert.ok((await response.text()).length > 20, `${path} nie może być pusty`);
  }

  const manifest = await (await fetch(`${origin}/manifest.webmanifest`)).json();
  assert.equal(manifest.display, "standalone");

  const missingAsset = await fetch(`${origin}/nie-istnieje.js`);
  assert.equal(missingAsset.status, 404);

  console.log("HTTP smoke test: OK");
} finally {
  server.close();
  await once(server, "close");
}
