const CACHE_PREFIX = "stay-quest-";
const STATIC_CACHE = "stay-quest-shell-v11";
const RUNTIME_CACHE = "stay-quest-runtime-v1";

const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./assets/icons/app-icon.svg",
  "./assets/icons/app-icon-192.png",
  "./assets/icons/app-icon-512.png",
  "./assets/icons/app-icon-maskable-512.png",
  "./src/main.js",
  "./src/app/app.js",
  "./src/app/feedback.js",
  "./src/app/router.js",
  "./src/app/store.js",
  "./src/data/game-modes.js",
  "./src/data/achievements.js",
  "./src/data/member-symbols.js",
  "./src/data/question-bank.js",
  "./src/data/extended-question-bank.js",
  "./src/data/quality-question-bank.js",
  "./src/data/daily-challenge.js",
  "./src/data/soulmate-questions.js",
  "./src/data/timeline-events.js",
  "./src/game/question-schema.js",
  "./src/game/random.js",
  "./src/game/scoring.js",
  "./src/game/progress.js",
  "./src/game/quiz-session.js",
  "./src/game/soulmate-session.js",
  "./src/game/timeline-session.js",
  "./src/game/memory-session.js",
  "./src/ui/app-shell.js",
  "./src/ui/html.js",
  "./src/ui/components/mode-card.js",
  "./src/ui/screens/home-screen.js",
  "./src/ui/screens/achievements-screen.js",
  "./src/ui/screens/settings-screen.js",
  "./src/ui/screens/mode-screen.js",
  "./src/ui/screens/quiz-screen.js",
  "./src/ui/screens/timeline-screen.js",
  "./src/ui/screens/memory-screen.js",
  "./src/ui/screens/soulmate-screen.js",
  "./src/ui/screens/static-screen.js",
  "./src/styles/tokens.css",
  "./src/styles/base.css",
  "./src/styles/layout.css",
  "./src/styles/components.css",
  "./src/styles/warm-theme.css"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(STATIC_CACHE).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => key.startsWith(CACHE_PREFIX) && ![STATIC_CACHE, RUNTIME_CACHE].includes(key))
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

async function fetchAndCache(request, cacheName) {
  const response = await fetch(request);
  if (response && response.status === 200 && response.type !== "opaque") {
    const cache = await caches.open(cacheName);
    await cache.put(request, response.clone());
  }
  return response;
}

async function handleNavigation(request) {
  try {
    return await fetchAndCache(request, RUNTIME_CACHE);
  } catch {
    return (await caches.match(request)) ?? (await caches.match("./index.html")) ?? Response.error();
  }
}

async function handleAsset(event) {
  const cached = await caches.match(event.request);
  if (cached) {
    event.waitUntil(fetchAndCache(event.request, STATIC_CACHE).catch(() => undefined));
    return cached;
  }

  try {
    return await fetchAndCache(event.request, RUNTIME_CACHE);
  } catch {
    return Response.error();
  }
}

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const requestUrl = new URL(event.request.url);

  if (requestUrl.origin !== self.location.origin) return;
  event.respondWith(event.request.mode === "navigate" ? handleNavigation(event.request) : handleAsset(event));
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});
